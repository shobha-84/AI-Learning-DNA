"""
RAG + LLM engine for the in-chapter AI Learning Companion.

Retrieval is deliberately dependency-free (no vector DB, no embedding API) so the
demo runs anywhere. Chapter content is split into sections and sentence-level
chunks, then scored with a small BM25-style lexical ranker. That is enough to keep
answers chapter-specific without an external service.

Retrieval order (the RAG flow shown in the UI):
    learner question
      -> retrieve chapter content
      -> retrieve chapter DNA
      -> retrieve assessment insights
      -> build LLM context
      -> generate response

The LLM is optional. When Ollama is not running, responses are composed from the
retrieved chapter text so the companion is still useful offline.
"""

import math
import re
from collections import Counter
from typing import Any, Dict, List, Optional, Tuple

try:
    import ollama

    OLLAMA_AVAILABLE = True
except ImportError:
    OLLAMA_AVAILABLE = False


# Words that carry no retrieval signal.
STOPWORDS = {
    "a", "an", "the", "is", "are", "was", "were", "be", "been", "being",
    "of", "in", "on", "at", "to", "for", "with", "by", "from", "as", "it",
    "this", "that", "these", "those", "and", "or", "but", "if", "then",
    "so", "than", "do", "does", "did", "can", "could", "will", "would",
    "me", "my", "i", "you", "your", "we", "our", "what", "how", "why",
    "please", "give", "tell", "explain", "about",
}

# Maps a learner question to an intent that shapes both retrieval and the prompt.
INTENT_RULES: List[Tuple[str, Tuple[str, ...]]] = [
    ("practice", ("practice", "question", "quiz", "test", "exercise", "worksheet", "solve")),
    ("simple", ("simple", "easy", "plain", "simple english", "understand", "confused", "beginner")),
    ("example", ("example", "real life", "real-life", "daily life", "practical")),
    ("summarize", ("summary", "summarise", "summarize", "recap", "revision", "revise", "cheat sheet", "key points", "quick")),
    ("weakness", ("weak", "struggle", "wrong", "mistake", "gap", "improve", "better", "why am i", "why am i weak")),
    ("recommend", ("recommend", "suggest", "should i", "what should", "next step", "plan", "study")),
    ("explain", ("what is", "what are", "define", "meaning", "how do", "how does", "why does", "why is")),
]

INTENT_LABELS = {
    "practice": "Create practice questions",
    "simple": "Explain in simple English",
    "example": "Give a real-life example",
    "summarize": "Summarize the chapter",
    "weakness": "Explain my weaknesses",
    "recommend": "Recommend what to study next",
    "explain": "Explain the concept",
    "default": "Answer the question",
}

# Generic prompts like "Explain in simple English" carry no content-bearing keywords,
# so we expand them into the terms most likely to appear in useful chapter text.
INTENT_QUERY_TERMS = {
    "simple": "definition example concept key idea explain",
    "summarize": "summary key points revision review",
    "example": "example real life example",
    "practice": "example practice question",
    "weakness": "concept key idea example",
    "recommend": "summary concept key idea",
}


def tokenize(text: str) -> List[str]:
    """Lowercase word tokens, keeping fractions such as 3/4 as single tokens."""
    lowered = (text or "").lower()
    tokens = re.findall(r"\d+\s*/\s*\d+|\d+(?:\.\d+)?|[a-z]+", lowered)
    return [t.strip() for t in tokens if t.strip() and t.strip() not in STOPWORDS]


def clean_markdown(text: str) -> str:
    """Strip markdown syntax so retrieved text reads as plain prose."""
    cleaned = re.sub(r"^#{1,6}\s*", "", text or "", flags=re.MULTILINE)
    cleaned = re.sub(r"\*\*(.+?)\*\*", r"\1", cleaned)
    cleaned = re.sub(r"\*(.+?)\*", r"\1", cleaned)
    cleaned = re.sub(r"`(.+?)`", r"\1", cleaned)
    cleaned = re.sub(r"^[-*+]\s+", "• ", cleaned, flags=re.MULTILINE)
    cleaned = re.sub(r"^(\d+)\.\s+", r"\1. ", cleaned, flags=re.MULTILINE)
    cleaned = cleaned.replace("---", "")
    return re.sub(r"\n{3,}", "\n\n", cleaned).strip()


def clean_heading(heading: str) -> str:
    """Trim trailing punctuation so headings read cleanly in the UI."""
    return re.sub(r"[\s:.\-]+$", "", (heading or "").strip())


def detect_intent(message: str) -> str:
    """Classify the learner's question so we can shape retrieval and the answer."""
    lower = (message or "").lower()
    for intent, keywords in INTENT_RULES:
        if any(k in lower for k in keywords):
            return intent
    return "default"


def split_sections(markdown: str) -> List[Dict[str, str]]:
    """Split chapter markdown into (heading, body) sections."""
    sections: List[Dict[str, str]] = []
    if not markdown:
        return sections

    lines = markdown.splitlines()
    heading = "Overview"
    buffer: List[str] = []

    for line in lines:
        heading_match = re.match(r"^(#{1,6})\s+(.*)$", line.strip())
        if heading_match:
            if buffer and "".join(buffer).strip():
                sections.append({"heading": heading, "body": "\n".join(buffer).strip()})
            heading = heading_match.group(2).strip()
            buffer = []
        else:
            buffer.append(line)

    if buffer and "".join(buffer).strip():
        sections.append({"heading": heading, "body": "\n".join(buffer).strip()})
    return sections


def chunk_text(text: str, max_chars: int = 420) -> List[str]:
    """Split a section body into sentence-grouped chunks."""
    body = clean_markdown(text)
    if not body:
        return []
    if len(body) <= max_chars:
        return [body]

    chunks: List[str] = []
    current = ""
    for sentence in re.split(r"(?<=[.!?•])\s+", body):
        if not sentence.strip():
            continue
        if len(current) + len(sentence) + 1 > max_chars and current:
            chunks.append(current.strip())
            current = sentence
        else:
            current = f"{current} {sentence}".strip()
    if current.strip():
        chunks.append(current.strip())
    return chunks


class BM25Index:
    """Small BM25 ranker over pre-chunked chapter text."""

    K1 = 1.5
    B = 0.75

    def __init__(self, chunks: List[Dict[str, str]]):
        self.chunks = chunks
        self.doc_tokens = [tokenize(c["text"]) for c in chunks]
        self.doc_freqs = [Counter(t) for t in self.doc_tokens]
        self.doc_lens = [len(t) for t in self.doc_tokens]
        self.avg_len = (sum(self.doc_lens) / len(self.doc_lens)) if self.doc_lens else 0.0
        self.term_freqs: Counter = Counter()
        for freq in self.doc_freqs:
            self.term_freqs.update(freq.keys())

    def search(self, query: str, top_k: int = 4) -> List[Dict[str, Any]]:
        if not self.chunks:
            return []
        query_tokens = tokenize(query)
        if not query_tokens:
            return []

        total_docs = len(self.chunks)
        scored: List[Tuple[float, Dict[str, Any]]] = []

        for i, chunk in enumerate(self.chunks):
            freq = self.doc_freqs[i]
            doc_len = self.doc_lens[i] or 1
            score = 0.0
            for term in query_tokens:
                tf = freq.get(term, 0)
                if tf == 0:
                    continue
                df = self.term_freqs.get(term, 0)
                # BM25 IDF, floored so very common terms never subtract score.
                idf = math.log(1 + (total_docs - df + 0.5) / (df + 0.5))
                denominator = tf + self.K1 * (1 - self.B + self.B * doc_len / self.avg_len)
                score += idf * (tf * (self.K1 + 1)) / denominator
            if score > 0:
                scored.append((score, {**chunk, "score": round(score, 3)}))

        scored.sort(key=lambda item: item[0], reverse=True)
        return [item[1] for item in scored[:top_k]]


class ChapterRetriever:
    """Builds a searchable index for one chapter from its stored content."""

    def __init__(self, chapter: Dict[str, Any], contents: List[Dict[str, Any]], questions: List[Dict[str, Any]]):
        self.chapter = chapter or {}
        self.contents = contents or []
        self.questions = questions or []
        self.sections = self._build_sections()
        self.index = BM25Index(self.sections)

    def _build_sections(self) -> List[Dict[str, str]]:
        chunks: List[Dict[str, str]] = []
        seen: set = set()

        for content in self.contents:
            if content.get("type") != "document":
                continue
            for section in split_sections(content.get("text", "")):
                for chunk in chunk_text(section["body"]):
                    key = chunk.lower()[:80]
                    if key in seen:
                        continue
                    seen.add(key)
                    chunks.append({
                        "text": chunk,
                        "heading": clean_heading(section["heading"]),
                        "source": "chapter content",
                    })

        # Slides and questions are secondary sources, ranked below the document.
        for content in self.contents:
            if content.get("type") in ("document", "viva"):
                continue
            text = clean_markdown(content.get("text", ""))
            if not text:
                continue
            label = content.get("title") or content.get("type")
            key = f"{content.get('type')}::{text.lower()[:60]}"
            if key in seen:
                continue
            seen.add(key)
            chunks.append({"text": text, "heading": label, "source": content.get("type", "content")})

        for q in self.questions:
            text = clean_markdown(q.get("text", ""))
            if not text:
                continue
            answer = clean_markdown(q.get("answer", ""))
            explanation = clean_markdown(q.get("explanation", ""))
            combined = f"{text}\nAnswer: {answer}" + (f"\n{explanation}" if explanation else "")
            key = f"q::{text.lower()[:60]}"
            if key in seen:
                continue
            seen.add(key)
            chunks.append({
                "text": clean_markdown(combined),
                "heading": q.get("concept") or "Practice",
                "source": "question bank",
            })

        return chunks

    def retrieve(
        self,
        query: str,
        intent: str,
        top_k: int = 4,
        boost_terms: Optional[List[str]] = None,
    ) -> List[Dict[str, Any]]:
        # Concepts the learner is actually weak in outrank a generic prompt like
        # "why am I weak", so they are mixed into the query.
        search_query = query
        weak = [w for w in (boost_terms or []) if w]
        if weak and intent in ("weakness", "recommend", "default", "simple"):
            search_query = f"{query} {' '.join(weak)}"

        hits = self.index.search(search_query, top_k=top_k)

        # A generic prompt ("Explain in simple English") matches nothing lexically.
        # Fall back to intent-driven retrieval so the companion still has material.
        if not hits and intent in INTENT_QUERY_TERMS:
            hits = self.index.search(INTENT_QUERY_TERMS[intent], top_k=top_k)

        # Still nothing: return the opening chunks so the learner gets real content
        # instead of an empty answer.
        if not hits:
            hits = [{**c, "score": 0.0} for c in self.index.chunks[:top_k]]

        # Summary-style questions want breadth, so always include the summary section.
        if intent in ("summarize", "recommend", "default") and len(hits) < top_k:
            for chunk in self.index.chunks:
                if "summary" in chunk["heading"].lower() and chunk not in hits:
                    hits.append({**chunk, "score": 0.0})
                    break
        return hits


class ChapterCompanion:
    """Chapter-scoped AI Learning Companion (RAG + optional LLM)."""

    def __init__(self):
        self.client = None
        self.available_model = None
        if OLLAMA_AVAILABLE:
            try:
                self.client = ollama
                models = self.client.list()
                available = [m.get("name", "") for m in models.get("models", [])]
                for candidate in ["llama3.2", "llama3", "llama", "mistral", "gemma"]:
                    match = next((m for m in available if m.startswith(candidate)), None)
                    if match:
                        self.available_model = match
                        break
            except Exception:
                self.client = None

    # ---------- context building ----------

    def build_context(
        self,
        retriever: ChapterRetriever,
        message: str,
        intent: str,
        dna: Optional[Dict[str, Any]],
        assessment: Optional[Dict[str, Any]],
    ) -> Dict[str, Any]:
        chapter = retriever.chapter

        strengths, gaps, misconceptions, recommendations = [], [], [], []
        score = None
        if dna:
            score = dna.get("overall_score")
            strengths = [s.get("concept", "") for s in (dna.get("strengths") or [])][:4]
            gaps = [g.get("concept", "") for g in (dna.get("gaps") or [])][:4]
            misconceptions = [
                m.get("description") or m.get("type", "")
                for m in (dna.get("misconceptions") or [])
            ][:3]
            recommendations = list(dna.get("recommendations") or [])[:4]

        weak_concepts = [g for g in gaps if g]
        wrong_concepts = [
            r.get("concept", "")
            for r in ((assessment or {}).get("wrong_concepts") or [])
            if r.get("concept")
        ][:4]

        # Retrieval runs after the DNA is read so weak concepts can steer it.
        hits = retriever.retrieve(message, intent, boost_terms=weak_concepts or wrong_concepts)

        return {
            "chapter_title": chapter.get("title", "this chapter"),
            "chapter_subject": chapter.get("subject", ""),
            "chapter_description": chapter.get("description", ""),
            "intent": intent,
            "intent_label": INTENT_LABELS.get(intent, INTENT_LABELS["default"]),
            "hits": hits,
            "context_text": self._format_hits(hits),
            "dna_score": score,
            "strengths": strengths,
            "gaps": gaps,
            "weak_concepts": weak_concepts or wrong_concepts,
            "misconceptions": misconceptions,
            "recommendations": recommendations,
            "has_dna": bool(dna),
        }

    @staticmethod
    def _format_hits(hits: List[Dict[str, Any]]) -> str:
        if not hits:
            return ""
        blocks = []
        for i, hit in enumerate(hits, start=1):
            blocks.append(f"[{i}] ({hit['heading']})\n{hit['text']}")
        return "\n\n".join(blocks)

    # ---------- answer generation ----------

    def answer(self, message: str, context: Dict[str, Any]) -> str:
        if not context.get("context_text"):
            return self._offline_answer(message, context)

        if self.client:
            try:
                return self._llm_answer(message, context)
            except Exception as exc:  # pragma: no cover - network/LLM failure path
                print(f"[ChapterCompanion] LLM failed: {exc}. Using retrieval fallback.")
        return self._offline_answer(message, context)

    def _llm_answer(self, message: str, context: Dict[str, Any]) -> str:
        title = context.get("chapter_title", "this chapter")
        subject = context.get("chapter_subject", "")
        score = context.get("dna_score")
        score_line = (
            f"- Your DNA score on this chapter: {score}%"
            if score is not None
            else "- You have not completed an assessment for this chapter yet."
        )

        prompt = f"""You are an AI Learning Companion embedded inside a learning chapter.
Be accurate, warm and concise. Use ONLY the chapter excerpts below to teach the concept.

Subject: {subject or 'General'}
Chapter: {title}
Learner's intent: {context.get('intent_label', 'Answer the question')}

Learner's DNA for this chapter:
{score_line}
- Strong in: {', '.join(context.get('strengths', [])) or 'nothing recorded yet'}
- Needs work on: {', '.join(context.get('weak_concepts', [])) or 'nothing recorded yet'}
- Misconceptions to watch: {'; '.join(context.get('misconceptions', [])) or 'none recorded'}

Chapter excerpts (retrieved, may be partial):
\"\"\"
{context['context_text']}
\"\"\"

Learner question: {message}

Rules:
1. Ground every factual statement in the excerpts. If the excerpts do not cover it, say so plainly instead of inventing detail.
2. Match the register the intent implies: simple explanations use short sentences and everyday words; practice questions come with answers.
3. If the learner is weak in a concept, acknowledge it supportively and target the explanation at that concept.
4. Keep it under 200 words. Use short paragraphs and bullets where it helps."""

        response = self.client.chat(
            model=self.available_model or "llama3.2",
            messages=[{"role": "user", "content": prompt}],
            options={"temperature": 0.6},
        )
        return response["message"]["content"].strip()

    def _offline_answer(self, message: str, context: Dict[str, Any]) -> str:
        """Compose a chapter-grounded answer without an LLM."""
        title = context.get("chapter_title", "this chapter")
        intent = context.get("intent", "default")
        hits = context.get("hits", [])
        sources = ", ".join(sorted({h["heading"] for h in hits})) or "this chapter"
        lead = f"**{title}** — {sources}"

        if intent == "practice":
            body = self._offline_practice(hits, title)
        elif intent == "summarize":
            body = self._offline_summary(hits, title)
        elif intent == "weakness":
            body = self._offline_weakness(context, hits)
        elif intent == "recommend":
            body = self._offline_recommend(context)
        elif intent in ("example", "simple"):
            body = self._offline_explain(hits, title, simple=intent == "simple")
        else:
            body = self._offline_explain(hits, title, simple=False)

        return f"{lead}\n\n{body}"

    @staticmethod
    def _offline_explain(hits: List[Dict[str, Any]], title: str, simple: bool) -> str:
        if not hits:
            return (
                f"I could not find anything in the {title} material that covers this yet. "
                "Try rephrasing, or ask your teacher to add this topic to the chapter."
            )
        lines = []
        for hit in hits[:2]:
            excerpt = hit["text"]
            if len(excerpt) > 700:
                excerpt = excerpt[:700].rsplit(" ", 1)[0] + "..."
            prefix = "In plain terms: " if simple else ""
            lines.append(f"**{hit['heading']}**\n{prefix}{excerpt}")
        if simple:
            lines.append("Ask me again if any line still feels unclear, and I will re-explain it differently.")
        return "\n\n".join(lines)

    @staticmethod
    def _offline_summary(hits: List[Dict[str, Any]], title: str) -> str:
        if not hits:
            return f"The {title} material is not available yet, so I cannot summarize it."
        summary_hits = [h for h in hits if "summary" in h["heading"].lower()] or hits[:2]
        lines = ["**Key points**"]
        for hit in summary_hits[:2]:
            for point in [p.strip() for p in hit["text"].split("\n") if p.strip()][:8]:
                lines.append(f"- {point.lstrip('• ').strip()}")
        return "\n".join(lines)

    @staticmethod
    def _offline_weakness(context: Dict[str, Any], hits: List[Dict[str, Any]]) -> str:
        weak = context.get("weak_concepts") or []
        if not weak:
            return (
                "I do not see any recorded weak concepts for this chapter yet. "
                "Complete the chapter assessment and I will pinpoint exactly where to focus."
            )
        lines = [f"Your weakest areas here are **{', '.join(weak)}**. Here is what the chapter says about them:"]
        for hit in hits[:2]:
            excerpt = hit["text"]
            if len(excerpt) > 450:
                excerpt = excerpt[:450].rsplit(" ", 1)[0] + "..."
            lines.append(f"\n**{hit['heading']}**\n{excerpt}")
        lines.append("\nRevisit these two sections, then retake the chapter assessment to update your DNA.")
        return "\n".join(lines)

    @staticmethod
    def _offline_recommend(context: Dict[str, Any]) -> str:
        recommendations = context.get("recommendations") or []
        if recommendations:
            return "**From your DNA profile**\n" + "\n".join(f"- {r}" for r in recommendations[:5])
        weak = context.get("weak_concepts") or []
        if weak:
            return (
                "**Suggested next steps**\n"
                + "\n".join(f"- Focus on {w}" for w in weak)
                + "\n\n- Re-read the matching section in the learner document\n- Retake the chapter assessment"
            )
        return "Complete this chapter's assessment first, then I can give you targeted revision steps."

    @staticmethod
    def _offline_practice(hits: List[Dict[str, Any]], title: str) -> str:
        if not hits:
            return f"I could not build practice questions for {title} because its content is not loaded yet."
        lines = ["**Practice questions**", "Answer these without looking back at the chapter:", ""]
        for i, hit in enumerate(hits[:3], start=1):
            lines.append(f"{i}. Using the {hit['heading']} section — write down the key idea in your own words, then check it against the chapter.")
        lines.append("")
        lines.append("Want more? Ask for practice on a specific concept and I will focus the questions there.")
        return "\n".join(lines)
