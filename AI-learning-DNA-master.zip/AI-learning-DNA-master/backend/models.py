from pydantic import BaseModel
from typing import Dict, List, Literal, Optional
from datetime import datetime


class QuestionAnswer(BaseModel):
    question_id: str
    question_text: str
    student_answer: str
    correct_answer: str
    is_correct: bool
    concept_id: str
    concept_name: str
    explanation: str


class AssessmentSubmission(BaseModel):
    student_id: str
    chapter_id: str
    answers: List[QuestionAnswer]
    attempt_number: int


class Misconception(BaseModel):
    type: str
    description: str
    evidence: str
    frequency: int
    confidence: float
    corrected_concept: str
    resolution: str


class ConceptMastery(BaseModel):
    concept_id: str
    concept_name: str
    mastery_score: float
    previous_score: Optional[float]
    trend: Literal["improving", "declining", "stable"]
    status: Literal["strong", "good", "weak", "critical"]


class DNAProfile(BaseModel):
    id: str
    student_id: str
    chapter_id: str
    version: int
    generated_at: str
    overall_score: float
    concept_mastery: List[ConceptMastery]
    strengths: List[str]
    gaps: List[str]
    misconceptions: List[Misconception]
    reasoning_score: float
    confidence_level: float
    learning_risks: List[str]
    recommendations: List[str]
    remediation_activities: List[Dict]


class ChapterAnswer(BaseModel):
    question_id: str
    student_answer: str


class ChapterSubmission(BaseModel):
    student_id: str
    answers: List[ChapterAnswer]


class ChatMessage(BaseModel):
    student_id: str
    chapter_id: str
    message: str
    context: Optional[Dict] = None


class ChapterContentItem(BaseModel):
    chapter_id: str
    title: str
    content_type: Literal["document", "ppt", "video", "voice", "learning_material"]
    content_url: str
    content_text: Optional[str] = None
    duration: Optional[str] = None
    thumbnail: Optional[str] = None
    description: str = ""
    is_active: bool = True
    sort_order: int = 0


class ChapterQuestionItem(BaseModel):
    chapter_id: str
    question_text: str
    options: List[str]
    correct_answer: str
    concept_id: str
    concept_name: str
    difficulty: Literal["Easy", "Medium", "Hard"]
    explanation: str = ""
    is_active: bool = True
    sort_order: int = 0


class LearningPlanItem(BaseModel):
    student_id: str
    chapter_id: str
    activity_type: Literal["document", "ppt", "video", "voice", "ai_companion", "practice", "assessment"]
    title: str
    description: str = ""
    duration: str = ""
    completed: bool = False
    created_at: str = ""


class ChapterContentRequest(BaseModel):
    chapter_id: str
    title: str
    content_type: str
    content_url: str = ""
    content_text: str = ""
    duration: str = ""
    thumbnail: str = ""
    description: str = ""
    is_active: bool = True
    sort_order: int = 0


class ChapterUpdateRequest(BaseModel):
    title: str = ""
    subject: str = ""
    grade: str = ""
    description: str = ""
    passing_score: int = 70


class ChapterContentItem(BaseModel):
    id: str
    chapter_id: str
    title: str
    content_type: str
    content_url: str
    content_text: str = ""
    duration: str = ""
    thumbnail: str = ""
    description: str = ""
    is_active: bool
    sort_order: int
    created_at: str = ""


class ChapterItem(BaseModel):
    id: str
    title: str
    subject: str
    grade: str
    description: str = ""
    total_questions: int = 0
    passing_score: int = 70
    content_count: int = 0
    questions_count: int = 0
    created_at: str = ""
