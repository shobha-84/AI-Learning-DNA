from fastapi import FastAPI, HTTPException, Request
from pydantic import BaseModel, Field
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from fastapi.responses import FileResponse, HTMLResponse
from starlette.middleware.base import BaseHTTPMiddleware
import os
from pathlib import Path
from sqlalchemy import create_engine, Column, Integer, String as SQLAlchemyString, Float, Boolean, Text, JSON, DateTime, text
from sqlalchemy.dialects.postgresql import VARCHAR
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import sessionmaker, Session
from datetime import datetime
from typing import Any, Dict
import uuid
import numpy as np
from dna_engine import DNAEngine, AICompanion
from rag_engine import ChapterCompanion, ChapterRetriever, detect_intent, INTENT_LABELS, clean_markdown
from seed_data import STUDENTS, ASSESSMENT_HISTORY, CHAPTER_INFO, SEED_CHAPTERS, ALL_QUESTIONS

# Database setup - prefer PostgreSQL when available, but fall back to SQLite for local demo runs.
# The SQLite path is anchored to this file's directory rather than left relative:
# a relative "./learning_dna.db" silently creates a *different* database depending on
# the working directory uvicorn happens to be started from.
_DEFAULT_SQLITE_PATH = Path(__file__).resolve().parent / "learning_dna.db"
DATABASE_URL = os.getenv("DATABASE_URL", f"sqlite:///{_DEFAULT_SQLITE_PATH.as_posix()}")
IS_SQLITE = DATABASE_URL.startswith("sqlite")

# The endpoints below are plain `def`, so FastAPI runs them in the anyio threadpool
# (40 threads by default). SQLAlchemy's default pool of 5 + 10 overflow could not
# serve that, and concurrent chapter-screen requests died with
# "QueuePool limit of size 5 overflow 10 reached". Size the pool above the
# threadpool capacity so a connection is always available, and allow brief
# contention to queue instead of returning a 500.
engine_kwargs: dict = {"pool_pre_ping": True, "pool_size": 20, "max_overflow": 30, "pool_timeout": 60}
if IS_SQLITE:
    engine_kwargs["connect_args"] = {"check_same_thread": False, "timeout": 30}
engine = create_engine(DATABASE_URL, **engine_kwargs)
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)
Base = declarative_base()

# Create tables (moved to after all models are defined)
# Base.metadata.create_all(bind=engine)


def ensure_student_columns():
    if IS_SQLITE:
        with engine.begin() as connection:
            columns = connection.execute(text("PRAGMA table_info(students)")).fetchall()
            existing = {row[1] for row in columns}
            if "school" not in existing:
                connection.execute(text("ALTER TABLE students ADD COLUMN school VARCHAR"))
            if "email" not in existing:
                connection.execute(text("ALTER TABLE students ADD COLUMN email VARCHAR"))
            if "subjects_json" not in existing:
                connection.execute(text("ALTER TABLE students ADD COLUMN subjects_json JSON"))
            if "contact_number" not in existing:
                connection.execute(text("ALTER TABLE students ADD COLUMN contact_number VARCHAR"))
            if "learning_goal" not in existing:
                connection.execute(text("ALTER TABLE students ADD COLUMN learning_goal TEXT"))
            if "registration_date" not in existing:
                connection.execute(text("ALTER TABLE students ADD COLUMN registration_date VARCHAR"))
        return

    with engine.begin() as connection:
        connection.execute(text("ALTER TABLE students ADD COLUMN IF NOT EXISTS school VARCHAR"))
        connection.execute(text("ALTER TABLE students ADD COLUMN IF NOT EXISTS email VARCHAR"))
        connection.execute(text("ALTER TABLE students ADD COLUMN IF NOT EXISTS subjects_json JSON"))
        connection.execute(text("ALTER TABLE students ADD COLUMN IF NOT EXISTS contact_number VARCHAR"))
        connection.execute(text("ALTER TABLE students ADD COLUMN IF NOT EXISTS learning_goal TEXT"))
        connection.execute(text("ALTER TABLE students ADD COLUMN IF NOT EXISTS registration_date VARCHAR"))


def ensure_learning_plan_columns():
    """Add completion_percentage to student_learning_plans on databases created before it existed."""
    if IS_SQLITE:
        with engine.begin() as connection:
            columns = connection.execute(text("PRAGMA table_info(student_learning_plans)")).fetchall()
            existing = {row[1] for row in columns}
            if "completion_percentage" not in existing:
                connection.execute(
                    text("ALTER TABLE student_learning_plans ADD COLUMN completion_percentage INTEGER DEFAULT 0")
                )
        return

    with engine.begin() as connection:
        connection.execute(
            text("ALTER TABLE student_learning_plans ADD COLUMN IF NOT EXISTS completion_percentage INTEGER DEFAULT 0")
        )


app = FastAPI(title="AI Learning DNA", version="1.0.0")

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# --- Database Models ---
class StudentDB(Base):
    __tablename__ = "students"
    id = Column(SQLAlchemyString, primary_key=True)
    name = Column(SQLAlchemyString, nullable=False)
    grade = Column(SQLAlchemyString)
    avatar = Column(SQLAlchemyString)
    enrolled_date = Column(SQLAlchemyString)
    school = Column(SQLAlchemyString)
    email = Column(SQLAlchemyString, unique=True)
    subjects_json = Column(JSON)
    contact_number = Column(SQLAlchemyString)
    learning_goal = Column(Text)
    registration_date = Column(SQLAlchemyString)
    created_at = Column(DateTime, default=datetime.utcnow)


class ChapterDB(Base):
    __tablename__ = "chapters"
    id = Column(SQLAlchemyString, primary_key=True)
    title = Column(SQLAlchemyString, nullable=False)
    subject = Column(SQLAlchemyString)
    grade = Column(SQLAlchemyString)
    description = Column(Text)
    total_questions = Column(Integer)
    passing_score = Column(Integer)


class QuestionDB(Base):
    __tablename__ = "questions"
    id = Column(SQLAlchemyString, primary_key=True)
    chapter_id = Column(SQLAlchemyString)
    text = Column(Text, nullable=False)
    correct_answer = Column(SQLAlchemyString)
    concept_id = Column(SQLAlchemyString)
    concept_name = Column(SQLAlchemyString)
    difficulty = Column(Integer)


class AssessmentDB(Base):
    __tablename__ = "assessments"
    id = Column(SQLAlchemyString, primary_key=True)
    student_id = Column(SQLAlchemyString)
    chapter_id = Column(SQLAlchemyString)
    attempt_number = Column(Integer)
    score = Column(Float)
    date = Column(DateTime)
    answers_json = Column(JSON)
    created_at = Column(DateTime, default=datetime.utcnow)


class DNAProfileDB(Base):
    __tablename__ = "dna_profiles"
    id = Column(SQLAlchemyString, primary_key=True)
    student_id = Column(SQLAlchemyString)
    chapter_id = Column(SQLAlchemyString)
    version = Column(Integer)
    overall_score = Column(Float)
    concept_mastery_json = Column(JSON)
    strengths_json = Column(JSON)
    gaps_json = Column(JSON)
    misconceptions_json = Column(JSON)
    reasoning_score = Column(Float)
    confidence_level = Column(Float)
    learning_risks_json = Column(JSON)
    recommendations_json = Column(JSON)
    remediation_json = Column(JSON)
    generated_at = Column(DateTime, default=datetime.utcnow)


class ChapterContentDB(Base):
    __tablename__ = "chapter_content"
    id = Column(SQLAlchemyString, primary_key=True)
    chapter_id = Column(SQLAlchemyString, nullable=False)
    title = Column(SQLAlchemyString, nullable=False)
    content_type = Column(SQLAlchemyString, nullable=False)
    content_url = Column(SQLAlchemyString, default="")
    content_text = Column(Text, default="")
    duration = Column(SQLAlchemyString, default="")
    thumbnail = Column(SQLAlchemyString, default="")
    description = Column(Text, default="")
    is_active = Column(Boolean, default=True)
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)


class ChapterQuestionsDB(Base):
    __tablename__ = "chapter_questions"
    id = Column(SQLAlchemyString, primary_key=True)
    chapter_id = Column(SQLAlchemyString, nullable=False)
    question_text = Column(Text, nullable=False)
    options_json = Column(JSON, nullable=False)
    correct_answer = Column(SQLAlchemyString, nullable=False)
    concept_id = Column(SQLAlchemyString)
    concept_name = Column(SQLAlchemyString)
    difficulty = Column(SQLAlchemyString)
    explanation = Column(Text, default="")
    is_active = Column(Boolean, default=True)
    sort_order = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)


class StudentLearningPlanDB(Base):
    __tablename__ = "student_learning_plans"
    id = Column(SQLAlchemyString, primary_key=True)
    student_id = Column(SQLAlchemyString, nullable=False)
    chapter_id = Column(SQLAlchemyString, nullable=False)
    activity_type = Column(SQLAlchemyString, nullable=False)
    title = Column(SQLAlchemyString, nullable=False)
    description = Column(Text, default="")
    duration = Column(SQLAlchemyString, default="")
    completed = Column(Boolean, default=False)
    # How much of a learning mode was actually consumed, e.g. video slide progress.
    completion_percentage = Column(Integer, default=0)
    created_at = Column(DateTime, default=datetime.utcnow)


# --- Create Tables ---
Base.metadata.create_all(bind=engine)

# Ensure legacy student columns exist (after tables are created)
ensure_student_columns()
ensure_learning_plan_columns()


# --- Seed Database ---
def seed_database():
    db = SessionLocal()
    try:
        if db.query(StudentDB).count() == 0:
            for s in STUDENTS:
                student = StudentDB(**s)
                db.add(student)
            for q in ALL_QUESTIONS:
                question = QuestionDB(**q)
                db.add(question)
            for ch in SEED_CHAPTERS:
                chapter = ChapterDB(
                    id=ch["id"], title=ch["title"], subject=ch["subject"],
                    grade=ch["grade"], description=ch["description"],
                    total_questions=len(ch["questions"]), passing_score=ch["passing_score"],
                )
                db.add(chapter)

                # Seed chapter content (document, ppt slides, video)
                sort = 1
                # Document content
                doc_id = f"{ch['id']}-doc"
                db.add(ChapterContentDB(
                    id=doc_id, chapter_id=ch["id"], title=f"{ch['title']} - Complete Notes",
                    content_type="document", content_text=ch["document_content"],
                    description="Complete chapter notes covering all topics",
                    is_active=True, sort_order=sort
                ))
                sort += 1

                # PPT slides
                for i, slide in enumerate(ch["ppt_slides"]):
                    ppt_id = f"{ch['id']}-ppt-{i+1}"
                    db.add(ChapterContentDB(
                        id=ppt_id, chapter_id=ch["id"], title=slide["title"],
                        content_type="ppt", content_text=slide["content"],
                        description=f"PPT Slide {i+1}: {slide['title']}",
                        is_active=True, sort_order=sort
                    ))
                    sort += 1

                # Video
                video = ch["video"]
                db.add(ChapterContentDB(
                    id=f"{ch['id']}-video", chapter_id=ch["id"], title=video["title"],
                    content_type="video", content_url=video["url"],
                    duration=video["duration"], description=video["description"],
                    is_active=True, sort_order=sort
                ))

                # Seed chapter questions (new format with options)
                for q in ch["questions"]:
                    db.add(ChapterQuestionsDB(
                        id=q["id"], chapter_id=ch["id"],
                        question_text=q["question"],
                        options_json=q["options"],
                        correct_answer=q["correctAnswer"],
                        concept_id=q["concept_id"],
                        concept_name=q["concept_name"],
                        difficulty=q["difficulty"],
                        is_active=True, sort_order=1
                    ))

            db.commit()
            print("Database seeded successfully")
    except Exception as e:
        db.rollback()
        print(f"Seed error: {e}")
    finally:
        db.close()


seed_database()

# --- API Endpoints ---

@app.get("/api/students")
def get_students():
    db = SessionLocal()
    students = db.query(StudentDB).all()
    return [
        {
            "id": s.id,
            "name": s.name,
            "grade": s.grade,
            "avatar": s.avatar,
            "enrolled_date": s.enrolled_date,
        }
        for s in students
    ]


class RegistrationRequest(BaseModel):
    name: str
    grade: str
    school: str
    email: str
    subjects: list[str]


class StudentRegistrationRequest(BaseModel):
    studentName: str
    class_: str = Field(alias="class")
    schoolName: str
    email: str
    contactNumber: str
    preferredSubjects: list[str]
    learningGoal: str = ""
    registrationDate: str

    class Config:
        allow_population_by_field_name = True


@app.post("/api/students/register")
def register_student_profile(registration: StudentRegistrationRequest):
    db = SessionLocal()
    try:
        existing = db.query(StudentDB).filter(StudentDB.email == registration.email).first()
        if existing:
            existing.name = registration.studentName
            existing.grade = registration.class_
            existing.school = registration.schoolName
            existing.subjects_json = registration.preferredSubjects
            existing.contact_number = registration.contactNumber
            existing.learning_goal = registration.learningGoal
            existing.registration_date = registration.registrationDate
            db.commit()
            return {
                "studentId": existing.id,
                "message": "Registration successful",
                "studentName": existing.name,
                "preferredSubjects": existing.subjects_json,
            }

        dna_students = db.query(StudentDB).filter(StudentDB.id.like("DNA%")) .all()
        next_number = max(
            [int(student.id[3:]) for student in dna_students if student.id[3:].isdigit()] or [10000]
        ) + 1
        student_id = f"DNA{next_number:05d}"
        student = StudentDB(
            id=student_id,
            name=registration.studentName,
            grade=registration.class_,
            avatar="🧑‍🎓",
            enrolled_date=datetime.utcnow().date().isoformat(),
            school=registration.schoolName,
            email=registration.email,
            subjects_json=registration.preferredSubjects,
            contact_number=registration.contactNumber,
            learning_goal=registration.learningGoal,
            registration_date=registration.registrationDate,
        )
        db.add(student)
        db.commit()
        return {
            "studentId": student_id,
            "message": "Registration successful",
            "studentName": student.name,
            "preferredSubjects": student.subjects_json,
        }
    except Exception:
        db.rollback()
        raise HTTPException(status_code=500, detail="Could not create learner profile")
    finally:
        db.close()


@app.post("/api/registrations")
def register_student(registration: RegistrationRequest):
    db = SessionLocal()
    try:
        existing = db.query(StudentDB).filter(StudentDB.email == registration.email).first()
        if existing:
            existing.name = registration.name
            existing.grade = registration.grade
            existing.school = registration.school
            existing.subjects_json = registration.subjects
            db.commit()
            return {"id": existing.id, "name": existing.name, "grade": existing.grade}

        student_id = str(uuid.uuid4())
        student = StudentDB(
            id=student_id,
            name=registration.name,
            grade=registration.grade,
            avatar="🧑‍🎓",
            enrolled_date=datetime.utcnow().date().isoformat(),
            school=registration.school,
            email=str(registration.email),
            subjects_json=registration.subjects,
        )
        db.add(student)
        db.commit()
        return {"id": student_id, "name": student.name, "grade": student.grade}
    except Exception:
        db.rollback()
        raise HTTPException(status_code=500, detail="Could not create learner profile")
    finally:
        db.close()


@app.get("/api/chapters")
def get_chapters():
    db = SessionLocal()
    chapters = db.query(ChapterDB).all()
    return [{"id": c.id, "title": c.title, "subject": c.subject, "grade": c.grade} for c in chapters]


@app.get("/api/questions/{chapter_id}")
def get_questions(chapter_id: str):
    db = SessionLocal()
    questions = db.query(QuestionDB).filter(QuestionDB.chapter_id == chapter_id).all()
    return [
        {
            "id": q.id,
            "text": q.text,
            "concept_name": q.concept_name,
            "difficulty": q.difficulty,
        }
        for q in questions
    ]


@app.get("/api/student/{student_id}/history")
def get_assessment_history(student_id: str):
    db = SessionLocal()
    assessments = (
        db.query(AssessmentDB)
        .filter(AssessmentDB.student_id == student_id)
        .order_by(AssessmentDB.attempt_number.desc())
        .all()
    )
    return [
        {
            "id": a.id,
            "chapter_id": a.chapter_id,
            "attempt_number": a.attempt_number,
            "score": a.score,
            "date": a.date.isoformat() if a.date else None,
            "answers": a.answers_json,
        }
        for a in assessments
    ]


@app.get("/api/student/{student_id}/dna/{chapter_id}")
def get_dna_profile(student_id: str, chapter_id: str):
    db = SessionLocal()
    profiles = (
        db.query(DNAProfileDB)
        .filter(
            DNAProfileDB.student_id == student_id,
            DNAProfileDB.chapter_id == chapter_id,
        )
        .order_by(DNAProfileDB.version.desc())
        .all()
    )
    if not profiles:
        db.close()
        return None
    return [
        {
            "id": p.id,
            "version": p.version,
            "overall_score": p.overall_score,
            "concept_mastery": p.concept_mastery_json,
            "strengths": p.strengths_json,
            "gaps": p.gaps_json,
            "misconceptions": p.misconceptions_json,
            "reasoning_score": p.reasoning_score,
            "confidence_level": p.confidence_level,
            "learning_risks": p.learning_risks_json,
            "recommendations": p.recommendations_json,
            "remediation": p.remediation_json,
            "generated_at": p.generated_at.isoformat() if p.generated_at else None,
        }
        for p in profiles
    ]


@app.post("/api/assessment/submit")
def submit_assessment(submission: dict):
    """Submit assessment and generate DNA profile."""
    student_id = submission["student_id"]
    chapter_id = submission["chapter_id"]
    answers = submission["answers"]
    attempt_number = submission.get("attempt_number", 1)

    # Check if student exists
    db = SessionLocal()
    student = db.query(StudentDB).filter(StudentDB.id == student_id).first()
    if not student:
        db.close()
        raise HTTPException(status_code=404, detail="Student not found")

    # Get chapter info
    chapter = db.query(ChapterDB).filter(ChapterDB.id == chapter_id).first()
    if not chapter:
        db.close()
        raise HTTPException(status_code=404, detail="Chapter not found")

    # Get full question data
    questions_map = {}
    db_questions = (
        db.query(QuestionDB).filter(QuestionDB.chapter_id == chapter_id).all()
    )
    for q in db_questions:
        questions_map[q.id] = {
            "text": q.text,
            "correct_answer": q.correct_answer,
            "concept_id": q.concept_id,
            "concept_name": q.concept_name,
        }

    # Save assessment to database
    assessment_id = str(uuid.uuid4())
    score = sum(1 for a in answers if a.get("is_correct")) * 100 // len(answers)
    assessment = AssessmentDB(
        id=assessment_id,
        student_id=student_id,
        chapter_id=chapter_id,
        attempt_number=attempt_number,
        score=float(score),
        date=datetime.utcnow(),
        answers_json=answers,
    )
    db.add(assessment)
    db.commit()

    # Generate DNA Profile
    engine = DNAEngine()
    ai_companion = AICompanion()

    # Analyze responses
    mastery = engine.analyze_responses(answers)

    # Get previous mastery for trend analysis
    prev_profiles = (
        db.query(DNAProfileDB)
        .filter(
            DNAProfileDB.student_id == student_id,
            DNAProfileDB.chapter_id == chapter_id,
        )
        .order_by(DNAProfileDB.version.desc())
        .limit(1)
        .all()
    )
    prev_mastery = prev_profiles[0].concept_mastery_json if prev_profiles else None

    # Detect misconceptions
    misconceptions = engine.detect_misconceptions(answers, mastery)

    # Identify strengths and gaps
    strengths_gaps = engine.identify_strengths_and_gaps(mastery, prev_mastery)

    # Calculate learning risks
    risks = engine.calculate_learning_risks(mastery, misconceptions, answers)

    # Generate recommendations
    recommendations = engine.generate_recommendations(
        mastery, misconceptions, strengths_gaps, {}
    )

    # Generate remediation activities
    remediation = engine.generate_remediation_activities(misconceptions, strengths_gaps)

    # Calculate reasoning score and confidence
    reasoning_score = score * 0.7 + (100 - sum(
        10 for a in answers if not a.get("is_correct")
    )) * 0.3
    confidence_level = min(100, score + 10)

    # Create DNA profile
    dna_id = str(uuid.uuid4())
    next_version = (prev_profiles[0].version + 1) if prev_profiles else 1

    dna_profile = DNAProfileDB(
        id=dna_id,
        student_id=student_id,
        chapter_id=chapter_id,
        version=next_version,
        overall_score=float(score),
        concept_mastery_json=mastery,
        strengths_json=strengths_gaps.get("strengths", []),
        gaps_json=strengths_gaps.get("gaps", []),
        misconceptions_json=misconceptions,
        reasoning_score=float(min(100, reasoning_score)),
        confidence_level=float(confidence_level),
        learning_risks_json=risks,
        recommendations_json=recommendations,
        remediation_json=remediation,
    )
    db.add(dna_profile)
    db.commit()

    # Copy values before closing session to avoid DetachedInstanceError
    student_name = student.name
    student_avatar = student.avatar
    chapter_title = chapter.title
    db.close()

    return {
        "student": {"id": student_id, "name": student_name, "avatar": student_avatar},
        "chapter": {"id": chapter_id, "title": chapter_title},
        "attempt": attempt_number,
        "score": score,
        "dna_profile": {
            "id": dna_id,
            "version": next_version,
            "overall_score": float(score),
            "concept_mastery": mastery,
            "strengths": strengths_gaps.get("strengths", []),
            "gaps": strengths_gaps.get("gaps", []),
            "misconceptions": misconceptions,
            "reasoning_score": float(min(100, reasoning_score)),
            "confidence_level": float(confidence_level),
            "learning_risks": risks,
            "recommendations": recommendations,
            "remediation": remediation,
        },
    }


@app.post("/api/ai-companion/chat")
def chat_with_companion(request: dict):
    """AI Learning Companion chat endpoint."""
    student_id = request.get("student_id", "")
    chapter_id = request.get("chapter_id", "")
    message = request.get("message", "")

    engine = DNAEngine()
    ai_companion = AICompanion()

    # Get student's latest DNA profile
    db = SessionLocal()
    latest_dna = (
        db.query(DNAProfileDB)
        .filter(
            DNAProfileDB.student_id == student_id,
            DNAProfileDB.chapter_id == chapter_id,
        )
        .order_by(DNAProfileDB.version.desc())
        .first()
    )

    # Also fetch chapter info and questions for AI context
    chapter = db.query(ChapterDB).filter(ChapterDB.id == chapter_id).first() if chapter_id else None
    chapter_topics = []
    chapter_qs = []
    if chapter_id:
        db_qs = (
            db.query(ChapterQuestionsDB)
            .filter(ChapterQuestionsDB.chapter_id == chapter_id, ChapterQuestionsDB.is_active == True)
            .order_by(ChapterQuestionsDB.sort_order)
            .all()
        )
        chapter_qs = [
            {
                "question": q.question_text,
                "concept": q.concept_name or "",
                "explanation": q.explanation or "",
            }
            for q in db_qs
        ]
        if chapter_qs:
            chapter_topics = [q.get("concept", "") for q in chapter_qs if q.get("concept")]

    if not latest_dna:
        explanation = ai_companion.generate_chat_response(message, {
            "strengths": [],
            "gaps": [],
            "chapter_title": chapter.title if chapter else "",
            "chapter_topics": chapter_topics,
            "chapter_questions": chapter_qs[:10],
        })
        db.close()
        return {"response": explanation}

    misconception = None
    if latest_dna.misconceptions_json:
        top_mc = max(
            latest_dna.misconceptions_json, key=lambda x: x.get("confidence", 0)
        )
        misconception = top_mc

    # Generate response
    if "misconception" in message.lower() or "wrong" in message.lower():
        if misconception:
            explanation = ai_companion.generate_explanation(misconception)
            db.close()
            return {"response": explanation}
        else:
            db.close()
            return {"response": "No misconceptions detected. Great job!"}

    if "recommend" in message.lower() or "suggest" in message.lower():
        recommendations = latest_dna.recommendations_json or []
        db.close()
        if recommendations:
            return {
                "response": "Based on your DNA profile, I recommend:\n"
                + "\n".join([f"• {r}" for r in recommendations[:5]])
            }
        else:
            return {"response": "Complete more assessments to get personalized recommendations."}

    if "study" in message.lower() or "plan" in message.lower():
        plan = ai_companion.generate_study_plan(
            {
                "gaps": latest_dna.gaps_json or [],
                "misconceptions": latest_dna.misconceptions_json or [],
            }
        )
        db.close()
        plan_text = "\n".join(
            [f"Day {p['day']}: {p['focus']} - {', '.join(p['activities'])}" for p in plan[:5]]
        )
        return {"response": f"Here's your personalized study plan:\n\n{plan_text}"}

    # Default: free-form AI chat with DNA context
    db.close()
    strengths = latest_dna.strengths_json or []
    gaps = latest_dna.gaps_json or []
    context = {
        "strengths": [s.get("concept", "") for s in strengths[:3]],
        "gaps": [g.get("concept", "") for g in gaps[:3]],
        "chapter_title": chapter.title if chapter else (latest_dna.chapter_title or "this chapter"),
        "chapter_topics": chapter_topics if chapter_topics else [],
        "chapter_questions": chapter_qs[:10] if chapter_qs else [],
    }
    explanation = ai_companion.generate_chat_response(message, context)
    return {"response": explanation}


# --- API: In-Chapter AI Learning Companion (RAG + LLM) ---

SUGGESTED_QUESTIONS = [
    "What are the key concepts in this chapter?",
    "Explain in simple English.",
    "Give me a real-life example.",
    "Why am I weak in this chapter?",
    "Create practice questions.",
    "Summarize this chapter.",
]


@app.get("/api/chapters/{chapter_id}/learning-context")
def get_learning_context(chapter_id: str, student_id: str = ""):
    """Everything the chapter screen needs: content by mode, plus learner DNA."""
    db = SessionLocal()
    try:
        chapter = db.query(ChapterDB).filter(ChapterDB.id == chapter_id).first()
        if not chapter:
            raise HTTPException(status_code=404, detail="Chapter not found")

        contents = (
            db.query(ChapterContentDB)
            .filter(ChapterContentDB.chapter_id == chapter_id, ChapterContentDB.is_active == True)
            .order_by(ChapterContentDB.sort_order)
            .all()
        )
        questions = (
            db.query(ChapterQuestionsDB)
            .filter(ChapterQuestionsDB.chapter_id == chapter_id, ChapterQuestionsDB.is_active == True)
            .order_by(ChapterQuestionsDB.sort_order)
            .all()
        )

        # Group content by mode so the frontend can render document / ppt / video / audio.
        modes = {"document": [], "ppt": [], "video": [], "audio": [], "viva": []}
        for c in contents:
            bucket = modes.setdefault(c.content_type, [])
            bucket.append({
                "id": c.id,
                "title": c.title,
                "type": c.content_type,
                "text": c.content_text or "",
                "url": c.content_url or "",
                "duration": c.duration or "",
                "description": c.description or "",
            })

        dna = None
        if student_id:
            profile = (
                db.query(DNAProfileDB)
                .filter(
                    DNAProfileDB.student_id == student_id,
                    DNAProfileDB.chapter_id == chapter_id,
                )
                .order_by(DNAProfileDB.version.desc())
                .first()
            )
            if profile:
                dna = {
                    "version": profile.version,
                    "overall_score": profile.overall_score,
                    "strengths": profile.strengths_json or [],
                    "gaps": profile.gaps_json or [],
                    "misconceptions": profile.misconceptions_json or [],
                    "recommendations": profile.recommendations_json or [],
                }

        return {
            "chapter": {
                "id": chapter.id,
                "title": chapter.title,
                "subject": chapter.subject,
                "grade": chapter.grade,
                "description": chapter.description or "",
            },
            "modes": modes,
            "question_count": len(questions),
            "dna": dna,
            "suggested_questions": SUGGESTED_QUESTIONS,
        }
    finally:
        db.close()


@app.post("/api/chapters/{chapter_id}/companion")
def chapter_companion(chapter_id: str, request: dict):
    """Chapter-scoped AI companion. RAG: content -> DNA -> assessment -> LLM -> answer."""
    message = (request.get("message") or "").strip()
    student_id = request.get("student_id", "")
    if not message:
        raise HTTPException(status_code=400, detail="message is required")

    db = SessionLocal()
    try:
        chapter = db.query(ChapterDB).filter(ChapterDB.id == chapter_id).first()
        if not chapter:
            raise HTTPException(status_code=404, detail="Chapter not found")

        contents = (
            db.query(ChapterContentDB)
            .filter(ChapterContentDB.chapter_id == chapter_id, ChapterContentDB.is_active == True)
            .order_by(ChapterContentDB.sort_order)
            .all()
        )
        questions = (
            db.query(ChapterQuestionsDB)
            .filter(ChapterQuestionsDB.chapter_id == chapter_id, ChapterQuestionsDB.is_active == True)
            .order_by(ChapterQuestionsDB.sort_order)
            .all()
        )

        retriever = ChapterRetriever(
            chapter={"title": chapter.title, "subject": chapter.subject, "description": chapter.description or ""},
            contents=[
                {"type": c.content_type, "title": c.title, "text": c.content_text or ""}
                for c in contents
            ],
            questions=[
                {"text": q.question_text or "", "answer": q.correct_answer or "",
                 "concept": q.concept_name or "", "explanation": q.explanation or ""}
                for q in questions
            ],
        )

        dna = None
        if student_id:
            profile = (
                db.query(DNAProfileDB)
                .filter(
                    DNAProfileDB.student_id == student_id,
                    DNAProfileDB.chapter_id == chapter_id,
                )
                .order_by(DNAProfileDB.version.desc())
                .first()
            )
            if profile:
                dna = {
                    "overall_score": profile.overall_score,
                    "strengths": profile.strengths_json or [],
                    "gaps": profile.gaps_json or [],
                    "misconceptions": profile.misconceptions_json or [],
                    "recommendations": profile.recommendations_json or [],
                }

        # Assessment insights: concepts this learner actually got wrong.
        assessment = None
        if student_id:
            attempt = (
                db.query(AssessmentDB)
                .filter(
                    AssessmentDB.student_id == student_id,
                    AssessmentDB.chapter_id == chapter_id,
                )
                .order_by(AssessmentDB.created_at.desc())
                .first()
            )
            if attempt and attempt.answers_json:
                wrong = []
                for item in attempt.answers_json:
                    if isinstance(item, dict) and not item.get("is_correct", False):
                        wrong.append({"concept": item.get("concept", ""), "type": item.get("question_type", "")})
                assessment = {"wrong_concepts": wrong, "score": attempt.score}

        intent = detect_intent(message)
        companion = ChapterCompanion()
        context = companion.build_context(retriever, message, intent, dna, assessment)
        reply = companion.answer(message, context)

        return {
            "response": reply,
            "intent": intent,
            "intent_label": INTENT_LABELS.get(intent, INTENT_LABELS["default"]),
            "sources": [
                {"heading": h["heading"], "source": h["source"], "score": h["score"]}
                for h in context["hits"]
            ],
            "used_dna": context["has_dna"],
        }
    finally:
        db.close()


@app.get("/api/dna/trajectory/{student_id}/{chapter_id}")
def get_dna_trajectory(student_id: str, chapter_id: str):
    """Get DNA profile history for improvement visualization."""
    db = SessionLocal()
    profiles = (
        db.query(DNAProfileDB)
        .filter(
            DNAProfileDB.student_id == student_id,
            DNAProfileDB.chapter_id == chapter_id,
        )
        .order_by(DNAProfileDB.version.asc())
        .all()
    )
    db.close()

    trajectory = []
    for p in profiles:
        trajectory.append(
            {
                "version": p.version,
                "overall_score": p.overall_score,
                "reasoning_score": p.reasoning_score,
                "confidence_level": p.confidence_level,
                "misconception_count": len(p.misconceptions_json) if p.misconceptions_json else 0,
                "concept_mastery": p.concept_mastery_json,
            }
        )
    return trajectory


@app.get("/api/dna/concept-trend/{student_id}/{chapter_id}")
def get_concept_trends(student_id: str, chapter_id: str):
    """Get concept mastery trends across attempts."""
    db = SessionLocal()
    profiles = (
        db.query(DNAProfileDB)
        .filter(
            DNAProfileDB.student_id == student_id,
            DNAProfileDB.chapter_id == chapter_id,
        )
        .order_by(DNAProfileDB.version.asc())
        .all()
    )
    db.close()

    # Collect all unique concepts
    all_concepts = {}
    for p in profiles:
        cm = p.concept_mastery_json or {}
        for cid, data in cm.items():
            if cid not in all_concepts:
                all_concepts[cid] = {
                    "concept_name": data.get("concept_name", cid),
                    "scores": [],
                }
            all_concepts[cid]["scores"].append(
                {"version": p.version, "score": data.get("score", 0)}
            )
    return all_concepts


    return all_concepts


# ==================== CHAPTER REPOSITORY / CONTENT MANAGEMENT ====================
# Note: Chapter, content, and question seeding is done in seed_database() above

# --- API: Chapters ---
@app.get("/api/repo/chapters")
def list_chapters():
    db = SessionLocal()
    chapters = db.query(ChapterDB).all()
    result = []
    for c in chapters:
        content_count = db.query(ChapterContentDB).filter(ChapterContentDB.chapter_id == c.id, ChapterContentDB.is_active == True).count()
        q_count = db.query(ChapterQuestionsDB).filter(ChapterQuestionsDB.chapter_id == c.id, ChapterQuestionsDB.is_active == True).count()
        result.append({
            "id": c.id,
            "title": c.title,
            "subject": c.subject,
            "grade": c.grade,
            "description": c.description or "",
            "total_questions": c.total_questions or 0,
            "passing_score": c.passing_score or 70,
            "content_count": content_count,
            "questions_count": q_count,
            "created_at": c.created_at.isoformat() if hasattr(c, 'created_at') and c.created_at else "",
        })
    return result


@app.post("/api/repo/chapters")
def create_chapter(data: dict):
    db = SessionLocal()
    try:
        chapter_id = data.get("id", f"ch-{uuid.uuid4().hex[:8]}")
        chapter = ChapterDB(
            id=chapter_id,
            title=data["title"],
            subject=data.get("subject", ""),
            grade=data.get("grade", ""),
            description=data.get("description", ""),
            total_questions=data.get("totalQuestions", 0),
            passing_score=data.get("passingScore", 70),
        )
        db.add(chapter)
        db.commit()
        return {"id": chapter_id, "message": "Chapter created"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@app.put("/api/repo/chapters/{chapter_id}")
def update_chapter(chapter_id: str, data: dict):
    db = SessionLocal()
    try:
        chapter = db.query(ChapterDB).filter(ChapterDB.id == chapter_id).first()
        if not chapter:
            raise HTTPException(status_code=404, detail="Chapter not found")
        for key, value in data.items():
            if hasattr(chapter, key) and key != "id":
                setattr(chapter, key, value)
        db.commit()
        return {"id": chapter_id, "message": "Chapter updated"}
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@app.delete("/api/repo/chapters/{chapter_id}")
def delete_chapter(chapter_id: str):
    db = SessionLocal()
    try:
        db.query(ChapterContentDB).filter(ChapterContentDB.chapter_id == chapter_id).delete()
        db.query(ChapterQuestionsDB).filter(ChapterQuestionsDB.chapter_id == chapter_id).delete()
        db.query(AssessmentDB).filter(AssessmentDB.chapter_id == chapter_id).delete()
        db.query(DNAProfileDB).filter(DNAProfileDB.chapter_id == chapter_id).delete()
        db.query(ChapterDB).filter(ChapterDB.id == chapter_id).delete()
        db.commit()
        return {"message": "Chapter deleted"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


# --- API: Learner Progress Persistence ---
# Chapter assessments, DNA versions and completed learning modes are stored so a
# learner's journey survives a page refresh. Attempts reuse the existing
# `assessments` and `dna_profiles` tables; remediation modes reuse
# `student_learning_plans` with activity_type='mode'.

RISK_BY_SCORE = {"Low": 0, "Medium": 1, "High": 2}


def _risk_from_score(score: float) -> str:
    if score >= 80:
        return "Low"
    if score >= 50:
        return "Medium"
    return "High"


def _mastery_from_score(score: float) -> float:
    return round(min(100.0, score * 0.7 + 20.0), 2)


@app.post("/api/progress/chapter-assessment")
def record_chapter_assessment(request: dict):
    """Store a chapter assessment attempt and snapshot a new DNA version."""
    student_id = request.get("student_id", "")
    chapter_id = request.get("chapter_id", "")
    if not student_id or not chapter_id:
        raise HTTPException(status_code=400, detail="student_id and chapter_id are required")

    score = float(request.get("score", 0))
    kind = request.get("kind", "assessment")
    correct = int(request.get("correct", 0))
    total = int(request.get("total", 0))
    reasoning = float(request.get("reasoning", 0))
    problem_solving = float(request.get("problemSolving", 0))
    critical_thinking = float(request.get("criticalThinking", 0))
    answers = request.get("answers") or []

    db = SessionLocal()
    try:
        existing = (
            db.query(AssessmentDB)
            .filter(AssessmentDB.student_id == student_id, AssessmentDB.chapter_id == chapter_id)
            .order_by(AssessmentDB.attempt_number.desc())
            .first()
        )
        attempt_number = (existing.attempt_number + 1) if existing else 1
        now = datetime.utcnow()

        record = AssessmentDB(
            id=str(uuid.uuid4()),
            student_id=student_id,
            chapter_id=chapter_id,
            attempt_number=attempt_number,
            score=score,
            date=now,
            answers_json=[
                {
                    "kind": kind,
                    "correct": correct,
                    "total": total,
                    "reasoning": reasoning,
                    "problemSolving": problem_solving,
                    "criticalThinking": critical_thinking,
                    "answers": answers,
                }
            ],
        )
        db.add(record)

        chapter = db.query(ChapterDB).filter(ChapterDB.id == chapter_id).first()
        db.add(
            DNAProfileDB(
                id=str(uuid.uuid4()),
                student_id=student_id,
                chapter_id=chapter_id,
                version=attempt_number,
                overall_score=score,
                concept_mastery_json={
                    "mastery": _mastery_from_score(score),
                    "reasoning": reasoning,
                    "problemSolving": problem_solving,
                    "criticalThinking": critical_thinking,
                    "kind": kind,
                },
                strengths_json=[],
                gaps_json=[],
                misconceptions_json=[],
                reasoning_score=reasoning,
                confidence_level=None,
                learning_risks_json=[{"level": _risk_from_score(score)}],
                recommendations_json=[],
                remediation_json=[],
            )
        )
        db.commit()

        return {
            "saved": True,
            "attempt": attempt_number,
            "chapterId": chapter_id,
            "chapterName": chapter.title if chapter else chapter_id,
            "subject": chapter.subject if chapter else "",
            "score": score,
            "date": now.isoformat(),
        }
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@app.post("/api/progress/mode-complete")
def record_mode_complete(request: dict):
    """Record a completed learning mode, which is the remediation gate for a retest.

    ``completion_percentage`` lets a mode report real consumption rather than a
    single click, e.g. how much of a generated video lesson was actually watched.
    """
    student_id = request.get("student_id", "")
    chapter_id = request.get("chapter_id", "")
    mode = request.get("mode", "")
    if not student_id or not chapter_id or not mode:
        raise HTTPException(status_code=400, detail="student_id, chapter_id and mode are required")

    try:
        percentage = max(0, min(100, int(request.get("completion_percentage", 100))))
    except (TypeError, ValueError):
        percentage = 100
    completed = bool(request.get("completed", True))

    db = SessionLocal()
    try:
        existing = (
            db.query(StudentLearningPlanDB)
            .filter(
                StudentLearningPlanDB.student_id == student_id,
                StudentLearningPlanDB.chapter_id == chapter_id,
                StudentLearningPlanDB.activity_type == "mode",
                StudentLearningPlanDB.title == mode,
            )
            .first()
        )
        if existing:
            existing.completed = completed
            existing.completion_percentage = percentage
        else:
            db.add(
                StudentLearningPlanDB(
                    id=str(uuid.uuid4()),
                    student_id=student_id,
                    chapter_id=chapter_id,
                    activity_type="mode",
                    title=mode,
                    description=f"{mode} learning mode",
                    completed=completed,
                    completion_percentage=percentage,
                )
            )
        db.commit()
        return {
            "saved": True,
            "chapterId": chapter_id,
            "learningMode": mode,
            "completionPercentage": percentage,
            "completed": completed,
        }
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@app.get("/api/progress/{student_id}")
def get_progress(student_id: str):
    """Return the learner's chapter tracking, attempts and DNA evolution."""
    db = SessionLocal()
    try:
        assessments = (
            db.query(AssessmentDB)
            .filter(AssessmentDB.student_id == student_id)
            .order_by(AssessmentDB.created_at.asc())
            .all()
        )
        profiles = (
            db.query(DNAProfileDB)
            .filter(DNAProfileDB.student_id == student_id)
            .order_by(DNAProfileDB.generated_at.asc())
            .all()
        )
        modes = (
            db.query(StudentLearningPlanDB)
            .filter(
                StudentLearningPlanDB.student_id == student_id,
                StudentLearningPlanDB.activity_type == "mode",
            )
            .all()
        )

        chapter_ids = {a.chapter_id for a in assessments} | {p.chapter_id for p in profiles} | {m.chapter_id for m in modes}
        chapters = {
            c.id: c
            for c in db.query(ChapterDB).filter(ChapterDB.id.in_(chapter_ids)).all()
        } if chapter_ids else {}

        # Build the same shape the dashboard uses, keyed by subject + chapter name.
        tracking: Dict[str, Dict[str, Any]] = {}
        for chapter_id in chapter_ids:
            chapter = chapters.get(chapter_id)
            subject = chapter.subject if chapter else ""
            chapter_name = chapter.title if chapter else chapter_id
            tracking[chapter_id] = {
                "chapter_id": chapter_id,
                "chapterName": chapter_name,
                "subject": subject,
                "completedModes": [],
                "modeProgress": {},
                "attempts": [],
                "assessmentCompleted": False,
                "retestCompleted": False,
                "currentVersion": None,
            }

        for mode in modes:
            entry = tracking.get(mode.chapter_id)
            if not entry or not mode.completed:
                continue
            if mode.title not in entry["completedModes"]:
                entry["completedModes"].append(mode.title)
            entry.setdefault("modeProgress", {})[mode.title] = mode.completion_percentage or 100

        for row in assessments:
            entry = tracking.get(row.chapter_id)
            if not entry:
                continue
            meta = (row.answers_json or [{}])[0] if row.answers_json else {}
            mastery = _mastery_from_score(row.score or 0)
            attempt = {
                "kind": meta.get("kind", "assessment"),
                "attempt": row.attempt_number,
                "score": row.score,
                "mastery": mastery,
                "risk": _risk_from_score(row.score or 0),
                "correct": meta.get("correct", 0),
                "total": meta.get("total", 0),
                "date": (row.date or row.created_at).isoformat() if (row.date or row.created_at) else None,
                "reasoning": meta.get("reasoning", 0),
                "problemSolving": meta.get("problemSolving", 0),
                "criticalThinking": meta.get("criticalThinking", 0),
                # Per-question results, so the chapter review survives a refresh.
                "answers": meta.get("answers") or [],
            }
            entry["attempts"].append(attempt)
            entry["assessmentCompleted"] = True
            if row.attempt_number and row.attempt_number >= 2:
                entry["retestCompleted"] = True
            entry["currentVersion"] = {
                "version": row.attempt_number,
                "score": row.score,
                "mastery": mastery,
                "risk": _risk_from_score(row.score or 0),
                "date": attempt["date"],
                "assessmentResult": None,
                "reasoning": attempt["reasoning"],
                "problemSolving": attempt["problemSolving"],
                "criticalThinking": attempt["criticalThinking"],
            }

        # An explicit DNA profile version wins, since it is the generated snapshot.
        for profile in profiles:
            entry = tracking.get(profile.chapter_id)
            if not entry:
                continue
            meta = profile.concept_mastery_json or {}
            entry["currentVersion"] = {
                "version": profile.version,
                "score": profile.overall_score,
                "mastery": meta.get("mastery", _mastery_from_score(profile.overall_score or 0)),
                "risk": _risk_from_score(profile.overall_score or 0),
                "date": profile.generated_at.isoformat() if profile.generated_at else None,
                "assessmentResult": None,
                "reasoning": profile.reasoning_score or meta.get("reasoning", 0),
                "problemSolving": meta.get("problemSolving", 0),
                "criticalThinking": meta.get("criticalThinking", 0),
            }

        evolution = []
        for chapter_id, entry in tracking.items():
            for attempt in entry["attempts"]:
                evolution.append({
                    "chapterId": chapter_id,
                    "chapter": entry["chapterName"],
                    "subject": entry["subject"],
                    "type": "Retest" if attempt["kind"] == "retest" else "Chapter Assessment",
                    "score": attempt["score"],
                    "mastery": attempt["mastery"],
                    "risk": attempt["risk"],
                    "version": attempt["attempt"],
                    "date": attempt["date"],
                })

        return {"chapters": list(tracking.values()), "evolution": evolution}
    finally:
        db.close()


# --- API: Chapter Content ---
@app.get("/api/repo/chapters/{chapter_id}/content")
def get_chapter_content(chapter_id: str):
    db = SessionLocal()
    content = (
        db.query(ChapterContentDB)
        .filter(ChapterContentDB.chapter_id == chapter_id)
        .order_by(ChapterContentDB.sort_order)
        .all()
    )
    return [
        {
            "id": c.id,
            "chapterId": c.chapter_id,
            "title": c.title,
            "contentType": c.content_type,
            "contentUrl": c.content_url or "",
            "contentText": c.content_text or "",
            "duration": c.duration or "",
            "thumbnail": c.thumbnail or "",
            "description": c.description or "",
            "isActive": c.is_active,
            "sortOrder": c.sort_order,
            "createdAt": c.created_at.isoformat() if c.created_at else "",
        }
        for c in content
    ]


@app.post("/api/repo/chapters/{chapter_id}/content")
def add_chapter_content(chapter_id: str, data: dict):
    db = SessionLocal()
    try:
        content = ChapterContentDB(
            id=str(uuid.uuid4()),
            chapter_id=chapter_id,
            title=data["title"],
            content_type=data.get("contentType", "document"),
            content_url=data.get("contentUrl", ""),
            content_text=data.get("contentText", ""),
            duration=data.get("duration", ""),
            thumbnail=data.get("thumbnail", ""),
            description=data.get("description", ""),
            is_active=data.get("isActive", True),
            sort_order=data.get("sortOrder", 0),
            created_at=datetime.utcnow(),
            updated_at=datetime.utcnow(),
        )
        db.add(content)
        db.commit()
        return {"id": content.id, "message": "Content added"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@app.put("/api/repo/content/{content_id}")
def update_content(content_id: str, data: dict):
    db = SessionLocal()
    try:
        content = db.query(ChapterContentDB).filter(ChapterContentDB.id == content_id).first()
        if not content:
            raise HTTPException(status_code=404, detail="Content not found")
        for key, value in data.items():
            attr = key.replace("contentUrl", "content_url").replace("contentText", "content_text").replace("contentType", "content_type").replace("sortOrder", "sort_order").replace("isActive", "is_active")
            if hasattr(content, attr):
                setattr(content, attr, value)
        content.updated_at = datetime.utcnow()
        db.commit()
        return {"id": content_id, "message": "Content updated"}
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@app.delete("/api/repo/content/{content_id}")
def delete_content(content_id: str):
    db = SessionLocal()
    try:
        db.query(ChapterContentDB).filter(ChapterContentDB.id == content_id).delete()
        db.commit()
        return {"message": "Content deleted"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


# --- API: Chapter Questions ---
@app.get("/api/repo/chapters/{chapter_id}/questions")
def get_chapter_questions(chapter_id: str):
    db = SessionLocal()
    questions = (
        db.query(ChapterQuestionsDB)
        .filter(ChapterQuestionsDB.chapter_id == chapter_id, ChapterQuestionsDB.is_active == True)
        .order_by(ChapterQuestionsDB.sort_order)
        .all()
    )
    return [
        {
            "id": q.id,
            "chapter_id": q.chapter_id,
            "questionText": q.question_text,
            "options": q.options_json or [],
            "correctAnswer": q.correct_answer,
            "conceptId": q.concept_id or "",
            "conceptName": q.concept_name or "",
            "difficulty": q.difficulty or "Medium",
            "explanation": q.explanation or "",
            "isActive": q.is_active,
            "sortOrder": q.sort_order,
            "createdAt": q.created_at.isoformat() if q.created_at else "",
        }
        for q in questions
    ]


@app.post("/api/repo/chapters/{chapter_id}/questions")
def add_chapter_question(chapter_id: str, data: dict):
    db = SessionLocal()
    try:
        question = ChapterQuestionsDB(
            id=str(uuid.uuid4()),
            chapter_id=chapter_id,
            question_text=data["questionText"],
            options_json=data.get("options", []),
            correct_answer=data["correctAnswer"],
            concept_id=data.get("conceptId", ""),
            concept_name=data.get("conceptName", ""),
            difficulty=data.get("difficulty", "Medium"),
            explanation=data.get("explanation", ""),
            is_active=data.get("isActive", True),
            sort_order=data.get("sortOrder", 0),
            created_at=datetime.utcnow(),
        )
        db.add(question)
        db.commit()
        return {"id": question.id, "message": "Question added"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@app.put("/api/repo/question/{question_id}")
def update_question(question_id: str, data: dict):
    db = SessionLocal()
    try:
        question = db.query(ChapterQuestionsDB).filter(ChapterQuestionsDB.id == question_id).first()
        if not question:
            raise HTTPException(status_code=404, detail="Question not found")
        question.question_text = data.get("questionText", question.question_text)
        if "options" in data:
            question.options_json = data["options"]
        question.correct_answer = data.get("correctAnswer", question.correct_answer)
        question.concept_id = data.get("conceptId", question.concept_id)
        question.concept_name = data.get("conceptName", question.concept_name)
        question.difficulty = data.get("difficulty", question.difficulty)
        question.explanation = data.get("explanation", question.explanation)
        question.is_active = data.get("isActive", question.is_active)
        question.sort_order = data.get("sortOrder", question.sort_order)
        db.commit()
        return {"id": question_id, "message": "Question updated"}
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@app.delete("/api/repo/question/{question_id}")
def delete_question(question_id: str):
    db = SessionLocal()
    try:
        db.query(ChapterQuestionsDB).filter(ChapterQuestionsDB.id == question_id).delete()
        db.commit()
        return {"message": "Question deleted"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


# --- API: Student Learning Plan ---
@app.get("/api/repo/plans/{student_id}")
def get_student_plans(student_id: str):
    db = SessionLocal()
    plans = (
        db.query(StudentLearningPlanDB)
        .filter(StudentLearningPlanDB.student_id == student_id)
        .order_by(StudentLearningPlanDB.created_at.desc())
        .all()
    )
    return [
        {
            "id": p.id,
            "studentId": p.student_id,
            "chapterId": p.chapter_id,
            "activityType": p.activity_type,
            "title": p.title,
            "description": p.description or "",
            "duration": p.duration or "",
            "completed": p.completed,
            "createdAt": p.created_at.isoformat() if p.created_at else "",
        }
        for p in plans
    ]


@app.post("/api/repo/plans/{student_id}")
def create_student_plan(student_id: str, data: dict):
    db = SessionLocal()
    try:
        plan = StudentLearningPlanDB(
            id=str(uuid.uuid4()),
            student_id=student_id,
            chapter_id=data.get("chapterId", ""),
            activity_type=data["activityType"],
            title=data["title"],
            description=data.get("description", ""),
            duration=data.get("duration", ""),
            completed=False,
            created_at=datetime.utcnow(),
        )
        db.add(plan)
        db.commit()
        return {"id": plan.id, "message": "Plan created"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@app.put("/api/repo/plans/{plan_id}")
def update_plan(plan_id: str, data: dict):
    db = SessionLocal()
    try:
        plan = db.query(StudentLearningPlanDB).filter(StudentLearningPlanDB.id == plan_id).first()
        if not plan:
            raise HTTPException(status_code=404, detail="Plan not found")
        plan.completed = data.get("completed", plan.completed)
        db.commit()
        return {"id": plan_id, "message": "Plan updated"}
    except HTTPException:
        raise
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


@app.delete("/api/repo/plans/{plan_id}")
def delete_plan(plan_id: str):
    db = SessionLocal()
    try:
        db.query(StudentLearningPlanDB).filter(StudentLearningPlanDB.id == plan_id).delete()
        db.commit()
        return {"message": "Plan deleted"}
    except Exception as e:
        db.rollback()
        raise HTTPException(status_code=500, detail=str(e))
    finally:
        db.close()


# Serve frontend static files via middleware (runs before route matching)
# DISABLED: Use Vite dev server on port 5173 instead of serving from backend
# STATIC_DIR = os.path.join(os.path.dirname(os.path.dirname(__file__)), "frontend", "dist")
#
#
# class FrontendMiddleware(BaseHTTPMiddleware):
#     async def dispatch(self, request: Request, call_next):
#         if request.url.path.startswith("/api") or request.url.path.startswith("/docs") or request.url.path.startswith("/openapi.json"):
#             return await call_next(request)
#         file_path = os.path.join(STATIC_DIR, request.url.path.lstrip("/"))
#         if os.path.isfile(file_path):
#             return FileResponse(file_path)
#         return FileResponse(os.path.join(STATIC_DIR, "index.html"))
#
#
# app.add_middleware(FrontendMiddleware)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
