import sqlite3
conn = sqlite3.connect('learning_dna.db')
cursor = conn.execute('SELECT name FROM sqlite_master WHERE type="table"')
tables = [r[0] for r in cursor.fetchall()]
print("Tables:", tables)

for t in tables:
    count = conn.execute(f'SELECT COUNT(*) FROM {t}').scalar()
    print(f"  {t}: {count} rows")

conn.close()
