import numpy as np
from typing import List, Dict, Optional
from datetime import datetime
import re

try:
    import ollama
    OLLAMA_AVAILABLE = True
except ImportError:
    OLLAMA_AVAILABLE = False


# Knowledge graph: concept prerequisites and relationships
CONCEPT_MAP = {
    "addition_no_carry": {
        "name": "No-Carry Addition",
        "prerequisites": [],
        "difficulty": 1,
        "next_concepts": ["addition_carry", "subtraction_no_carry"],
    },
    "addition_carry": {
        "name": "Carry Addition",
        "prerequisites": ["addition_no_carry"],
        "difficulty": 2,
        "next_concepts": ["addition_multi_digit", "subtraction_carry"],
    },
    "subtraction_no_carry": {
        "name": "No-Carry Subtraction",
        "prerequisites": ["addition_no_carry"],
        "difficulty": 1,
        "next_concepts": ["subtraction_carry", "addition_carry"],
    },
    "subtraction_carry": {
        "name": "Carry/Subtract Borrow",
        "prerequisites": ["subtraction_no_carry", "addition_carry"],
        "difficulty": 3,
        "next_concepts": ["multiplication_basic"],
    },
    "multiplication_basic": {
        "name": "Basic Multiplication",
        "prerequisites": ["addition_carry", "subtraction_carry"],
        "difficulty": 2,
        "next_concepts": ["multiplication_multi_digit", "division_basic"],
    },
    "division_basic": {
        "name": "Basic Division",
        "prerequisites": ["multiplication_basic"],
        "difficulty": 2,
        "next_concepts": ["division_remainder"],
    },
    "word_problems": {
        "name": "Word Problem Solving",
        "prerequisites": ["addition_no_carry", "subtraction_no_carry"],
        "difficulty": 4,
        "next_concepts": [],
    },
}


# Common misconception patterns
MISCONCEPTION_PATTERNS = {
    "carry_omission": {
        "type": "carry_omission",
        "description": "Forgets to carry over when sum in a column exceeds 9",
        "indicators": ["answer_off_by_10", "answer_off_by_100", "partial_sum_correct"],
        "severity": "high",
    },
    "sign_confusion": {
        "type": "sign_confusion",
        "description": "Confuses addition and subtraction in mixed operations",
        "indicators": ["added_instead_of_subtracted", "subtracted_instead_of_added"],
        "severity": "medium",
    },
    "place_value_error": {
        "type": "place_value_error",
        "description": "Misunderstands place value in multi-digit numbers",
        "indicators": ["treated_tens_as_ones", "dropped_zero"],
        "severity": "high",
    },
    "rote_memorization": {
        "type": "rote_memorization",
        "description": "Memorized answers without understanding the concept",
        "indicators": ["correct_simple_wrong_complex", "cannot_explain_steps"],
        "severity": "medium",
    },
    "guessing_pattern": {
        "type": "guessing_pattern",
        "description": "Guessing answers without showing work or reasoning",
        "indicators": ["no_steps_shown", "answer_random_offset"],
        "severity": "low",
    },
}


class DNAEngine:
    """Core DNA generation engine. Analyzes responses and builds Learner DNA profile."""

    def __init__(self):
        self.concept_map = CONCEPT_MAP

    def analyze_responses(self, answers: List[Dict]) -> Dict:
        """Analyze all responses and generate concept-level mastery scores."""
        concept_results = {}

        for answer in answers:
            concept_id = answer.get("concept_id", "unknown")
            is_correct = answer.get("is_correct", False)
            student_answer = answer.get("student_answer", "")
            correct_answer = answer.get("correct_answer", "")
            question_text = answer.get("question_text", "")

            if concept_id not in concept_results:
                concept_results[concept_id] = {
                    "concept_name": self.concept_map.get(
                        concept_id, {}
                    ).get("name", concept_id),
                    "total": 0,
                    "correct": 0,
                    "errors": [],
                }

            concept_results[concept_id]["total"] += 1
            if is_correct:
                concept_results[concept_id]["correct"] += 1
            else:
                concept_results[concept_id]["errors"].append(
                    {"question": question_text, "student_answer": student_answer}
                )

        mastery_scores = {}
        for concept_id, data in concept_results.items():
            score = (data["correct"] / data["total"]) * 100 if data["total"] > 0 else 0
            mastery_scores[concept_id] = {
                **data,
                "score": round(score, 1),
                "proficiency": self._get_proficiency(score),
            }

        return mastery_scores

    def _get_proficiency(self, score: float) -> str:
        if score >= 90:
            return "excellent"
        elif score >= 75:
            return "good"
        elif score >= 50:
            return "developing"
        else:
            return "emerging"

    def detect_misconceptions(self, answers: List[Dict], mastery: Dict) -> List[Dict]:
        """Detect learning misconceptions from response patterns."""
        misconceptions = []

        # Pattern-based detection
        for answer in answers:
            if not answer.get("is_correct", False):
                detected = self._detect_from_answer(answer)
                if detected:
                    misconceptions.append(detected)

        # Aggregate similar misconceptions
        misconceptions = self._aggregate_misconceptions(misconceptions)

        # Also check mastery patterns for hidden misconceptions
        hidden = self._detect_hidden_misconceptions(mastery, answers)
        misconceptions.extend(hidden)

        return misconceptions

    def _detect_from_answer(self, answer: Dict) -> Optional[Dict]:
        """Detect misconception from individual wrong answer."""
        question = answer.get("question_text", "").lower()
        student_answer = str(answer.get("student_answer", "")).lower()
        correct_answer = str(answer.get("correct_answer", "")).lower()
        concept = answer.get("concept_id", "")

        # Carry omission detection
        if "addition" in concept and "carry" in concept:
            if self._is_carry_question(question):
                student_num = self._extract_answer(student_answer)
                correct_num = self._extract_answer(correct_answer)
                if student_num and correct_num and abs(student_num - correct_num) % 10 == 0:
                    return {
                        "type": "carry_omission",
                        "description": "Likely forgot to carry over in tens column",
                        "evidence": f"Expected {correct_answer}, got {student_answer} (off by {abs(student_num - correct_num)}) on carry addition",
                        "frequency": 1,
                        "confidence": 0.85,
                        "corrected_concept": "When a column sum exceeds 9, carry the tens digit to the next column",
                        "resolution": "Practice carry addition with visual base-10 blocks",
                    }

        # Sign confusion
        if "subtract" in question or "minus" in question:
            expected_operation = "subtract"
            student_num = self._extract_answer(student_answer)
            correct_num = self._extract_answer(correct_answer)
            if student_num and correct_num:
                parts = re.findall(r"\d+", question)
                if len(parts) >= 2:
                    n1, n2 = int(parts[0]), int(parts[1])
                    if student_num == n1 + n2:
                        return {
                            "type": "sign_confusion",
                            "description": "May have added instead of subtracted",
                            "evidence": f"Expected {correct_answer}, got {student_answer} (which equals {n1}+{n2})",
                            "frequency": 1,
                            "confidence": 0.7,
                            "corrected_concept": "Subtraction means taking away, not combining",
                            "resolution": "Practice distinguishing addition vs subtraction word problems",
                        }

        # Place value error
        if self._extract_answer(student_answer) and self._extract_answer(correct_answer):
            student_num = self._extract_answer(student_answer)
            correct_num = self._extract_answer(correct_answer)
            if (
                student_num
                and correct_num
                and len(str(student_num)) != len(str(correct_num))
            ):
                return {
                    "type": "place_value_error",
                    "description": "Misunderstands place value in multi-digit numbers",
                    "evidence": f"Got {student_answer} instead of {correct_answer} - different digit count suggests place value confusion",
                    "frequency": 1,
                    "confidence": 0.6,
                    "corrected_concept": "Each digit position has a different value (ones, tens, hundreds)",
                    "resolution": "Use place value charts to visualize digit positions",
                }

        return None

    def _detect_hidden_misconceptions(self, mastery: Dict, answers: List[Dict]) -> List[Dict]:
        """Detect misconceptions from overall performance patterns."""
        hidden = []

        for concept_id, data in mastery.items():
            if data["score"] >= 75:
                concept_answers = [
                    a for a in answers if a.get("concept_id") == concept_id
                ]
                simple_correct = sum(
                    1
                    for a in concept_answers
                    if a.get("is_correct")
                    and self._is_simple_question(a.get("question_text", ""))
                )
                complex_wrong = sum(
                    1
                    for a in concept_answers
                    if not a.get("is_correct")
                    and not self._is_simple_question(a.get("question_text", ""))
                )
                if simple_correct >= 2 and complex_wrong >= 1:
                    hidden.append(
                        {
                            "type": "rote_memorization",
                            "description": f"May be memorizing rather than understanding {data['concept_name']}",
                            "evidence": f"Consistently correct on simple {concept_id} problems but struggles with complex ones",
                            "frequency": complex_wrong,
                            "confidence": 0.65,
                            "corrected_concept": f"Focus on understanding the {data['concept_name']} concept, not just answers",
                            "resolution": f"Explain your reasoning for each {data['concept_name']} problem",
                        }
                    )

        unanswered = [
            a
            for a in answers
            if not a.get("student_answer", "").strip()
            and a.get("student_answer", "").strip() == ""
        ]
        if len(unanswered) >= 2:
            hidden.append(
                {
                    "type": "guessing_pattern",
                    "description": "May be guessing rather than solving",
                    "evidence": f" {len(unanswered)} unanswered questions detected",
                    "frequency": len(unanswered),
                    "confidence": 0.5,
                    "corrected_concept": "Always attempt every question, even with partial work",
                    "resolution": "Show at least some work for each problem",
                }
            )

        return hidden

    def _aggregate_misconceptions(self, misconceptions: List[Dict]) -> List[Dict]:
        """Group and count similar misconceptions."""
        aggregated = {}
        for m in misconceptions:
            key = m["type"]
            if key in aggregated:
                aggregated[key]["frequency"] += m["frequency"]
                aggregated[key]["confidence"] = min(
                    1.0, aggregated[key]["confidence"] + 0.1
                )
            else:
                aggregated[key] = m.copy()

        return [
            m
            for m in aggregated.values()
            if m["confidence"] >= 0.6 or m["frequency"] >= 2
        ]

    def identify_strengths_and_gaps(
        self, mastery: Dict, prev_mastery: Optional[Dict] = None
    ) -> Dict:
        """Identify student strengths and learning gaps."""
        strengths = []
        gaps = []

        for concept_id, data in mastery.items():
            score = data["score"]
            name = data["concept_name"]

            trend = "stable"
            if prev_mastery and concept_id in prev_mastery:
                prev_score = prev_mastery[concept_id]["score"]
                if score > prev_score + 5:
                    trend = "improving"
                    strengths.append(
                        {
                            "concept": name,
                            "score": score,
                            "improvement": round(score - prev_score, 1),
                        }
                    )
                elif score < prev_score - 5:
                    trend = "declining"
                    gaps.append(
                        {
                            "concept": name,
                            "score": score,
                            "decline": round(prev_score - score, 1),
                        }
                    )

            if score >= 75:
                if trend != "improving":
                    strengths.append(
                        {"concept": name, "score": score, "improvement": None}
                    )
            elif score < 50:
                if trend != "declining":
                    gaps.append(
                        {"concept": name, "score": score, "decline": None}
                    )

        return {"strengths": strengths, "gaps": gaps}

    def generate_recommendations(
        self,
        mastery: Dict,
        misconceptions: List[Dict],
        strengths: Dict,
        gaps: Dict,
    ) -> List[str]:
        """Generate personalized learning recommendations."""
        recommendations = []

        for mc in misconceptions:
            if mc["confidence"] >= 0.7:
                recommendations.append(
                    f"CRITICAL: Address '{mc['type']}' misconception - {mc['description']}"
                )

        for gap in gaps.get("gaps", []):
            recommendations.append(
                f"Focus on improving {gap['concept']} (currently at {gap['score']}%)"
            )

        weak = [
            (concept_id, c)
            for concept_id, c in mastery.items()
            if c["score"] >= 50 and c["score"] < 75
        ]
        for concept_id, c in weak:
            recommendations.append(
                f"Practice {c.get('concept_name', concept_id)} to move from developing to proficient"
            )

        for s in strengths.get("strengths", []):
            recommendations.append(
                f"Use your strong {s['concept']} skills to help with related topics"
            )

        concepts_by_score = sorted(mastery.items(), key=lambda x: x[1]["score"])
        if concepts_by_score:
            weakest = concepts_by_score[0]
            if weakest[0] in self.concept_map:
                next_concepts = self.concept_map[weakest[0]].get(
                    "next_concepts", []
                )
                if next_concepts:
                    recommendations.append(
                        f"Prerequisite for next chapter: Master {self.concept_map[next_concepts[0]]['name']}"
                    )

        return recommendations

    def generate_remediation_activities(
        self, misconceptions: List[Dict], gaps: Dict
    ) -> List[Dict]:
        """Generate specific remediation activities."""
        activities = []
        activity_types = [
            {"type": "video", "duration": "5-10 min", "icon": "📖"},
            {"type": "practice", "count": 10, "icon": "📝"},
            {"type": "interactive", "icon": "🎯"},
            {"type": "reassessment", "icon": "🔄"},
        ]

        for mc in misconceptions:
            for at in activity_types[:3]:
                activities.append(
                    {
                        **at,
                        "target": mc["type"],
                        "description": f"{mc['type'].replace('_', ' ').title()} - {mc['description']}",
                    }
                )

        for gap in gaps.get("gaps", []):
            activities.append(
                {
                    "type": "practice",
                    "count": 15,
                    "icon": "📝",
                    "target": gap["concept"],
                    "description": f"15 targeted problems on {gap['concept']}",
                }
            )

        return activities

    def calculate_learning_risks(
        self, mastery: Dict, misconceptions: List[Dict], answers: List[Dict]
    ) -> List[str]:
        """Identify learning risks."""
        risks = []

        avg_score = np.mean([m["score"] for m in mastery.values()])
        if avg_score < 50:
            risks.append(
                "Overall performance below 50% - immediate intervention recommended"
            )

        high_confidence_mcs = [m for m in misconceptions if m["confidence"] >= 0.7]
        if len(high_confidence_mcs) >= 2:
            risks.append(
                f"Multiple persistent misconceptions detected ({len(high_confidence_mcs)})"
            )

        for concept_id in mastery:
            if concept_id in self.concept_map:
                prereqs = self.concept_map[concept_id].get("prerequisites", [])
                for prereq in prereqs:
                    if prereq in mastery and mastery[prereq]["score"] < 50:
                        prereq_name = self.concept_map[prereq]["name"]
                        concept_name = self.concept_map[concept_id]["name"]
                        risks.append(
                            f"Prerequisite gap: {prereq_name} ({mastery[prereq]['score']}%) blocks understanding of {concept_name}"
                        )

        unanswered = [a for a in answers if not a.get("student_answer", "").strip()]
        if len(unanswered) > len(answers) * 0.3:
            risks.append("High number of unanswered questions - possible disengagement")

        return risks

    def _is_carry_question(self, question: str) -> bool:
        numbers = re.findall(r"\d+", question)
        if len(numbers) >= 2:
            try:
                nums = [int(n) for n in numbers]
                for n in nums:
                    if n >= 10:
                        str_n = str(n)
                        if len(str_n) >= 2:
                            for i, d in enumerate(str_n):
                                if int(d) > 0:
                                    return True
            except (ValueError, IndexError):
                pass
        return False

    def _is_simple_question(self, question: str) -> bool:
        numbers = re.findall(r"\d+", question)
        if len(numbers) >= 2:
            try:
                nums = [int(n) for n in numbers]
                return all(n < 10 for n in nums)
            except ValueError:
                pass
        return False

    def _extract_answer(self, text: str) -> Optional[int]:
        text = text.strip()
        try:
            return int(text)
        except ValueError:
            numbers = re.findall(r"\d+", text)
            if numbers:
                return int(numbers[-1])
        return None

    def get_prerequisite_chain(self, concept_id: str) -> List[str]:
        chain = []
        visited = set()
        current = concept_id

        while current in self.concept_map and current not in visited:
            visited.add(current)
            prereqs = self.concept_map[current].get("prerequisites", [])
            if prereqs:
                chain.extend(prereqs)
                current = prereqs[0]
            else:
                break

        return [
            self.concept_map[c]["name"]
            for c in chain
            if c in self.concept_map
        ]


class AICompanion:
    """AI Learning Companion for personalized explanations."""

    def __init__(self):
        self.client = None
        self.available_model = None
        if OLLAMA_AVAILABLE:
            try:
                self.client = ollama
                models = self.client.list()
                available = [m.get("name", "") for m in models.get("models", [])]
                # Pick best available model
                for candidate in ["llama3.2", "llama3", "llama", "mistral", "gemma"]:
                    for m in available:
                        if candidate in m:
                            self.available_model = m
                            break
                    if self.available_model:
                        break
                if not self.available_model and available:
                    self.available_model = available[0].split(":")[0]
                if not self.available_model:
                    self.available_model = "llama3.2"
            except Exception:
                self.client = None

    def generate_explanation(
        self, misconception: Dict, student_level: str = "grade_3"
    ) -> str:
        if not self.client:
            return self._offline_explanation(misconception)

        prompt = f"""You are an expert {student_level} math teacher. A student has the following misconception:

Type: {misconception['type']}
Description: {misconception['description']}
Evidence: {misconception['evidence']}
Correct Concept: {misconception['corrected_concept']}

Explain this misconception in simple, encouraging terms. Use a concrete example. 
Keep it under 150 words. Be supportive and clear."""

        try:
            response = self.client.chat(
                model=self.available_model or "llama3.2",
                messages=[{"role": "user", "content": prompt}],
                options={"temperature": 0.7},
            )
            return response["message"]["content"]
        except Exception as e:
            print(f"[AICompanion] Ollama chat failed: {e}. Using fallback explanation.")
            return self._offline_explanation(misconception)

    def _offline_explanation(self, misconception: Dict) -> str:
        mc = misconception
        explanations = {
            "carry_omission": f"""You often forget to carry over when a column adds up to 10 or more. 

Example: In 57 + 34:
  7 + 4 = 11 (write 1, carry the 1)
  5 + 3 + 1(carry) = 9
  Answer: 91

Tip: Always check if any column adds to 10 or more!""",
            "sign_confusion": f"""You sometimes mix up when to add and when to subtract.

Remember: Addition combines numbers. Subtraction takes away.

Tip: Look for keywords: 'total', 'sum', 'altogether' = add. 'left', 'fewer', 'difference' = subtract.""",
            "place_value_error": f"""You sometimes confuse the value of digits based on their position.

In 347:
  7 is in ones place = 7
  4 is in tens place = 40
  3 is in hundreds place = 300

Tip: Use a place value chart to keep track!""",
            "rote_memorization": f"""You may have memorized answers without fully understanding the concept.

To truly understand, always ask:
1. What is this problem asking?
2. What steps do I need?
3. Does my answer make sense?

Tip: Explain your reasoning out loud after solving.""",
            "guessing_pattern": f"""Try to always show your work, even for simple problems.

When you show steps:
1. Write down what you know
2. Plan your approach
3. Solve step by step
4. Check your answer

Tip: Partial work earns partial credit and helps you learn!""",
        }
        return explanations.get(mc["type"], mc["description"] + "\n\nFocus on understanding the concept, not just the answer.")

    def generate_chat_response(
        self, message: str, context: Dict
    ) -> str:
        if not self.client:
            return self._offline_chat_response(message, context)

        student_level = "grade_3"
        chapter_title = context.get('chapter_title', 'a topic')
        chapter_topics = context.get('chapter_topics', [])
        chapter_questions = context.get('chapter_questions', [])

        topic_str = ""
        if chapter_topics:
            topic_str = f"- This chapter covers: {', '.join(chapter_topics)}\n"

        question_str = ""
        if chapter_questions:
            sample_qs = chapter_questions[:5]
            question_str = "\nChapter questions (for reference):\n" + "\n".join(
                [f"• {q.get('question', '')} [concept: {q.get('concept', 'N/A')}] "
                 f"({q.get('explanation', '')[:80]})" for q in sample_qs]
            )

        prompt = f"""You are a friendly, encouraging teacher for {student_level} students.

Student context:
- Strong in: {context.get('strengths', [])}
- Needs help with: {context.get('gaps', [])}
- Currently studying: {chapter_title}
{topic_str}
{question_str}

Student question: {message}

Rules:
1. Answer the student's question clearly and simply.
2. If the question relates to their current chapter, use the chapter topics and questions above to give a relevant answer.
3. If it's a general question (like current events), politely redirect to their studies.
4. Connect to their strengths if possible.
5. Keep the answer under 200 words. Be supportive and educational."""

        try:
            response = self.client.chat(
                model=self.available_model or "llama3.2",
                messages=[{"role": "user", "content": prompt}],
                options={"temperature": 0.7},
            )
            return response["message"]["content"]
        except Exception as e:
            print(f"[AICompanion] Chat failed: {e}. Using fallback.")
            return self._offline_chat_response(message, context)

    def _offline_chat_response(self, message: str, context: Dict) -> str:
        lower = message.lower()
        if "who is" in lower or "prime minister" in lower or "president" in lower:
            return "I'm designed to help you with your current studies! Let me answer your question: I don't have real-time info on current events. But you can look it up online or ask your teacher. For now, let's focus on the topics you're learning about."
        return f"Hi! Based on your profile, you're strong in {', '.join(context.get('strengths', []))} and need work on {', '.join(context.get('gaps', []))}. I'm here to help with your studies. What would you like to learn about?"

    def generate_study_plan(
        self, dna_profile: Dict, days_available: int = 7
    ) -> List[Dict]:
        plan = []
        gaps = dna_profile.get("gaps", [])
        misconceptions = dna_profile.get("misconceptions", [])

        for i, gap in enumerate(gaps[:3]):
            day = (i * (days_available // 3)) + 1
            plan.append(
                {
                    "day": day,
                    "focus": gap["concept"],
                    "activities": [
                        f"Review {gap['concept']} concepts",
                        f"Complete 15 practice problems",
                        "Take a short self-test",
                    ],
                    "target_score": 75,
                }
            )

        for i, mc in enumerate(misconceptions[:2]):
            day = ((i + 1) * (days_available // 3)) + 1
            plan.append(
                {
                    "day": day,
                    "focus": mc["type"].replace("_", " ").title(),
                    "activities": [
                        f"Watch remediation video",
                        f"Practice with guided examples",
                        "Complete misconception quiz",
                    ],
                    "target_score": None,
                }
            )

        return plan if plan else [{"day": 1, "focus": "General review", "activities": ["Review all concepts", "Take practice test"], "target_score": 80}]
