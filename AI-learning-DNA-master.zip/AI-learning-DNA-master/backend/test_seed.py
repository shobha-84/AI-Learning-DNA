import sys
sys.path.insert(0, '.')
import main
import sqlite3

conn = sqlite3.connect('learning_dna.db')
tables = [r[0] for r in conn.execute("SELECT name FROM sqlite_master WHERE type='table'")]
print("Tables:", tables)

for t in tables:
    count = conn.execute(f'SELECT COUNT(*) FROM {t}').fetchone()[0]
    print(f"  {t}: {count} rows")

conn.close()
