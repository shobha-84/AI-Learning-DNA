# Content Repository Seed Data
# Subjects: Mathematics, Science
# Chapters with Document Content, PPT Slides, Video Metadata, Assessment Questions

SUBJECTS = ["Mathematics", "Science"]

# ============================================================
# MATHEMATICS
# ============================================================

SEED_CHAPTERS = [
    {
        "id": "math-fractions",
        "title": "Fractions",
        "subject": "Mathematics",
        "grade": "Class 6-8",
        "description": "Learn about fractions, equivalent fractions, addition, and comparison of fractions.",
        "passing_score": 50,
        "document_content": """# Introduction to Fractions

A fraction represents a part of a whole. It consists of two parts:
- **Numerator** (top number): how many parts we have
- **Denominator** (bottom number): how many equal parts the whole is divided into

## Examples:
- 1/2 means 1 part out of 2 equal parts
- 3/4 means 3 parts out of 4 equal parts
- 2/5 means 2 parts out of 5 equal parts

## Types of Fractions:
1. **Proper Fractions**: Numerator < Denominator (e.g., 3/5, 1/4)
2. **Improper Fractions**: Numerator > Denominator (e.g., 7/3, 5/2)
3. **Mixed Numbers**: A whole number and a fraction combined (e.g., 1 ½, 2 ¾)

---

## Equivalent Fractions

Equivalent fractions are fractions that represent the same value, even though they look different.

### How to Find Equivalent Fractions:
Multiply or divide both the numerator and denominator by the same number.

### Examples:
- 1/2 = 2/4 = 3/6 = 4/8 (all equal one half)
- 2/3 = 4/6 = 6/9 = 8/12 (all equal two thirds)
- 3/4 = 6/8 = 9/12 = 12/16 (all equal three quarters)

### Simplifying Fractions:
To simplify, divide both numerator and denominator by their Greatest Common Divisor (GCD).
- 6/8 = 3/4 (divided both by 2)
- 10/15 = 2/3 (divided both by 5)
- 12/20 = 3/5 (divided both by 4)

---

## Fraction Addition

### Adding Fractions with Same Denominator:
Simply add the numerators. Keep the denominator the same.

**Example:** 1/5 + 2/5 = 3/5

### Adding Fractions with Different Denominators:
1. Find the Least Common Multiple (LCM) of the denominators
2. Convert each fraction to an equivalent fraction with the LCM as denominator
3. Add the numerators

**Example:** 1/3 + 1/4
- LCM of 3 and 4 = 12
- 1/3 = 4/12, 1/4 = 3/12
- 4/12 + 3/12 = 7/12

---

## Fraction Comparison

### Comparing Fractions with Same Denominator:
The fraction with the larger numerator is greater.
- 3/5 > 2/5
- 7/8 > 5/8

### Comparing Fractions with Different Denominators:
Method 1: Convert to equivalent fractions with common denominators
Method 2: Cross-multiply

**Cross-Multiply Method:**
Compare a/b and c/d:
- If a × d > b × c, then a/b > c/d
- If a × d < b × c, then a/b < c/d

**Example:** Compare 2/3 and 3/5
- 2 × 5 = 10
- 3 × 3 = 9
- 10 > 9, so 2/3 > 3/5

---

## Summary

- Fractions represent parts of a whole
- Equivalent fractions have the same value with different numerators and denominators
- To add fractions, find a common denominator
- Compare fractions by converting to common denominators or cross-multiplying
- Simplify fractions by dividing both parts by their GCD""",
        "ppt_slides": [
            {
                "title": "Introduction to Fractions",
                "content": """ What is a Fraction?
- Part of a whole
- Numerator (top) and Denominator (bottom)
- Example: 3/4 = 3 parts out of 4 equal parts
- Visual: Pizza cut into 4 slices, 3 eaten

Types of Fractions
- Proper Fractions: numerator < denominator (1/2, 3/5)
- Improper Fractions: numerator > denominator (5/3, 7/4)
- Mixed Numbers: whole number + fraction (2 ½)

Equivalent Fractions
- Same value, different form
- 1/2 = 2/4 = 3/6 = 4/8
- Multiply/divide top and bottom by same number

Fraction Addition
- Same denominator: add numerators directly
- Different denominator: find common denominator first
- Example: 1/3 + 1/4 = 4/12 + 3/12 = 7/12
Summary & Practice
- Fractions = parts of a whole
- Find equivalents by scaling
- Add with common denominators
- Practice problems included""",
            },
            {
                "title": "Equivalent Fractions",
                "content": """What Are Equivalent Fractions?
- Different looking, same value
- 1/2 = 2/4 = 3/6
- Created by multiplying/dividing by same number

Finding Equivalent Fractions
- Multiply numerator and denominator
- Example: 2/3 = (2×2)/(3×2) = 4/6

Simplifying Fractions
- Divide by GCD
- 8/12 = 2/3 (divided by 4)
- 10/15 = 2/3 (divided by 5)

 Visual Proof
- Pie charts showing same fraction
- Number line with equivalent positions
- Bar models with equal parts

Practice Problems
- Find 2 equivalents of 3/5
- Simplify 6/8
- Which are equivalent: 2/3, 4/6, 5/8?""",
            },
            {
                "title": "Fraction Addition",
                "content": """ Adding Same Denominators
- Simply add numerators
- 2/7 + 3/7 = 5/7
- Keep denominator the same

Adding Different Denominators
- Step 1: Find LCM of denominators
- Step 2: Convert fractions
- Step 3: Add numerators

 Worked Example
- 1/4 + 2/3
- LCM of 4 and 3 = 12
- 1/4 = 3/12, 2/3 = 8/12
- Answer: 11/12

 More Examples
- 1/3 + 1/6 = 2/6 + 1/6 = 3/6 = 1/2
- 2/5 + 1/10 = 4/10 + 1/10 = 5/10 = 1/2

Practice Problems
- 1/5 + 2/5 = ?
- 1/6 + 1/3 = ?
- 3/8 + 1/4 = ?""",
            },
            {
                "title": "Fraction Comparison",
                "content": """Slide 1: Comparing Same Denominators
- Larger numerator = larger fraction
- 3/5 > 2/5
- 7/10 > 4/10

 Comparing Different Denominators
- Method 1: Common denominators
- Method 2: Cross-multiply

 Cross-Multiply Method
- Compare a/b and c/d
- If a×d > b×c, then a/b > c/d
- Example: 2/3 vs 3/5 → 10 > 9 → 2/3 is larger

Visual Comparison
- Bar models side by side
- Number line positioning
- Pizza comparisons

 Practice Problems
- Which is larger: 3/4 or 2/3?
- Which is smaller: 5/8 or 3/5?
- Arrange in order: 1/2, 2/3, 1/4""",
            },
            {
                "title": "Summary & Review",
                "content": """ Key Concepts Review
- Fractions = parts of a whole
- Numerator/denominator
- Types: proper, improper, mixed

 Equivalent Fractions
- Same value, different representation
- Multiply/divide both parts equally
- Simplify by dividing by GCD

 Operations
- Addition: find common denominator
- Comparison: cross-multiply or common denominator
 Common Mistakes
- Forgetting common denominator
- Not simplifying final answer
- Adding denominators (wrong!)

Test Yourself
- 5 review questions
- Answer key provided
- Next: Practice exercises""",
            },
        ],
        "video": {
            "title": "Fractions Basics",
            "duration": "5 minutes",
            "url": "https://example.com/videos/fractions-basics",
            "description": "Comprehensive introduction to fractions covering parts of whole, equivalent fractions, addition, and comparison.",
        },
        "questions": [
            {
                "id": "fra-q1",
                "question": "What fraction of the shape is shaded if 3 out of 8 equal parts are shaded?",
                "options": ["3/8", "8/3", "5/8", "3/5"],
                "correctAnswer": "3/8",
                "concept_id": "fraction_basics",
                "concept_name": "Fraction Basics",
                "difficulty": "Easy",
            },
            {
                "id": "fra-q2",
                "question": "Which fraction is equivalent to 2/3?",
                "options": ["4/6", "2/5", "3/4", "6/8"],
                "correctAnswer": "4/6",
                "concept_id": "equivalent_fractions",
                "concept_name": "Equivalent Fractions",
                "difficulty": "Medium",
            },
            {
                "id": "fra-q3",
                "question": "What is 1/4 + 1/4?",
                "options": ["2/4", "1/8", "2/8", "1/2"],
                "correctAnswer": "2/4",
                "concept_id": "fraction_addition",
                "concept_name": "Fraction Addition",
                "difficulty": "Easy",
            },
            {
                "id": "fra-q4",
                "question": "Which is larger: 2/3 or 3/5?",
                "options": ["2/3", "3/5", "They are equal", "Cannot compare"],
                "correctAnswer": "2/3",
                "concept_id": "fraction_comparison",
                "concept_name": "Fraction Comparison",
                "difficulty": "Medium",
            },
            {
                "id": "fra-q5",
                "question": "Simplify the fraction 6/9.",
                "options": ["2/3", "3/4", "1/3", "6/9"],
                "correctAnswer": "2/3",
                "concept_id": "simplifying_fractions",
                "concept_name": "Simplifying Fractions",
                "difficulty": "Medium",
            },
        ],
    },
    {
        "id": "math-algebra",
        "title": "Algebra",
        "subject": "Mathematics",
        "grade": "Class 6-8",
        "description": "Introduction to variables, algebraic expressions, and solving simple equations.",
        "passing_score": 50,
        "document_content": """# Introduction to Variables

A **variable** is a letter (usually x, y, or z) that represents an unknown number.

## Why Use Variables?
- To represent unknown values in problems
- To write general rules and formulas
- To express relationships between quantities

### Example:
If I have x apples and you have 3 more than me, you have (x + 3) apples.

---

## Algebraic Expressions

An **algebraic expression** combines numbers, variables, and operations.

### Components:
- **Terms**: parts separated by + or -
- **Coefficients**: numbers multiplied by variables
- **Constants**: numbers without variables

### Examples:
- 3x + 5 → coefficient = 3, constant = 5
- 2a - 7b + 4 → three terms
- y → coefficient = 1 (hidden)

### Writing Expressions from Words:
- "5 more than a number" → n + 5
- "twice a number" → 2n
- "3 less than half a number" → n/2 - 3

---

## Simple Equations

An **equation** states that two expressions are equal. Solving means finding the value of the variable.

### One-Step Equations:
- x + 5 = 12 → x = 7 (subtract 5 from both sides)
- 3x = 15 → x = 5 (divide both sides by 3)
- x - 4 = 9 → x = 13 (add 4 to both sides)
- x/2 = 6 → x = 12 (multiply both sides by 2)

### Two-Step Equations:
- 2x + 3 = 11 → 2x = 8 → x = 4
- 5x - 7 = 18 → 5x = 25 → x = 5
- 3(x + 2) = 15 → 3x + 6 = 15 → 3x = 9 → x = 3

### Checking Your Answer:
Substitute your answer back into the original equation.
- If 2x + 3 = 11 and x = 4: 2(4) + 3 = 8 + 3 = 11 ✓

---

## Summary

- Variables represent unknown numbers
- Algebraic expressions combine variables, numbers, and operations
- Solve equations by doing the same thing to both sides
- Always check your solution!""",
        "ppt_slides": [
            {
                "title": "Introduction to Variables",
                "content": """What is a Variable?
- Letter representing unknown number
- Common variables: x, y, z, n
- Example: x = ? in equation 2x = 10

 Real-World Examples
- Age: If I'm x years old, you're (x+3)
- Money: If I have $x, you have 2x
- Distance: If car travels x km/h

 Understanding Variables
- x can be different numbers
- Same letter = same value
- Different letters = can be different

 Writing Variable Expressions
- "3 more than x" → x + 3
- "twice y" → 2y
- "half of z" → z/2

 Practice
- If apples = a, write: 4 times apples
- If price = p, write: price minus 5
- Translate: "5 less than a number"
- Answer key provided""",
            },
            {
                "title": "Algebraic Expressions",
                "content": """Parts of Expressions
- Terms separated by + or -
- Coefficient: number with variable
- Constant: plain number

Identifying Parts
- 4x + 7 → coefficient: 4, constant: 7
- 3a - 2b + 5 → three terms

Writing Expressions
- Words → Math symbols
- "5 added to p" → p + 5
- "q multiplied by 3" → 3q

 Simplifying Expressions
- Combine like terms
- 3x + 2x = 5x
- 4a + 3b stays 4a + 3b

Practice Problems
- Identify parts: 6y - 8
- Write: "one-third of m"
- Simplify: 2a + 3a + 1""",
            },
            {
                "title": "Solving Simple Equations",
                "content": """ What Does Solve Mean?
- Find the value of the variable
- Make the variable stand alone
- Balance both sides

 One-Step Equations
- Addition: x + 5 = 12, x = 7
- Subtraction: x - 3 = 8, x = 11
- Multiplication: 4x = 20, x = 5
- Division: x/3 = 4, x = 12

 Two-Step Equations
- Undo addition/subtraction first
- Then undo multiplication/division
- 2x + 3 = 11 → x = 4

 Checking Solutions
- Plug answer back in
- Both sides should be equal
- Example: x = 4 in 2x+3=11: 8+3=11 ✓

Practice Problems
- Solve and check: x + 8 = 15
- Solve: 5x = 25
- Solve: 3x - 2 = 10""",
            },
            {
                "title": "Equation Practice",
                "content": """Word Problems
- Translate words to equations
- "I thought of a number, doubled it, got 10"
- Equation: 2x = 10

Multi-Step Problems
- Age problems
- Money problems
- Distance problems

Common Mistakes
- Not doing same thing both sides
- Forgetting to check answer
- Wrong order of operations

Tips & Tricks
- Work backwards
- Guess and check
- Draw diagrams

Challenge Problems
- 3 harder problems
- Time limit: 10 minutes
- Solutions provided""",
            },
            {
                "title": "Summary & Review",
                "content": """ Key Terms
- Variable, coefficient, constant
- Expression, equation
- Solution, substitute

Rules
- Same operation both sides
- Isolate the variable
- Check your answer

 Problem Types
- One-step equations
- Two-step equations
- Word problems

Skills Checklist
- Can write expressions from words
- Can identify parts of expressions
- Can solve one-step equations
- Can solve two-step equations

Next Steps
- More complex equations
- Inequalities
- Systems of equations""",
            },
        ],
        "video": {
            "title": "Algebra Basics",
            "duration": "6 minutes",
            "url": "https://example.com/videos/algebra-basics",
            "description": "Learn about variables, algebraic expressions, and solving simple equations step by step.",
        },
        "questions": [
            {
                "id": "alg-q1",
                "question": "If x + 7 = 12, what is the value of x?",
                "options": ["5", "19", "7", "12"],
                "correctAnswer": "5",
                "concept_id": "simple_equations",
                "concept_name": "Simple Equations",
                "difficulty": "Easy",
            },
            {
                "id": "alg-q2",
                "question": "Which expression represents 'three times a number added to 5'?",
                "options": ["3n + 5", "5 + 3n", "Both are correct", "3(n + 5)"],
                "correctAnswer": "Both are correct",
                "concept_id": "algebraic_expressions",
                "concept_name": "Algebraic Expressions",
                "difficulty": "Medium",
            },
            {
                "id": "alg-q3",
                "question": "What is the coefficient in the expression 8x + 3?",
                "options": ["8", "x", "3", "8x"],
                "correctAnswer": "8",
                "concept_id": "variables",
                "concept_name": "Variables",
                "difficulty": "Easy",
            },
            {
                "id": "alg-q4",
                "question": "Solve: 4x - 3 = 13",
                "options": ["4", "5", "3", "16"],
                "correctAnswer": "5",
                "concept_id": "two_step_equations",
                "concept_name": "Two-Step Equations",
                "difficulty": "Medium",
            },
            {
                "id": "alg-q5",
                "question": "If a = 3, what is the value of 2a + 4?",
                "options": ["10", "12", "8", "6"],
                "correctAnswer": "10",
                "concept_id": "substitution",
                "concept_name": "Substitution",
                "difficulty": "Medium",
            },
        ],
    },
    # ============================================================
    # SCIENCE
    # ============================================================
    {
        "id": "sci-plants",
        "title": "Plants",
        "subject": "Science",
        "grade": "Class 6-8",
        "description": "Learn about plant parts, functions, photosynthesis, and how plants grow.",
        "passing_score": 50,
        "document_content": """# Parts of Plants

Plants have several important parts, each with specific functions.

## 1. Roots
**Functions:**
- Anchor the plant in soil
- Absorb water and minerals
- Store food (in some plants like carrots)

**Types:**
- Tap root: one main root (e.g., mustard, dandelion)
- Fibrous root: many thin roots (e.g., grass, wheat)

## 2. Stem
**Functions:**
- Supports the plant and holds leaves up
- Transports water and minerals from roots to leaves
- Transports food from leaves to other parts

**Types:**
- Woody stem: hard and thick (trees, shrubs)
- Herbaceous stem: soft and green (herbs, vegetables)

## 3. Leaves
**Functions:**
- **Photosynthesis**: make food for the plant
- Transpiration: release water vapor
- Gas exchange: take in CO2, release O2

**Parts:**
- Blade: flat green part
- Petiole: stalk connecting to stem
- Veins: transport water and nutrients

## 4. Flowers
**Functions:**
- Reproduction
- Produce seeds and fruits

**Parts:**
- Petals: attract pollinators
- Sepals: protect the bud
- Stamen: male part (produces pollen)
- Pistil: female part (receives pollen)

## 5. Fruits and Seeds
- **Fruit**: protects seeds, helps dispersal
- **Seed**: contains embryo, can grow into new plant

---

## Functions of Plant Parts

| Part | Main Function |
|------|--------------|
| Roots | Absorb water and minerals |
| Stem | Transport and support |
| Leaves | Photosynthesis |
| Flowers | Reproduction |
| Fruits | Seed protection |

---

## Photosynthesis

**Photosynthesis** is the process by which plants make their own food using sunlight.

### Equation:
**Carbon Dioxide + Water + Sunlight → Glucose + Oxygen**
CO₂ + H₂O + Light → C₆H₁₂O₆ + O₂

### How It Works:
1. Roots absorb water from soil
2. Leaves take in carbon dioxide from air
3. Chlorophyll (green pigment) captures sunlight
4. Sunlight energy converts CO2 and water into glucose (food)
5. Oxygen is released as a byproduct

### Factors Affecting Photosynthesis:
- **Light intensity**: More light = faster photosynthesis (up to a point)
- **Carbon dioxide concentration**: More CO2 = faster rate
- **Temperature**: Optimal around 25-30°C
- **Water availability**: Water is a raw material

### Why It's Important:
- Produces food for plants (and all animals indirectly)
- Releases oxygen for all living organisms
- Removes CO2 from atmosphere

---

## Plant Growth

### Life Cycle of a Plant:
1. **Seed**: Dormant stage
2. **Germination**: Seed absorbs water, embryo grows
3. **Seedling**: First leaves appear
4. **Mature plant**: Grows flowers and fruits
5. **Seed production**: New generation begins

### What Plants Need to Grow:
- Water
- Sunlight
- Air (CO2)
- Minerals from soil
- Suitable temperature

---

## Summary

- Plants have 5 main parts: roots, stem, leaves, flowers, fruits
- Each part has specific functions
- Photosynthesis makes food using sunlight, water, and CO2
- Plants need water, light, air, and minerals to grow
- Plants are essential for life on Earth""",
        "ppt_slides": [
            {
                "title": "Parts of Plants",
                "content": """Overview of Plant Parts
- Roots, Stem, Leaves, Flowers, Fruits
- Each part has specific functions
- Working together for plant survival

 Roots
- Anchor plant in soil
- Absorb water and minerals
- Types: tap root vs fibrous root
- Examples: carrot (tap), grass (fibrous)
 Stem
- Supports the plant
- Transport highway for water and food
- Woody vs herbaceous stems

 Leaves
- Food factory (photosynthesis)
- Contains chlorophyll (green pigment)
- Blade, petiole, veins

 Flowers and Reproduction
- Male parts (stamen) and female parts (pistil)
- Petals attract pollinators
- Leads to fruit and seed formation""",
            },
            {
                "title": "Plant Functions",
                "content": """ What Does Each Part Do?
- Roots: absorption and anchoring
- Stem: transport and support
- Leaves: food production
- Flowers: reproduction

 Water Transport
- Roots absorb → Stem transports → Leaves use
- Xylem: water going up
- Phloem: food going everywhere

 Food Transport
- Leaves make food via photosynthesis
- Food travels through phloem
- Stored in roots, stems, fruits

 Gas Exchange
- Leaves breathe through stomata
- Take in CO2, release O2
- Important for life on Earth

 Function Match Activity
- Match parts to functions
- Interactive quiz
- Answer key provided""",
            },
            {
                "title": "Photosynthesis",
                "content": """What is Photosynthesis?
- Plants make their own food
- Uses sunlight, water, CO2
- Produces glucose and oxygen

 The Photosynthesis Equation
- CO2 + H2O + Light → Glucose + O2
- Simple equation, powerful process
- Happens in chloroplasts

Role of Chlorophyll
- Green pigment in leaves
- Captures light energy
- Why leaves are green!
Factors Affecting Photosynthesis
- Light intensity
- CO2 concentration
- Temperature
- Water availability

Why Photosynthesis Matters
- Food for all life
- Oxygen production
- Carbon dioxide removal""",
            },
            {
                "title": "Plant Growth and Life Cycle",
                "content": """Slide 1: Plant Life Cycle
- Seed → Germination → Seedling → Mature → Seeds
- Cycle repeats every generation

Germination
- Seed absorbs water
- Embryo starts growing
- Root emerges first (radicle)

 What Plants Need
- Water: for transport and reactions
- Sunlight: energy for photosynthesis
- Air: CO2 for food, O2 for respiration
- Minerals: from soil for health

Growth Conditions
- Temperature affects growth rate
- Seasonal changes trigger flowering
- Day length matters for some plants

Review and Test
- Label a plant diagram
- Match functions to parts
- Explain photosynthesis""",
            },
            {
                "title": "Summary and Review",
                "content": """Key Terms
- Photosynthesis, chlorophyll, stomata
- Xylem, phloem, germination
- Tap root, fibrous root

 Main Points
- 5 plant parts with specific functions
- Photosynthesis = food production
- Plants need water, light, air, minerals

 Quick Quiz
- 5 questions
- Multiple choice
- Self-assessment

Real-World Connections
- Agriculture and food production
- Deforestation and climate change
- Importance of planting trees

 Next Topics
- Plant classification
- Ecosystems and food chains
- Human impact on plants""",
            },
        ],
        "video": {
            "title": "Introduction to Plants",
            "duration": "5 minutes",
            "url": "https://example.com/videos/introduction-to-plants",
            "description": "Explore plant parts, their functions, and the amazing process of photosynthesis.",
        },
        "questions": [
            {
                "id": "pln-q1",
                "question": "Which part of the plant absorbs water from the soil?",
                "options": ["Roots", "Leaves", "Stem", "Flower"],
                "correctAnswer": "Roots",
                "concept_id": "plant_parts",
                "concept_name": "Plant Parts",
                "difficulty": "Easy",
            },
            {
                "id": "pln-q2",
                "question": "What is the process by which plants make food using sunlight?",
                "options": ["Photosynthesis", "Respiration", "Transpiration", "Germination"],
                "correctAnswer": "Photosynthesis",
                "concept_id": "photosynthesis",
                "concept_name": "Photosynthesis",
                "difficulty": "Medium",
            },
            {
                "id": "pln-q3",
                "question": "What gas do plants release during photosynthesis?",
                "options": ["Oxygen", "Carbon dioxide", "Nitrogen", "Hydrogen"],
                "correctAnswer": "Oxygen",
                "concept_id": "photosynthesis",
                "concept_name": "Photosynthesis",
                "difficulty": "Easy",
            },
            {
                "id": "pln-q4",
                "question": "Which pigment gives plants their green color and captures sunlight?",
                "options": ["Chlorophyll", "Carotene", "Xanthophyll", "Melanin"],
                "correctAnswer": "Chlorophyll",
                "concept_id": "photosynthesis",
                "concept_name": "Photosynthesis",
                "difficulty": "Medium",
            },
            {
                "id": "pln-q5",
                "question": "What is the main function of the stem in a plant?",
                "options": ["Support and transport", "Making food", "Absorbing water", "Reproduction"],
                "correctAnswer": "Support and transport",
                "concept_id": "plant_functions",
                "concept_name": "Plant Functions",
                "difficulty": "Easy",
            },
        ],
    },
    {
        "id": "sci-human-body",
        "title": "Human Body",
        "subject": "Science",
        "grade": "Class 6-8",
        "description": "Learn about the major body systems, organs, and their functions.",
        "passing_score": 50,
        "document_content": """# Body Systems and Organs

The human body is made up of several systems that work together to keep us alive and healthy.

## 1. Circulatory System
**Main Organ:** Heart

**Functions:**
- Pumps blood throughout the body
- Delivers oxygen and nutrients to cells
- Removes waste products

**Components:**
- **Heart**: muscular pump with 4 chambers
- **Blood vessels**: arteries (away from heart), veins (to heart), capillaries (exchange)
- **Blood**: carries oxygen, nutrients, waste, immune cells

**How It Works:**
1. Heart pumps oxygen-poor blood to lungs
2. Lungs add oxygen, remove CO2
3. Oxygen-rich blood returns to heart
4. Heart pumps oxygen-rich blood to body

---

## 2. Digestive System
**Main Organs:** Stomach, Small Intestine, Large Intestine

**Functions:**
- Breaks down food into nutrients
- Absorbs nutrients into blood
- Eliminates waste

**Process:**
1. **Mouth**: chewing and saliva enzymes
2. **Esophagus**: food tube to stomach
3. **Stomach**: acids and enzymes break down food
4. **Small intestine**: nutrients absorbed into blood
5. **Large intestine**: water absorbed, waste formed
6. **Rectum**: waste elimination

---

## 3. Respiratory System
**Main Organs:** Lungs, Trachea, Bronchi

**Functions:**
- Bring oxygen into the body
- Remove carbon dioxide
- Exchange gases in lungs

**Process:**
1. Breathe in: air enters through nose/mouth
2. Trachea and bronchi carry air to lungs
3. Alveoli (tiny air sacs) exchange gases
4. Oxygen enters blood, CO2 leaves blood
5. Breathe out: CO2 is expelled

---

## 4. Nervous System
**Main Organ:** Brain

**Functions:**
- Controls all body activities
- Processes information from senses
- Coordinates movement and thoughts

**Components:**
- **Brain**: control center
- **Spinal cord**: communication highway
- **Nerves**: transmit signals throughout body

---

## 5. Skeletal System
**Main Components:** Bones, Joints, Cartilage

**Functions:**
- Support and shape the body
- Protect organs (skull protects brain, ribs protect heart/lungs)
- Enable movement (with muscles)
- Produce blood cells (in bone marrow)

**Facts:**
- Adult body has 206 bones
- Babies have about 270 bones (some fuse together)
- Smallest bone: stapes (ear)
- Largest bone: femur (thigh)

---

## 6. Muscular System
**Main Components:** Muscles (600+)

**Types:**
- **Skeletal muscles**: voluntary movement
- **Smooth muscles**: involuntary (digestion, blood vessels)
- **Cardiac muscle**: heart only

---

## Summary Table

| System | Main Organ | Primary Function |
|--------|-----------|-----------------|
| Circulatory | Heart | Transport blood |
| Digestive | Stomach | Break down food |
| Respiratory | Lungs | Gas exchange |
| Nervous | Brain | Control body |
| Skeletal | Bones | Support and protect |
| Muscular | Muscles | Movement |

---

## How Systems Work Together

The systems don't work alone—they cooperate!

**Example: Exercise**
1. **Nervous system** decides to move
2. **Skeletal and muscular systems** make bones move
3. **Circulatory system** delivers more oxygen to muscles
4. **Respiratory system** increases breathing rate
5. **Digestive system** provides energy from food

All systems must work together for health!""",
        "ppt_slides": [
            {
                "title": "Overview of Body Systems",
                "content": """The Human Body Systems
- Circulatory: heart and blood
- Digestive: food breakdown
- Respiratory: breathing
- Nervous: brain and control
- Skeletal: bones
- Muscular: movement

Why Systems Matter
- Each system has a job
- Systems work together
- Health depends on all systems

The Big Picture
- 11 major body systems
- All interconnected
- Homeostasis: maintaining balance

Learning Objectives
- Identify main organs
- Understand functions
- See how systems cooperate
- Appreciate body complexity

Interactive Map
- Click body parts
- Learn which system they belong to
- Quiz section included""",
            },
            {
                "title": "Circulatory and Respiratory Systems",
                "content": """The Heart
- 4 chambers: 2 atria, 2 ventricles
- Beats ~100,000 times per day
- Size: your fist!

 Blood Vessels
- Arteries: carry blood away from heart
- Veins: carry blood to heart
- Capillaries: tiny exchange vessels

Lungs and Breathing
- Two lungs with millions of alveoli
- Surface area: like a tennis court!
- Exchange: O2 in, CO2 out

The Journey of Blood
- Right heart → Lungs → Left heart → Body
- Oxygen-poor vs oxygen-rich
- One complete circuit: ~20 seconds

Keeping Your Heart Healthy
- Exercise regularly
- Eat healthy foods
- Don't smoke
- Manage stress""",
            },
            {
                "title": "Digestive System",
                "content": """The Digestive Journey
- Mouth → Esophagus → Stomach → Intestines
- Takes 24-72 hours to complete

 Mouth and Stomach
- Teeth: chew and grind
- Saliva: starts digestion
- Stomach acid: strong enough to dissolve metal!

 Small Intestine
- Length: about 22 feet!
- Nutrient absorption happens here
- Villi increase surface area

 Large Intestine
- Water absorption
- Forms solid waste
- Houses beneficial bacteria

Digestive Health Tips
- Eat fiber-rich foods
- Stay hydrated
- Eat slowly and chew well
- Don't skip meals""",
            },
            {
                "title": "Nervous and Skeletal Systems",
                "content": """ The Brain
- 86 billion neurons
- Controls everything you do
- Uses 20% of your energy

The Spinal Cord
- Connects brain to body
- Carries signals both ways
- Protected by backbone

Nerves Throughout the Body
- Over 100,000 miles of nerves
- Fast signals: up to 268 mph!
- Reflexes don't need the brain

Your Skeleton
- 206 bones in adults
- Different shapes: long, short, flat, irregular
- Bones grow and remodel

Joints and Movement
- Hinge joints: elbow, knee
- Ball and socket: shoulder, hip
- Pivot joint: neck""",
            },
            {
                "title": "Muscular System and Summary",
                "content": """ Types of Muscles
- Skeletal: voluntary (arms, legs)
- Smooth: involuntary (digestion)
- Cardiac: heart only

 Muscle Facts
- 600+ muscles in the body
- Make up ~40% of body weight
- Largest: gluteus maximus
- Smallest: stapes (ear)

How Muscles Work
- Muscles pull, don't push
- Work in pairs (biceps/triceps)
- Need energy from food

Systems Working Together
- Exercise example: all systems involved
- Digestion: energy for movement
- Breathing: oxygen for muscles

 Summary Quiz
- Label major organs
- Match system to function
- How systems cooperate
- Answers provided""",
            },
        ],
        "video": {
            "title": "Human Body Basics",
            "duration": "6 minutes",
            "url": "https://example.com/videos/human-body-basics",
            "description": "Explore the major body systems, organs, and how they work together to keep you healthy.",
        },
        "questions": [
            {
                "id": "hb-q1",
                "question": "Which organ pumps blood throughout the body?",
                "options": ["Heart", "Lungs", "Brain", "Liver"],
                "correctAnswer": "Heart",
                "concept_id": "circulatory_system",
                "concept_name": "Circulatory System",
                "difficulty": "Easy",
            },
            {
                "id": "hb-q2",
                "question": "Where does digestion begin?",
                "options": ["Mouth", "Stomach", "Small intestine", "Esophagus"],
                "correctAnswer": "Mouth",
                "concept_id": "digestive_system",
                "concept_name": "Digestive System",
                "difficulty": "Easy",
            },
            {
                "id": "hb-q3",
                "question": "How many bones are in an adult human body?",
                "options": ["206", "106", "306", "156"],
                "correctAnswer": "206",
                "concept_id": "skeletal_system",
                "concept_name": "Skeletal System",
                "difficulty": "Medium",
            },
            {
                "id": "hb-q4",
                "question": "Which system controls all body activities?",
                "options": ["Nervous system", "Digestive system", "Circulatory system", "Respiratory system"],
                "correctAnswer": "Nervous system",
                "concept_id": "nervous_system",
                "concept_name": "Nervous System",
                "difficulty": "Medium",
            },
            {
                "id": "hb-q5",
                "question": "What carries oxygen in the blood?",
                "options": ["Red blood cells", "White blood cells", "Platelets", "Plasma"],
                "correctAnswer": "Red blood cells",
                "concept_id": "circulatory_system",
                "concept_name": "Circulatory System",
                "difficulty": "Medium",
            },
        ],
    },
]

# Extra Science chapters (Water, Weather and Seasons, Fun with Magnets) live in
# their own module so the additions stay reviewable on their own.
from chapter_content_extra import EXTRA_SCIENCE_CHAPTERS  # noqa: E402

SEED_CHAPTERS.extend(EXTRA_SCIENCE_CHAPTERS)

CHAPTER_INFO = {}
for ch in SEED_CHAPTERS:
    CHAPTER_INFO[ch["id"]] = {
        "id": ch["id"],
        "title": ch["title"],
        "subject": ch["subject"],
        "grade": ch["grade"],
        "description": ch["description"],
        "total_questions": len(ch["questions"]),
        "passing_score": ch["passing_score"],
    }


# Flatten all questions for the old-style questions table
ALL_QUESTIONS = []
for ch in SEED_CHAPTERS:
    for i, q in enumerate(ch["questions"]):
        ALL_QUESTIONS.append({
            "id": q["id"],
            "chapter_id": ch["id"],
            "text": q["question"],
            "correct_answer": q["correctAnswer"],
            "concept_id": q["concept_id"],
            "concept_name": q["concept_name"],
            "difficulty": {"Easy": 1, "Medium": 2, "Hard": 3}.get(q["difficulty"], 2),
        })


# Students data (kept for backward compatibility)
STUDENTS = [
    {
        "id": "student_1",
        "name": "Arjun Mehta",
        "grade": "Grade 3",
        "avatar": "👦",
        "enrolled_date": "2024-01-15",
    },
    {
        "id": "student_2",
        "name": "Priya Sharma",
        "grade": "Grade 3",
        "avatar": "👧",
        "enrolled_date": "2024-02-01",
    },
    {
        "id": "student_3",
        "name": "Rahul Kumar",
        "grade": "Grade 3",
        "avatar": "👦",
        "enrolled_date": "2024-01-20",
    },
]


# Assessment history (kept for backward compatibility)
ASSESSMENT_HISTORY = {}