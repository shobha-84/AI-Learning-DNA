"""
Additional Science chapters: Water, Weather and Seasons, Fun with Magnets.

These live in their own module so the additions stay readable and reviewable
separately from the original seed set. They are appended to SEED_CHAPTERS by
seed_data.py and match the exact structure of the existing chapters.
"""

EXTRA_SCIENCE_CHAPTERS = [
    # ============================================================
    # WATER
    # ============================================================
    {
        "id": "sci-water",
        "title": "Water",
        "subject": "Science",
        "grade": "Class 6-8",
        "description": "Learn about the states of water, its unique properties, the water cycle, and why water is essential to life.",
        "passing_score": 50,
        "document_content": """# Introduction to Water

Water covers about 71% of Earth's surface, yet it is one of the most unusual
substances we know. Almost every living thing depends on it, and it behaves in
ways that few other substances do.

## 1. States of Water

Water can exist in three states, and it can change between them when it gains
or loses energy (heat).

- **Solid** - ice, snow. Particles are packed in a fixed, orderly arrangement.
  Water freezes at 0 degrees Celsius (32 F) or 212 F... actually at 0 C / 32 F.
- **Liquid** - the state we use most. Particles are close together but can move
  freely past each other.
- **Gas** - water vapour. Particles are far apart and move quickly in all
  directions.

### Changing State
- **Melting**: solid to liquid (ice to water) - absorbs heat
- **Freezing**: liquid to solid (water to ice) - releases heat
- **Evaporation**: liquid to gas (water to vapour) - absorbs heat
- **Condensation**: gas to liquid (vapour to droplets) - releases heat
- **Sublimation**: solid to gas directly (ice to vapour) without melting

## 2. Unique Properties of Water

Water behaves unusually compared with most substances:

- **High boiling point (100 C)**: water needs a lot of heat to become a gas
- **High freezing point (0 C)**: ice floats because it is less dense than liquid water
- **Excellent solvent**: water dissolves more substances than any other liquid
- **High specific heat**: water heats and cools slowly, which moderates climates
- **Surface tension**: water forms a skin on its surface, letting insects walk on it

## 3. The Water Cycle

Water is never lost; it moves continuously around the Earth.

- **Evaporation**: Sun's heat turns liquid water into vapour
- **Condensation**: vapour cools and forms tiny droplets into clouds
- **Precipitation**: droplets grow heavy and fall as rain, snow, sleet or hail
- **Infiltration**: water soaks into the ground and becomes groundwater
- **Runoff**: water flows over the land into rivers, lakes and the sea
- **Transpiration**: plants release water vapour through their leaves

## 4. Water as a Solution

When a substance dissolves in water it forms a **solution**.

- **Solute**: the substance that dissolves (salt, sugar)
- **Solvent**: the liquid that does the dissolving (water)
- Water is called the universal solvent
- Not everything dissolves: oil floats on water because it does not dissolve
- Solubility usually increases with temperature

## 5. Water and Living Things

- About 60-70% of the human body is water
- Water helps transport nutrients and remove waste
- Plants need water to make food through photosynthesis
- Water is used every day for drinking, cooking, cleaning and farming

## Summary

- Water has three states: solid, liquid and gas
- Changing state needs energy - heat is absorbed or released
- Water has unusual properties: high boiling point, floats as ice, dissolves most solids
- The water cycle moves water through evaporation, condensation, precipitation and collection
- Water is the universal solvent and is essential to all life""",
        "ppt_slides": [
            {
                "title": "Why Water Matters",
                "content": """Water is Essential
- 71% of Earth's surface
- Needed by every living thing
- About 60-70% of the human body
- Drives climate and weather

 What We Will Learn
- The three states of water
- Unique properties of water
- The water cycle
- Water as a solvent""",
            },
            {
                "title": "States of Water",
                "content": """The Three States
- Solid: ice and snow, particles fixed in place
- Liquid: water, particles move freely
- Gas: vapour, particles far apart

 Changing State
- Melting: solid to liquid
- Freezing: liquid to solid
- Evaporation: liquid to gas
- Condensation: gas to liquid
- Sublimation: solid to gas

 Remember: change of state needs energy""",
            },
            {
                "title": "Unique Properties",
                "content": """Water Behaves Differently
- High boiling point: 100 C
- High freezing point: 0 C
- Ice floats: less dense than liquid water
- Excellent solvent
- High specific heat, so it cools slowly
- Surface tension lets insects walk on water

 Why This Matters
- Ice floats, so lakes freeze from the top
- Oceans and lakes stay warm longer in winter""",
            },
            {
                "title": "The Water Cycle",
                "content": """How Water Moves
- Evaporation: Sun heats water into vapour
- Condensation: vapour cools into clouds
- Precipitation: rain, snow, sleet, hail
- Infiltration: soaks into the ground
- Runoff: flows into rivers and seas
- Transpiration: plants release vapour

 Water is Never Destroyed
- It changes form, not quantity""",
            },
            {
                "title": "Water as a Solvent and Summary",
                "content": """Solutions
- Solute dissolves, solvent dissolves it
- Water is the universal solvent
- Oil does not dissolve, so it floats

 Summary
- Three states, changed by heat
- Unusual properties: boils high, ice floats
- Water cycle keeps water moving
- Essential for every living thing

 Quick Quiz
- Why does ice float?
- Name two states of water""",
            },
        ],
        "video": {
            "title": "Introduction to Water",
            "duration": "5 minutes",
            "url": "https://example.com/videos/introduction-to-water",
            "description": "Explore the states of water, its unique properties, the water cycle, and why water is essential to life.",
        },
        "questions": [
            {
                "id": "wat-q1",
                "question": "At what temperature does water freeze?",
                "options": ["0 degrees Celsius", "50 degrees Celsius", "100 degrees Celsius", "-50 degrees Celsius"],
                "correctAnswer": "0 degrees Celsius",
                "concept_id": "states_of_water",
                "concept_name": "States of Water",
                "difficulty": "Easy",
            },
            {
                "id": "wat-q2",
                "question": "Which change of state turns water vapour into liquid water?",
                "options": ["Condensation", "Evaporation", "Melting", "Sublimation"],
                "correctAnswer": "Condensation",
                "concept_id": "states_of_water",
                "concept_name": "States of Water",
                "difficulty": "Easy",
            },
            {
                "id": "wat-q3",
                "question": "Why is water called the universal solvent?",
                "options": ["It dissolves more substances than any other liquid", "It is found everywhere on Earth", "It is the heaviest natural liquid", "It freezes faster than other liquids"],
                "correctAnswer": "It dissolves more substances than any other liquid",
                "concept_id": "water_properties",
                "concept_name": "Water Properties",
                "difficulty": "Medium",
            },
            {
                "id": "wat-q4",
                "question": "In a solution of salt dissolved in water, what is the salt called?",
                "options": ["Solute", "Solvent", "Solution", "Mixture"],
                "correctAnswer": "Solute",
                "concept_id": "solutions",
                "concept_name": "Solutions",
                "difficulty": "Easy",
            },
            {
                "id": "wat-q5",
                "question": "A gardener waters plants in the morning. Plants release water vapour through their leaves. What is this process called?",
                "options": ["Transpiration", "Condensation", "Precipitation", "Infiltration"],
                "correctAnswer": "Transpiration",
                "concept_id": "water_cycle",
                "concept_name": "Water Cycle",
                "difficulty": "Medium",
            },
        ],
    },
    # ============================================================
    # WEATHER AND SEASONS
    # ============================================================
    {
        "id": "sci-weather-seasons",
        "title": "Weather and Seasons",
        "subject": "Science",
        "grade": "Class 6-8",
        "description": "Learn the elements of weather, how weather differs from climate, what causes seasons, and how to read a weather forecast.",
        "passing_score": 50,
        "document_content": """# Introduction to Weather and Seasons

Weather is what the sky is doing right now, where you are. It changes hour to
hour, and it is different in every place. Climate is the long-term pattern of
weather in a region over many years.

## 1. Weather vs Climate

- **Weather**: short-term, changes quickly, local
- **Climate**: average weather over 25 to 30 years, changes slowly
- Example: "It is raining today" is weather. "This city has a wet monsoon climate
  every June" is climate.

## 2. Elements of Weather

### Temperature
- How hot or cold the air is
- Measured in degrees Celsius (C) or Fahrenheit (F)
- Changes through the day, warmest around mid-afternoon

### Air Pressure
- Weight of the air pushing down on us
- Measured in millibars (mb) or hectopascals (hPa)
- High pressure usually brings settled, clear weather
- Low pressure usually brings clouds and rain

### Humidity
- Water vapour in the air
- High humidity makes the air feel sticky and helps clouds form
- Dew forms when humid air cools overnight

### Wind
- Air moving from high to low pressure
- Stronger pressure difference means stronger wind
- Named for the direction it blows **from**

### Cloud and Rain
- Clouds form when water vapour condenses around tiny dust particles
- Rain is cloud droplets that grow heavy enough to fall
- Rainfall is measured in millimetres

## 3. Air Masses and Fronts

- **Air mass**: a large body of air with fairly uniform temperature and moisture
- **Front**: the boundary where two different air masses meet
  - A **cold front** brings a sudden drop in temperature and often showers
  - A **warm front** brings gradual warming and steady light rain

## 4. Seasons

Seasons happen because Earth is **tilted on its axis at about 23.5 degrees**
while it orbits the Sun.

- A hemisphere tilted **towards** the Sun gets more direct sunlight and longer
  days - that is **summer**
- A hemisphere tilted **away** gets less direct sunlight and shorter days -
  that is **winter**
- When the tilt is sideways, both hemispheres get similar daylight - that is
  **spring** and **autumn**

Because the tilt always points in the same direction, the Northern Hemisphere
has summer from about June to August while the Southern Hemisphere has winter.

## 5. Reading a Forecast

- **High / Low**: the highest and lowest temperature expected
- **Rainfall chance**: how likely rain is, as a percentage
- **Wind speed**: often in km/h or Beaufort scale
- **Humidity**: relative humidity, where 100% means the air is saturated

## Summary

- Weather is short-term, climate is the long-term average
- Main elements: temperature, pressure, humidity, wind, cloud and rain
- High pressure means settled weather, low pressure means unsettled
- Seasons are caused by Earth's 23.5 degree axial tilt, not distance from the Sun
- The two hemispheres have opposite seasons""",
        "ppt_slides": [
            {
                "title": "Weather vs Climate",
                "content": """Two Different Ideas
- Weather: right now, where you are
- Climate: 25-30 year average for a region
- Weather changes hour to hour
- Climate changes over centuries

 Examples
- "It is raining now" = weather
- "Wet monsoon every June" = climate

 Remember
- Weather is local and short-term
- Climate is regional and long-term""",
            },
            {
                "title": "Elements of Weather",
                "content": """Measuring the Sky
- Temperature: hot or cold, in C or F
- Air pressure: weight of air, in mb or hPa
- Humidity: water vapour in the air
- Wind: air moving high to low pressure
- Cloud and rain: condensation and rainfall

 High vs Low Pressure
- High pressure: clear, settled weather
- Low pressure: cloudy, rainy weather""",
            },
            {
                "title": "Clouds, Rain and Fronts",
                "content": """How Clouds Form
- Water vapour condenses on tiny dust
- Droplets grow heavy and fall as rain
- Rainfall measured in millimetres

 Air Masses and Fronts
- Air mass: uniform temperature and moisture
- Front: where two air masses meet
- Cold front: sudden cooling, often showers
- Warm front: gradual warming, steady rain""",
            },
            {
                "title": "Why Seasons Happen",
                "content": """Earth's Tilt
- Earth is tilted about 23.5 degrees
- Tilt stays pointed the same way while we orbit

 Summer and Winter
- Tilted towards the Sun: more direct light, longer days
- Tilted away: less direct light, shorter days
- Spring and autumn: tilt sideways

 Key Point
- Seasons are caused by tilt, not by distance from the Sun""",
            },
            {
                "title": "Opposite Seasons and Summary",
                "content": """Two Hemispheres
- Northern summer: June to August
- Southern hemisphere has winter at the same time
- The opposite pattern runs December to February

 Summary
- Weather is short-term, climate is long-term
- Five main elements of weather
- Seasons come from Earth's 23.5 degree tilt
- Opposite hemispheres, opposite seasons

 Quick Quiz
- Why do seasons happen?
- High pressure means?""",
            },
        ],
        "video": {
            "title": "Weather and Seasons Explained",
            "duration": "6 minutes",
            "url": "https://example.com/videos/weather-and-seasons",
            "description": "Understand the elements of weather, the difference between weather and climate, and why Earth has seasons.",
        },
        "questions": [
            {
                "id": "wth-q1",
                "question": "What is the difference between weather and climate?",
                "options": ["Weather is short-term, climate is the long-term average", "They mean exactly the same thing", "Climate changes hourly, weather does not", "Weather is only about rain"],
                "correctAnswer": "Weather is short-term, climate is the long-term average",
                "concept_id": "weather_vs_climate",
                "concept_name": "Weather and Climate",
                "difficulty": "Easy",
            },
            {
                "id": "wth-q2",
                "question": "Low air pressure usually brings which kind of weather?",
                "options": ["Cloudy and rainy", "Clear and dry", "Extremely cold and dry", "Very windy and hot"],
                "correctAnswer": "Cloudy and rainy",
                "concept_id": "air_pressure",
                "concept_name": "Air Pressure",
                "difficulty": "Easy",
            },
            {
                "id": "wth-q3",
                "question": "Earth's seasons are mainly caused by what?",
                "options": ["Earth's 23.5 degree axial tilt", "Earth being closer to the Sun in summer", "The Moon's gravity", "Changes in Earth's size"],
                "correctAnswer": "Earth's 23.5 degree axial tilt",
                "concept_id": "seasons",
                "concept_name": "Seasons",
                "difficulty": "Medium",
            },
            {
                "id": "wth-q4",
                "question": "When a cold air mass meets a warm air mass, what is the boundary called?",
                "options": ["A front", "A cloud", "A gust", "An isobar"],
                "correctAnswer": "A front",
                "concept_id": "air_masses",
                "concept_name": "Air Masses and Fronts",
                "difficulty": "Medium",
            },
            {
                "id": "wth-q5",
                "question": "If it is summer in the Northern Hemisphere, which hemisphere is having winter?",
                "options": ["The Southern Hemisphere", "Both hemispheres", "Neither hemisphere", "Only the equator"],
                "correctAnswer": "The Southern Hemisphere",
                "concept_id": "seasons",
                "concept_name": "Seasons",
                "difficulty": "Easy",
            },
        ],
    },
    # ============================================================
    # FUN WITH MAGNETS
    # ============================================================
    {
        "id": "sci-magnets",
        "title": "Fun with Magnets",
        "subject": "Science",
        "grade": "Class 6-8",
        "description": "Discover how magnets work, what magnetic poles do, where magnets are used, and how to make your own magnet.",
        "passing_score": 50,
        "document_content": """# Introduction to Magnets

A magnet is an object that attracts certain materials, most commonly iron. Magnets
can be natural or man-made, and they are used in everything from door catches to
mobile phones.

## 1. What Is a Magnet?

- A magnet attracts magnetic materials such as **iron, nickel and cobalt**
- It does not attract all metals: aluminium, copper and gold are not magnetic
- A magnet has two ends called **poles**
- A freely suspended magnet always points North-South

### Natural and Artificial Magnets
- **Natural magnet**: lodestone, a naturally magnetised rock
- **Artificial magnets**: made by humans, including bar, horseshoe and needle magnets
- Artificial magnets are stronger and can be given any shape

## 2. Magnetic Poles

- Every magnet has a **North pole (N)** and a **South pole (S)**
- **Like poles repel** each other (N-N, S-S)
- **Unlike poles attract** each other (N-S)
- This is the single most important rule in magnetism

## 3. The Magnetic Field

- The region around a magnet where it can attract other objects
- Magnetic field lines go **from North to South** outside the magnet
- Field lines never cross each other
- The field is strongest at the poles and weak far from the magnet
- A compass needle is a small magnet that points along the field

## 4. Magnetism Can Be Induced

- **Temporary magnetism**: stroking a steel needle with a magnet makes it a
  magnet, but the effect wears off
- **Permanent magnetism**: a steel bar kept in a magnetic field for a long time
  becomes a permanent magnet
- **Demagnetising**: heating a magnet, hammering it, or rubbing two magnets
  together can destroy its magnetism
- An electromagnet becomes magnetic only when electric current flows, and the
  strength can be changed by adding coils or an iron core

## 5. Uses of Magnets

- **Compass**: a needle magnet for navigation
- **Loudspeakers**: a coil moves near a magnet to make sound
- **Fridge doors**: small magnets hold the door shut
- **MRI scanners**: extremely strong magnets image the body
- **Maglev trains**: magnetic levitation reduces friction
- **Hard drives and speakers**: store data magnetically
- **Electric generators**: turning motion near a magnet makes electricity

## 6. Safety

- Magnets should be kept away from mobile phones, cards and watches
- Small powerful magnets are dangerous if swallowed
- Never place a magnet near a heart pacemaker

## Summary

- Magnets attract iron, nickel and cobalt, not all metals
- Every magnet has North and South poles
- Like poles repel, unlike poles attract
- Field lines run from North to South and never cross
- Magnetism can be induced, lost, or produced by electric current
- Magnets are used in compasses, speakers, generators and medical imaging""",
        "ppt_slides": [
            {
                "title": "What Is a Magnet?",
                "content": """Magnet Basics
- Attracts iron, nickel and cobalt
- Does NOT attract aluminium, copper, gold
- Has two ends called poles
- Always points North-South when free

 Natural vs Artificial
- Natural: lodestone rock
- Artificial: bar, horseshoe, needle
- Artificial magnets are stronger

 Definition
- An object that attracts magnetic materials""",
            },
            {
                "title": "Magnetic Poles",
                "content": """The Two Poles
- North pole (N) and South pole (S)
- Every magnet has both

 The Key Rule
- Like poles repel: N-N, S-S
- Unlike poles attract: N-S

 Examples
- Two bar magnets with N facing N push apart
- N facing S pull together

 This holds for all magnets""",
            },
            {
                "title": "The Magnetic Field",
                "content": """The Invisible Field
- Region around a magnet where it attracts
- Field lines run North to South
- Lines never cross each other
- Strongest at the poles, weaker far away
- Denser lines mean a stronger field

 The Compass
- A compass needle is a tiny magnet
- It points along the magnetic field""",
            },
            {
                "title": "Making and Losing Magnetism",
                "content": """Induced Magnetism
- Stroking steel with a magnet gives temporary magnetism
- Permanent magnetism lasts much longer

 Losing Magnetism
- Heating a magnet
- Hammering it hard
- Rubbing two magnets together

 Electromagnets
- Become magnetic only with electric current
- Stronger with more coils and an iron core
- Switchable on and off""",
            },
            {
                "title": "Uses and Summary",
                "content": """Where Magnets Are Used
- Compass for navigation
- Loudspeakers and headphones
- Fridge door catches
- MRI scanners in hospitals
- Maglev trains
- Hard drives storing data
- Generators making electricity

 Safety
- Keep away from phones, cards, pacemakers

 Summary
- Two poles, like repels unlike attracts
- Field from North to South
- Magnetism can be induced or lost""",
            },
        ],
        "video": {
            "title": "Fun with Magnets",
            "duration": "5 minutes",
            "url": "https://example.com/videos/fun-with-magnets",
            "description": "Discover how magnets work, what poles do, how to make your own magnet, and where magnets are used every day.",
        },
        "questions": [
            {
                "id": "mag-q1",
                "question": "Which of these materials is attracted by a magnet?",
                "options": ["Iron", "Copper", "Aluminium", "Gold"],
                "correctAnswer": "Iron",
                "concept_id": "magnetic_materials",
                "concept_name": "Magnetic Materials",
                "difficulty": "Easy",
            },
            {
                "id": "mag-q2",
                "question": "What happens when the North poles of two magnets are brought close together?",
                "options": ["They repel", "They attract", "They become one magnet", "Nothing happens"],
                "correctAnswer": "They repel",
                "concept_id": "magnetic_poles",
                "concept_name": "Magnetic Poles",
                "difficulty": "Easy",
            },
            {
                "id": "mag-q3",
                "question": "Magnetic field lines outside a magnet run in which direction?",
                "options": ["From North to South", "From South to North", "In circles only", "They do not exist"],
                "correctAnswer": "From North to South",
                "concept_id": "magnetic_field",
                "concept_name": "Magnetic Field",
                "difficulty": "Medium",
            },
            {
                "id": "mag-q4",
                "question": "A compass needle works because it is a small _____.",
                "options": ["Magnet", "Battery", "Spring", "Wire"],
                "correctAnswer": "Magnet",
                "concept_id": "magnetic_field",
                "concept_name": "Magnetic Field",
                "difficulty": "Medium",
            },
            {
                "id": "mag-q5",
                "question": "Which action can destroy the magnetism of a magnet?",
                "options": ["Heating it strongly", "Storing it near other magnets", "Keeping it dry", "Blowing on it"],
                "correctAnswer": "Heating it strongly",
                "concept_id": "induced_magnetism",
                "concept_name": "Induced Magnetism",
                "difficulty": "Hard",
            },
        ],
    },
]
