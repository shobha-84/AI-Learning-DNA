# Technical Documentation — AI Learning DNA

Personalised learning platform that converts assessment results into a versioned
"Learning DNA" profile (concept mastery, misconceptions, strengths, gaps,
learning risk) and drives a learning journey from baseline through chapter
learning, AI tutoring and chapter assessment.

**Scope:** this document describes the system as built. Where behaviour is
incomplete or inconsistent, it says so explicitly rather than describing intent.

---

## Table of Contents

1. [Architecture](#1-architecture)
2. [Tech Stack](#2-tech-stack)
3. [Running the Project](#3-running-the-project)
4. [Backend](#4-backend)
5. [Database Schema](#5-database-schema)
6. [DNA Engine](#6-dna-engine)
7. [RAG Retrieval](#7-rag-retrieval)
8. [Frontend](#8-frontend)
9. [Learning Progression & Gating Rules](#9-learning-progression--gating-rules)
10. [Scoring Formulas](#10-scoring-formulas)
11. [API Reference](#11-api-reference)
12. [Known Issues](#12-known-issues)

---

## 1. Architecture

```
┌──────────────────────────────────────────────────────────┐
│  Browser (React 18 + Vite, single-file app)               │
│                                                          │
│  Assessment ──► DNA Profile ──► Dashboard                │
│                                   ├─ Profile tab          │
│                                   ├─ Subjects tab         │
│                                   └─ Assessment tab       │
│                                                          │
│  Chapter screen: Document | PPT | Video | Audio          │
│                  + AI Companion (side panel)             │
└───────────────────────────┬──────────────────────────────┘
                            │ HTTP (Vite dev proxy /api → :8000)
┌───────────────────────────▼──────────────────────────────┐
│  FastAPI backend                                         │
│                                                          │
│  main.py       routes, SQLAlchemy models, persistence    │
│  dna_engine.py concept analysis, misconceptions, risk    │
│  rag_engine.py BM25 retrieval + chapter companion        │
│  seed_data.py + chapter_content_extra.py content bank    │
└───────────────────────────┬──────────────────────────────┘
                            │
              ┌─────────────┴─────────────┐
              │                           │
        SQLite (default)            PostgreSQL (DATABASE_URL)
        learning_dna.db
              │
        Ollama (optional LLM)
```

**Key design decisions**

| Decision | Rationale |
|----------|-----------|
| SQLite default, PostgreSQL via `DATABASE_URL` | Zero-setup demo; same ORM models either way |
| BM25 lexical retrieval instead of a vector DB | No embedding API or vector store needed, so retrieval works offline and in a demo |
| LLM optional | Every AI path has a retrieval-only fallback, so no feature dies when Ollama is absent |
| Chapter content in the database, question bank in the frontend | Content is authored once; the assessment can run without a network call |
| Single-file React app | Fast to iterate for a demo; a known maintainability cost |

---

## 2. Tech Stack

**Backend** — `backend/requirements.txt`

| Package | Version | Role |
|---------|---------|------|
| fastapi | 0.109.0 | HTTP API, auto OpenAPI docs |
| uvicorn | 0.27.0 | ASGI server |
| pydantic | 2.5.3 | Request/response validation |
| sqlalchemy | 2.0.25 | ORM |
| psycopg2-binary | 2.9.10 | PostgreSQL driver |
| python-multipart | 0.0.6 | Form parsing |
| numpy | 1.26.3 | Numeric work in the DNA engine |
| ollama | 0.3.0 | Optional local LLM client |

**Frontend** — `frontend/package.json`

| Package | Version | Role |
|---------|---------|------|
| react / react-dom | 18.2.0 | UI |
| react-router-dom | 7.18.4 | Routing shell |
| framer-motion | 11.11.17 | Transitions, `AnimatePresence` |
| recharts | 2.10.3 | Charts |
| axios | 1.6.2 | HTTP client |
| vite | 5.0.8 | Dev server + build |
| tailwindcss | 3.3.6 | Available, but the app styles in `index.css` |

**Python 3.14** is the interpreter in use. Note the startup warning from pydantic
v2 about `allow_population_by_field_name` → `validate_by_name`; it is a deprecation
notice in a dependency, not an application error.

---

## 3. Running the Project

```bash
# Backend  (the bare `uvicorn` command is not on PATH on this machine)
cd backend
python -m pip install -r requirements.txt
python -m uvicorn main:app --host 0.0.0.0 --port 8000 --reload

# Frontend
cd frontend
npm install
npm run dev          # or: npm run build
```

| Service | URL |
|---------|-----|
| Frontend | http://localhost:5173 |
| API | http://localhost:8000 |
| OpenAPI docs | http://localhost:8000/docs |

**Vite dev proxy** — `frontend/vite.config.ts` forwards `/api` to
`http://localhost:8000`, so the browser only ever talks to one origin.

**Is the backend required?** Not for most of the app. Registration, the baseline
assessment, the DNA profile, the subjects explorer, the chapter assessment runner
and all tracking work client-side — the question bank and subject definitions ship
in `App.tsx`. The backend is required for the **chapter learning screen** (content
lives in the API) and the **AI companion** (retrieval and LLM).

**Database selection** — `DATABASE_URL` defaults to
`sqlite:///./learning_dna.db`. Set it to a PostgreSQL URL to switch; both use the
same SQLAlchemy models.

**Schema migrations** are inline and idempotent, run at import:
`ensure_student_columns()` adds legacy columns to `students`, and
`ensure_learning_plan_columns()` adds `completion_percentage` to
`student_learning_plans`. Both check before altering.

**Seeding** — `seed_database()` only runs when the `students` table is empty.
Chapters added to `seed_data.py` afterwards must be inserted explicitly; that was
done for the three Science chapters with a guarded, re-runnable script.

---

## 4. Backend

### `backend/main.py`
Routes, SQLAlchemy models (declared inline — `backend/models.py` contains
Pydantic schemas only and is **not** imported), seeding, and persistence.

### `backend/dna_engine.py`
The analysis engine. Public methods on `DNAEngine`:

| Method | Purpose |
|--------|---------|
| `analyze_responses` | Concept-level mastery from a set of answers |
| `detect_misconceptions` | Rule-based error pattern classification |
| `identify_strengths_and_gaps` | Concept partitioning with trends |
| `generate_recommendations` | Targeted study advice from the weakest concept |
| `generate_remediation_activities` | Activity suggestions |
| `calculate_learning_risks` | Risk level from misconceptions and gaps |
| `get_prerequisite_chain` | Walks `CONCEPT_MAP` prerequisites with cycle guard |

`AICompanion` provides `generate_explanation`, `generate_chat_response` and
`generate_study_plan`, each with an offline fallback when Ollama is unavailable.

Misconception detection is rule-based over `CONCEPT_MAP`, covering patterns such
as carry omission, sign confusion and place-value error. Confidence threshold
`0.7` separates high- and low-confidence detections.

### `backend/rag_engine.py`
Chapter-scoped retrieval — see [§7](#7-rag-retrieval).

### `backend/seed_data.py` / `chapter_content_extra.py`
Content bank: 7 chapters, each with a markdown document, 5 PPT slides, video
metadata and 5 questions.

| Chapter id | Title | Subject |
|-------------|-------|---------|
| `math-fractions` | Fractions | Mathematics |
| `math-algebra` | Algebra | Mathematics |
| `sci-plants` | Plants | Science |
| `sci-human-body` | Human Body | Science |
| `sci-water` | Water | Science |
| `sci-weather-seasons` | Weather and Seasons | Science |
| `sci-magnets` | Fun with Magnets | Science |

---

## 5. Database Schema

Eight tables. All models are declared in `main.py`.

### `students`
`id` (PK, `DNA10001`-style), `name`, `grade`, `avatar`, `enrolled_date`,
`school`, `email` (unique), `subjects_json`, `contact_number`, `learning_goal`,
`registration_date`, `created_at`

### `chapters`
`id` (PK), `title`, `subject`, `grade`, `description`, `total_questions`,
`passing_score`

### `questions`
`id` (PK), `chapter_id`, `text`, `correct_answer`, `concept_id`, `concept_name`,
`difficulty`

### `assessments`
One row per attempt. `id` (PK), `student_id`, `chapter_id`, `attempt_number`,
`score`, `date`, `answers_json`, `created_at`

`answers_json` holds a single-element array whose object carries `kind`,
`correct`, `total`, `reasoning`, `problemSolving`, `criticalThinking` and the
raw `answers`. The cognitive scores are only in this field — there are no
dedicated columns.

### `dna_profiles`
One row per DNA version. `id` (PK), `student_id`, `chapter_id`, `version`,
`overall_score`, `concept_mastery_json`, `strengths_json`, `gaps_json`,
`misconceptions_json`, `reasoning_score`, `confidence_level`,
`learning_risks_json`, `recommendations_json`, `remediation_json`, `generated_at`

Chapter-level progress-solving lives in `concept_mastery_json` as
`{ mastery, reasoning, problemSolving, criticalThinking, kind }`. There is no
`problem_solving` or `critical_thinking` column.

### `chapter_content`
`id` (PK), `chapter_id`, `title`, `content_type` (`document` | `ppt` | `video` |
`audio`), `content_url`, `content_text`, `duration`, `thumbnail`, `description`,
`is_active`, `sort_order`, timestamps

### `chapter_questions`
`id` (PK), `chapter_id`, `question_text`, `options_json`, `correct_answer`,
`concept_id`, `concept_name`, `difficulty`, `explanation`, `is_active`,
`sort_order`, `created_at`

### `student_learning_plans`
Doubles as the learning-mode completion record.
`id` (PK), `student_id`, `chapter_id`, `activity_type` (`mode` for remediation),
`title` (the mode id), `description`, `duration`, `completed`,
`completion_percentage`, `created_at`

---

## 6. DNA Engine

Pipeline, in order:

1. `analyze_responses` → per-concept mastery
2. `detect_misconceptions` → classified error patterns
3. `identify_strengths_and_gaps` → partitioned concepts
4. `calculate_learning_risks` → Low / Medium / High
5. `generate_recommendations` + `generate_remediation_activities`

Concept relationships live in `CONCEPT_MAP`, a static prerequisite graph.
`get_prerequisite_chain` traverses it with a `visited` set to prevent cycles.

Versioning: every assessment attempt writes a **new** `dna_profiles` row with an
incrementing `version`, which is what makes trajectory and evolution views
possible. `assessments.attempt_number` and `dna_profiles.version` increment in
lockstep — the second attempt of a chapter is the retest.

---

## 7. RAG Retrieval

`backend/rag_engine.py`, used by `POST /api/chapters/{id}/companion`.

```
learner question
      ↓
intent detection
      ↓
BM25 retrieval over chapter content
      ↓
+ chapter DNA (gaps, strengths, misconceptions)
      + assessment insights (concepts actually answered wrong)
      ↓
prompt assembly → LLM
      ↓
answer + source sections + whether DNA was used
```

**Indexing** — chapter markdown is split into sections by heading, then into
sentence-grouped chunks (max ~420 chars). Document content is the primary source;
slides and question-bank items are indexed secondarily and rank below it.

**Ranking** — BM25 with `k1=1.5`, `b=0.75`, IDF floored so common terms never
subtract score.

**Intent detection** — keyword rules over the question, mapping to explain,
simple, example, practice, summarize, weakness, recommend, default. Intent shapes
both retrieval and the prompt.

**Two behaviours worth knowing:**

- *Generic prompts are expanded.* "Explain in simple English" contains no
  content-bearing keywords, so it would match nothing. Intent query expansion
  substitutes retrieval terms, and failing that the opening chunks are returned.
  Without this the companion answers "I could not find anything" to a perfectly
  reasonable question.
- *Weak concepts boost retrieval.* For weakness intent, the learner's recorded
  gaps are mixed into the query, so "Why am I weak?" retrieves the concepts they
  actually failed rather than generic chapter text.

**Offline fallback** — if Ollama is absent or errors, answers are composed from
the retrieved text, shaped by intent (explain / summary / practice / weakness /
recommend). The companion degrades rather than fails.

---

## 8. Frontend

Single-file app: `frontend/src/App.tsx` (~5,100 lines) plus
`frontend/src/index.css` (~4,200 lines). No state library, no router-driven
screens — `App` holds a `screen` state and returns one screen per branch.

> **Maintainability note.** All hooks in `App` must be declared **above** the
> `if (screen === ...)` early returns. Violating this produces a blank page with
> a "Rendered more hooks than during the previous render" error, and `tsc` does
> not catch it. The same applies to any component using early returns.

### Screens
Registration → Baseline assessment → Learning DNA → Dashboard (Profile / Subjects /
Assessment tabs) → Chapter screen.

### Notable components
| Component | Role |
|-----------|------|
| `BaselineAssessmentPage` | Subject-grouped assessment, auto subject switch |
| `LearningDNAPage` | Student facts, Generate Baseline DNA with brain-loading, DNA profile |
| `SubjectResultsCard` | Per-subject scores + overall |
| `Dashboard` | Learner header, three tabs, chapter tracking |
| `SubjectExplorer` | Subject → chapter → learning mode |
| `ChapterLearningScreen` | Mode switcher, four mode panels, AI companion |
| `VideoLearningScreen` | Generated narrated slide player (Phase 1) |
| `AudioLessonPlayer` | Track-based narrated audio player |
| `AICompanionPanel` | Chat, suggested questions, voice in/out |
| `ChapterAssessmentRunner` | Chapter assessment and retest |

### Generated video (Phase 1)
Slides are derived from chapter content, not authored per chapter:
`buildVideoSlides` classifies document sections into **Introduction / Key
Concepts / Examples / Summary** by heading regex and a worked-arithmetic content
signal. Verified to produce 3–4 slides across all 7 chapters.

Narration uses the Web Speech API. Advancement is driven by the speech engine's
`onend`; the progress bar animates on a timer between boundaries.

### Generated audio
`AudioLessonPlayer` builds one **track** per document section with an estimated
duration (`words / 2.4`, minimum 6s). Waveform bars use a deterministic sine
pattern so they do not jitter between renders.

### Speech handling — three subtle rules
1. **`speechSynthesis` is a single global queue.** A mode switch cancels it,
   including any AI companion reply in progress.
2. **Cancelling an utterance still fires its `onend`.** Both players use a *play
   token* ref: each play captures a token and the completion callback returns
   early if it no longer matches. Without this, pressing Stop advanced to the
   next track.
3. **Mode panels stay mounted.** All four are rendered inside `.mode-stage` with
   inactive ones marked `hidden`. This preserves each mode's own progress across
   switches, and it means the players' `isActive` effects actually run — the
   stop-on-mode-change guarantee cannot depend on unmount ordering.

### Voice input
`useSpeechToText` wraps `SpeechRecognition` (Chrome/Edge only). Lesson narration
is cancelled first so the microphone cannot record it. Recognition availability is
detected at runtime; the mic is hidden with a note where unsupported.

---

## 9. Learning Progression & Gating Rules

```
Registration
   → Baseline Assessment (5 questions per selected subject)
   → Generate Baseline DNA (brain loading)
   → Start Learning Journey
        → Subjects: subject → chapter → learning mode
             → Video: 80% watched, or all slides viewed
             → Audio: every track heard
             → Document / PPT: marked complete manually
        → Assessment tab: chapter assessment → remediation → retest
             → Chapter DNA → Subject DNA → Overall DNA → DNA Evolution
```

**Retest gating** — a retest unlocks only when the chapter assessment is
complete **and** at least one learning mode is recorded as done:

```
retestUnlocked = assessmentCompleted && completedModes.length >= 1 && !retestCompleted
```

Remediation is a real gate, not a click. Video and Audio self-report on
thresholds; Document and PPT require the explicit "Mark complete" action, which
is also the only way to complete a mode in a browser with no speech engine.

**Completion thresholds**

| Mode | Condition |
|------|-----------|
| Video | `VIDEO_COMPLETION_THRESHOLD = 80`% of slides viewed, or all viewed |
| Audio | Every track narrated to completion |
| Document / PPT | Manual "Mark complete" |

A cancelled or skipped narration never counts — a track or slide is only recorded
when playback actually ran.

**Progress persistence** — writes update the UI first and POST in the background,
so a backend outage never blocks the learner; the session just stays in memory.

---

## 10. Scoring Formulas

| Metric | Formula | Location |
|--------|---------|----------|
| Mastery | `round(score × 0.7 + confidence × 0.3)` | `App.tsx` `calcMastery` |
| Confidence weight | Very Confident 100, Confident 75, Unsure 40, Guessing 15 | `App.tsx` `calcConfidence` |
| Difficulty weight | Easy 0.6, Medium 0.8, Hard 1.0 | `App.tsx` `DIFFICULTY_WEIGHT` |
| Cognitive skill | Accuracy over matching question types; falls back to difficulty-weighted accuracy when the pool has none | `App.tsx` `computeCognitiveSkills` |
| Audio duration | `words / 2.4`, minimum 6s | `App.tsx` `estimateDuration` |
| BM25 | `k1 = 1.5`, `b = 0.75`, IDF floored | `rag_engine.py` `BM25Index` |

**Risk bands** — see [§12](#12-known-issues); the frontend and backend currently
use different thresholds.

---

## 11. API Reference

All routes are under `/api`. Interactive docs at `/docs`.

### Students & registration
| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/students` | List students |
| POST | `/api/students/register` | Register / get-or-create a learner |
| POST | `/api/registrations` | Create registration |

### Content repository
| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/chapters` | Chapter list |
| GET | `/api/questions/{chapter_id}` | Legacy question list |
| GET | `/api/repo/chapters` | List chapters |
| POST | `/api/repo/chapters` | Create chapter |
| PUT | `/api/repo/chapters/{chapter_id}` | Update chapter |
| DELETE | `/api/repo/chapters/{chapter_id}` | Delete chapter and its content, questions, assessments and DNA |
| GET | `/api/repo/chapters/{chapter_id}/content` | List content by type |
| POST | `/api/repo/chapters/{chapter_id}/content` | Add content |
| PUT | `/api/repo/content/{content_id}` | Update content |
| DELETE | `/api/repo/content/{content_id}` | Delete content |
| GET | `/api/repo/chapters/{chapter_id}/questions` | List questions |
| POST | `/api/repo/chapters/{chapter_id}/questions` | Add question |
| PUT | `/api/repo/question/{question_id}` | Update question |
| DELETE | `/api/repo/question/{question_id}` | Delete question |

### Learning plans
| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/repo/plans/{student_id}` | List plans |
| POST | `/api/repo/plans/{student_id}` | Create plan |
| PUT | `/api/repo/plans/{plan_id}` | Update / complete |
| DELETE | `/api/repo/plans/{plan_id}` | Delete plan |

### Assessment & DNA
| Method | Path | Purpose |
|--------|------|---------|
| POST | `/api/assessment/submit` | Submit assessment, generate DNA profile |
| GET | `/api/student/{student_id}/history` | Assessment history |
| GET | `/api/student/{student_id}/dna/{chapter_id}` | DNA profile for a chapter |
| GET | `/api/dna/trajectory/{student_id}/{chapter_id}` | Score across versions |
| GET | `/api/dna/concept-trend/{student_id}/{chapter_id}` | Per-concept trend |

### Progress persistence
| Method | Path | Purpose |
|--------|------|---------|
| POST | `/api/progress/chapter-assessment` | Store an attempt, write a DNA version |
| POST | `/api/progress/mode-complete` | Store a learning mode + percentage |
| GET | `/api/progress/{student_id}` | Restore tracking, attempts, evolution |

### AI
| Method | Path | Purpose |
|--------|------|---------|
| GET | `/api/chapters/{chapter_id}/learning-context` | Content grouped by mode + chapter DNA |
| POST | `/api/chapters/{chapter_id}/companion` | RAG chapter companion |
| POST | `/api/ai-companion/chat` | Legacy DNA-aware chat |

---

## 12. Known Issues

Documented deliberately rather than left to be discovered.

### Risk and mastery thresholds differ between client and server

| Metric | Frontend (`App.tsx`) | Backend (`main.py`) |
|--------|----------------------|---------------------|
| Risk Low at | score ≥ 70 | score ≥ 80 |
| Risk Medium at | score ≥ 40 | score ≥ 50 |
| Mastery | `score × 0.7 + 21` | `score × 0.7 + 20` |

A chapter scored 75 displays as **Low** risk in the UI, but the same score
restored from `/api/progress` is **Medium**. The two should be unified into one
shared definition before the thresholds are tuned further.

### Other limitations
- **Baseline DNA is not persisted.** It lives in React state; only chapter-level
  progress survives a refresh.
- **Progress is keyed to `student.id`.** When registration falls back to the
  hardcoded `DNA10001` (backend unreachable), learners share one bucket.
- **Seeded video and audio are placeholders** — `example.com` URLs, no audio
  files. Generated lessons are used instead. Because mode panels stay mounted, a
  *real* `<video>`/`<audio>` would keep playing while hidden and needs a
  pause-on-inactive handler.
- **Retrieval is lexical.** Synonyms absent from the chapter will not match.
- **Voice input is Chrome/Edge only**, and Chrome sends audio to Google for
  recognition — dictation is not local.
- **Speech synthesis needs a system voice**; silent in minimal containers.
- **Narration is one global queue** — a mode switch cancels companion speech too.
- **`seed_database()` is one-shot**, gated on an empty `students` table.
- **`backend/models.py` is unused** — Pydantic schemas only; ORM models live in
  `main.py`.
- **Dead code:** several `TS6133` warnings, an unused `EvolutionBadge`, and
  superseded CSS rules from the earlier player markup.