# ============================================
# AI Learning DNA - Automated Setup Script
# ============================================

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  AI Learning DNA - Setup Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan
Write-Host ""

$PROJECT_ROOT = "D:\2026\Hackthon\AI-Learning-DNADemo"
$BACKEND_DIR = "$PROJECT_ROOT\backend"
$FRONTEND_DIR = "$PROJECT_ROOT\frontend"

# Step 1: Check Python installation
Write-Host "[1/5] Checking Python installation..." -ForegroundColor Yellow
$pythonPath = Get-Command python -ErrorAction SilentlyContinue
if (-not $pythonPath) {
    Write-Host "ERROR: Python is not installed. Please install Python 3.10+ first." -ForegroundColor Red
    Write-Host "Download from: https://www.python.org/downloads/" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit
}
Write-Host "  Python found: $($pythonPath.Source)" -ForegroundColor Green

# Step 2: Check Node.js installation
Write-Host "[2/5] Checking Node.js installation..." -ForegroundColor Yellow
$nodePath = Get-Command node -ErrorAction SilentlyContinue
if (-not $nodePath) {
    Write-Host "ERROR: Node.js is not installed. Please install Node.js 18+ first." -ForegroundColor Red
    Write-Host "Download from: https://nodejs.org/" -ForegroundColor Yellow
    Write-Host ""
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit
}
Write-Host "  Node.js found: $($nodePath.Source)" -ForegroundColor Green

# Step 3: Install backend dependencies
Write-Host "[3/5] Installing Python dependencies..." -ForegroundColor Yellow
Set-Location $BACKEND_DIR
Write-Host "  Installing packages..." -ForegroundColor Gray
python -m pip install --upgrade pip -q 2>&1 | Out-Null
python -m pip install -r requirements.txt -q 2>&1 | Out-Null
if ($LASTEXITCODE -eq 0) {
    Write-Host "  Python dependencies installed successfully!" -ForegroundColor Green
} else {
    Write-Host "  ERROR: Failed to install Python dependencies." -ForegroundColor Red
    Write-Host ""
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit
}

# Step 4: Install frontend dependencies
Write-Host "[4/5] Installing Frontend dependencies..." -ForegroundColor Yellow
Set-Location $FRONTEND_DIR
Write-Host "  Installing packages..." -ForegroundColor Gray
npm install 2>&1 | Out-Null
if ($LASTEXITCODE -eq 0) {
    Write-Host "  Frontend dependencies installed successfully!" -ForegroundColor Green
} else {
    Write-Host "  ERROR: Failed to install Frontend dependencies." -ForegroundColor Red
    Write-Host ""
    Write-Host "Press any key to exit..."
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
    exit
}

# Step 5: Database Setup Instructions
Write-Host "[5/5] Database Setup" -ForegroundColor Yellow
Write-Host ""
Write-Host "IMPORTANT: PostgreSQL Database Setup Required" -ForegroundColor Yellow
Write-Host ""
Write-Host "Please do the following in pgAdmin4:" -ForegroundColor White
Write-Host ""
Write-Host "1. Open pgAdmin4" -ForegroundColor White
Write-Host "2. Connect to your PostgreSQL server" -ForegroundColor White
Write-Host "3. Right-click Databases -> Create -> Database" -ForegroundColor White
Write-Host "4. Enter Database Name: 'learning_dna'" -ForegroundColor White
Write-Host "5. Click Save" -ForegroundColor White
Write-Host ""
Write-Host "6. Right-click 'learning_dna' database -> Query Tool" -ForegroundColor White
Write-Host "7. Copy and paste the SQL script below:" -ForegroundColor White
Write-Host ""
Write-Host "--- SQL SCRIPT START ---" -ForegroundColor Cyan
Write-Host ""

# Print SQL script to console
Write-Host "CREATE TABLE students (
    id VARCHAR PRIMARY KEY,
    name VARCHAR NOT NULL,
    grade VARCHAR,
    avatar VARCHAR,
    enrolled_date VARCHAR,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE chapters (
    id VARCHAR PRIMARY KEY,
    title VARCHAR NOT NULL,
    subject VARCHAR,
    grade VARCHAR,
    description TEXT,
    total_questions INTEGER,
    passing_score INTEGER
);

CREATE TABLE questions (
    id VARCHAR PRIMARY KEY,
    chapter_id VARCHAR,
    text TEXT NOT NULL,
    correct_answer VARCHAR,
    concept_id VARCHAR,
    concept_name VARCHAR,
    difficulty INTEGER
);

CREATE TABLE assessments (
    id VARCHAR PRIMARY KEY,
    student_id VARCHAR,
    chapter_id VARCHAR,
    attempt_number INTEGER,
    score FLOAT,
    date TIMESTAMP,
    answers_json JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE dna_profiles (
    id VARCHAR PRIMARY KEY,
    student_id VARCHAR,
    chapter_id VARCHAR,
    version INTEGER,
    overall_score FLOAT,
    concept_mastery_json JSON,
    strengths_json JSON,
    gaps_json JSON,
    misconceptions_json JSON,
    reasoning_score FLOAT,
    confidence_level FLOAT,
    learning_risks_json JSON,
    recommendations_json JSON,
    remediation_json JSON,
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Insert demo students
INSERT INTO students VALUES ('student_1', 'Arjun Mehta', 'Grade 3', '👦', '2024-01-15');
INSERT INTO students VALUES ('student_2', 'Priya Sharma', 'Grade 3', '👧', '2024-02-01');
INSERT INTO students VALUES ('student_3', 'Rahul Kumar', 'Grade 3', '👦', '2024-01-20');

-- Insert chapter
INSERT INTO chapters VALUES ('ch1', 'Addition & Subtraction', 'Mathematics', 'Grade 3', 'Learn addition and subtraction with and without carrying', 10, 70);

-- Insert questions
INSERT INTO questions VALUES ('q1', 'ch1', 'What is 23 + 45?', '68', 'addition_no_carry', 'No-Carry Addition', 1);
INSERT INTO questions VALUES ('q2', 'ch1', 'What is 57 + 34?', '91', 'addition_carry', 'Carry Addition', 2);
INSERT INTO questions VALUES ('q3', 'ch1', 'What is 68 + 29?', '97', 'addition_carry', 'Carry Addition', 2);
INSERT INTO questions VALUES ('q4', 'ch1', 'What is 84 - 37?', '47', 'subtraction_carry', 'Carry/Subtract Borrow', 3);
INSERT INTO questions VALUES ('q5', 'ch1', 'What is 15 + 27 + 8?', '50', 'addition_multi_digit', 'Multi-Digit Addition', 3);
INSERT INTO questions VALUES ('q6', 'ch1', 'What is 36 - 19?', '17', 'subtraction_carry', 'Carry/Subtract Borrow', 3);
INSERT INTO questions VALUES ('q7', 'ch1', 'What is 12 + 8?', '20', 'addition_carry', 'Carry Addition', 2);
INSERT INTO questions VALUES ('q8', 'ch1', 'What is 45 - 23?', '22', 'subtraction_no_carry', 'No-Carry Subtraction', 1);
INSERT INTO questions VALUES ('q9', 'ch1', 'A farmer has 34 apples and picks 27 more. How many apples does he have now?', '61', 'word_problems', 'Word Problem Solving', 4);
INSERT INTO questions VALUES ('q10', 'ch1', 'What is 76 + 18?', '94', 'addition_carry', 'Carry Addition', 2);
" -ForegroundColor White
Write-Host ""
Write-Host "--- SQL SCRIPT END ---" -ForegroundColor Cyan
Write-Host ""

# Save SQL to file for easy copy-paste
$SQL_FILE = "$PROJECT_ROOT\setup_database.sql"
@'
CREATE TABLE students (
    id VARCHAR PRIMARY KEY,
    name VARCHAR NOT NULL,
    grade VARCHAR,
    avatar VARCHAR,
    enrolled_date VARCHAR,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE chapters (
    id VARCHAR PRIMARY KEY,
    title VARCHAR NOT NULL,
    subject VARCHAR,
    grade VARCHAR,
    description TEXT,
    total_questions INTEGER,
    passing_score INTEGER
);

CREATE TABLE questions (
    id VARCHAR PRIMARY KEY,
    chapter_id VARCHAR,
    text TEXT NOT NULL,
    correct_answer VARCHAR,
    concept_id VARCHAR,
    concept_name VARCHAR,
    difficulty INTEGER
);

CREATE TABLE assessments (
    id VARCHAR PRIMARY KEY,
    student_id VARCHAR,
    chapter_id VARCHAR,
    attempt_number INTEGER,
    score FLOAT,
    date TIMESTAMP,
    answers_json JSON,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE dna_profiles (
    id VARCHAR PRIMARY KEY,
    student_id VARCHAR,
    chapter_id VARCHAR,
    version INTEGER,
    overall_score FLOAT,
    concept_mastery_json JSON,
    strengths_json JSON,
    gaps_json JSON,
    misconceptions_json JSON,
    reasoning_score FLOAT,
    confidence_level FLOAT,
    learning_risks_json JSON,
    recommendations_json JSON,
    remediation_json JSON,
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

INSERT INTO students VALUES ('student_1', 'Arjun Mehta', 'Grade 3', '👦', '2024-01-15');
INSERT INTO students VALUES ('student_2', 'Priya Sharma', 'Grade 3', '👧', '2024-02-01');
INSERT INTO students VALUES ('student_3', 'Rahul Kumar', 'Grade 3', '👦', '2024-01-20');

INSERT INTO chapters VALUES ('ch1', 'Addition & Subtraction', 'Mathematics', 'Grade 3', 'Learn addition and subtraction with and without carrying', 10, 70);

INSERT INTO questions VALUES ('q1', 'ch1', 'What is 23 + 45?', '68', 'addition_no_carry', 'No-Carry Addition', 1);
INSERT INTO questions VALUES ('q2', 'ch1', 'What is 57 + 34?', '91', 'addition_carry', 'Carry Addition', 2);
INSERT INTO questions VALUES ('q3', 'ch1', 'What is 68 + 29?', '97', 'addition_carry', 'Carry Addition', 2);
INSERT INTO questions VALUES ('q4', 'ch1', 'What is 84 - 37?', '47', 'subtraction_carry', 'Carry/Subtract Borrow', 3);
INSERT INTO questions VALUES ('q5', 'ch1', 'What is 15 + 27 + 8?', '50', 'addition_multi_digit', 'Multi-Digit Addition', 3);
INSERT INTO questions VALUES ('q6', 'ch1', 'What is 36 - 19?', '17', 'subtraction_carry', 'Carry/Subtract Borrow', 3);
INSERT INTO questions VALUES ('q7', 'ch1', 'What is 12 + 8?', '20', 'addition_carry', 'Carry Addition', 2);
INSERT INTO questions VALUES ('q8', 'ch1', 'What is 45 - 23?', '22', 'subtraction_no_carry', 'No-Carry Subtraction', 1);
INSERT INTO questions VALUES ('q9', 'ch1', 'A farmer has 34 apples and picks 27 more. How many apples does he have now?', '61', 'word_problems', 'Word Problem Solving', 4);
INSERT INTO questions VALUES ('q10', 'ch1', 'What is 76 + 18?', '94', 'addition_carry', 'Carry Addition', 2);
'@ | Out-File -FilePath $SQL_FILE -Encoding utf8

Write-Host "  SQL script saved to: $SQL_FILE" -ForegroundColor Green
Write-Host "  You can open it with: notepad $SQL_FILE" -ForegroundColor Green
Write-Host ""
Write-Host "  After creating the database and running the SQL script," -ForegroundColor White
Write-Host "  press any key to start the servers..." -ForegroundColor White
Write-Host ""
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")

# Start Backend Server
Write-Host ""
Write-Host "Starting Backend Server..." -ForegroundColor Cyan
Write-Host "  URL: http://localhost:8000" -ForegroundColor White
Write-Host "  API Docs: http://localhost:8000/docs" -ForegroundColor White
Write-Host ""

# Start Backend in new window
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$BACKEND_DIR'; python -m uvicorn main:app --reload"

# Wait a moment for backend to start
Start-Sleep -Seconds 2

# Start Frontend Server
Write-Host "Starting Frontend Server..." -ForegroundColor Cyan
Write-Host "  URL: http://localhost:5173" -ForegroundColor White
Write-Host ""

# Start Frontend in new window
Start-Process powershell -ArgumentList "-NoExit", "-Command", "cd '$FRONTEND_DIR'; npm run dev"

Write-Host ""
Write-Host "========================================" -ForegroundColor Green
Write-Host "  Setup Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Green
Write-Host ""
Write-Host "Backend API:    http://localhost:8000" -ForegroundColor White
Write-Host "API Docs:       http://localhost:8000/docs" -ForegroundColor White
Write-Host "Frontend App:   http://localhost:5173" -ForegroundColor White
Write-Host ""
Write-Host "Open 2 PowerShell windows will launch automatically." -ForegroundColor Yellow
Write-Host "To stop servers: Close the PowerShell windows or press Ctrl+C" -ForegroundColor Yellow
Write-Host ""
Write-Host "Press any key to close this script..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
