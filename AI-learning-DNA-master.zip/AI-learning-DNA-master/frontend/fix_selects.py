import re

f = r'D:\2026\Hackthon\AI-Learning-DNADemo\frontend\src\App.tsx'
c = open(f, encoding='utf-8').read()

# The file has two broken patterns:
# 1. Class select: ...option key={index + 1}>Class {index + 1}</option></span></label>  (missing </select>)
# 2. Learning Goal: ...Clear exam doubts</option></select><span className="field-error">{fieldErrors.learningGoal}</span></label>  (this one is actually correct now)

# Fix Class select - add back </select> before the error span
# Pattern: Class {index + 1}</option></span></label>
c = c.replace(
    'Class {index + 1}</option></span></label>',
    'Class {index + 1}</option></select></label>'
)

# Verify fixes
idx1 = c.find('Class {index + 1}</option></select></label>')
idx2 = c.find('fieldErrors.learningGoal}')
print(f"Class select fixed: {idx1 > 0}")
print(f"Learning Goal error: {idx2 > 0}")

open(f, 'w', encoding='utf-8').write(c)

# Count select endings
count_select = c.count('</select></label>')
count_field = c.count('fieldErrors.')
print(f"</select></label> count: {count_select}")
print(f"fieldErrors count: {count_field}")
