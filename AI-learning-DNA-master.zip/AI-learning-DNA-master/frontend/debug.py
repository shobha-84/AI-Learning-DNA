import re

f = r'D:\2026\Hackthon\AI-Learning-DNADemo\frontend\src\App.tsx'
c = open(f, encoding='utf-8').read()

# Check what the file currently looks like around learning goal
idx = c.find('learningGoal')
if idx > 0:
    print("learningGoal context:", repr(c[idx-50:idx+200]))

# The file is broken - all </select></label> were removed
# We need to fix this properly

# Find the exact Learning Goal select element
# Pattern: Learning Goal<em>*</em><select...>...</select></label>
pattern = r'(Learning Goal<em>\*</em><select value=\{form\.learningGoal\} onChange=\{\(event\) => update\(\'learningGoal\', event\.target\.value\)\}>.*?</select>)</label>'
match = re.search(pattern, c, re.DOTALL)
if match:
    print("Found Learning Goal select:", match.group(0)[:100], "...")
else:
    print("Learning Goal select NOT found - file is broken")
    # Show what's around Learning Goal
    idx = c.find('Learning Goal')
    if idx > 0:
        print("Context:", repr(c[idx:idx+300]))
