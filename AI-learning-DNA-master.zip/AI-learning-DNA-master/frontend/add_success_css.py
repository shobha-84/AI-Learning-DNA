css_path = r'D:\2026\Hackthon\AI-Learning-DNADemo\frontend\src\index.css'
css = open(css_path, encoding='utf-8').read()

success_css = """

/* Success Modal Overlay */
.success-overlay {
  position: fixed;
  inset: 0;
  z-index: 1000;
  display: flex;
  align-items: center;
  justify-content: center;
}

.success-backdrop {
  position: absolute;
  inset: 0;
  background: rgba(10, 5, 30, 0.65);
  backdrop-filter: blur(16px);
  -webkit-backdrop-filter: blur(16px);
}

.success-glass {
  position: relative;
  z-index: 1;
  max-width: 480px;
  width: 92%;
  padding: 48px 40px 44px;
  border: 1px solid rgba(255, 255, 255, 0.18);
  border-radius: 24px;
  background: rgba(255, 255, 255, 0.12);
  backdrop-filter: blur(24px);
  -webkit-backdrop-filter: blur(24px);
  box-shadow: 0 32px 80px rgba(0, 0, 0, 0.35), 0 0 0 1px rgba(255, 255, 255, 0.1) inset, 0 0 60px rgba(126, 107, 226, 0.15) inset;
  overflow: hidden;
}

.success-confetti-burst {
  position: absolute;
  inset: 0;
  overflow: hidden;
  pointer-events: none;
}

.confetti-piece {
  position: absolute;
  top: -8px;
  width: 6px;
  height: 10px;
  border-radius: 2px;
  opacity: 0.8;
  animation: confetti-fall 2.8s ease-in forwards;
}

.c0, .c2 { background: #f59e0b; }
.c1, .c3 { background: #6366f1; }
.c0, .c1 { border-radius: 50%; }

@keyframes confetti-fall {
  0% { transform: translateY(-10px) rotate(0deg); opacity: 0.9; }
  70% { opacity: 0.7; }
  100% { transform: translateY(500px) rotate(720deg); opacity: 0; }
}

.success-icon-wrap {
  display: flex;
  justify-content: center;
  margin-bottom: 20px;
}

.success-circle {
  width: 64px;
  height: 64px;
  border-radius: 50%;
  display: grid;
  place-items: center;
  background: linear-gradient(135deg, #22c55e, #16a34a);
  box-shadow: 0 8px 24px rgba(34, 197, 94, 0.35);
}

.success-checkmark {
  color: white;
  font-size: 28px;
  font-weight: 700;
  text-shadow: 0 1px 3px rgba(0, 0, 0, 0.2);
}

.success-content {
  text-align: center;
}

.success-tag {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: 8px;
  color: #818cf8;
  font: 600 10px 'Space Grotesk', sans-serif;
  letter-spacing: 1.8px;
  margin-bottom: 14px;
}

.success-emoji {
  font-size: 18px;
  display: inline-block;
}

.success-content h2 {
  margin: 0 0 12px;
  color: white;
  font: 600 28px 'Space Grotesk', sans-serif;
  letter-spacing: -1px;
  line-height: 1.1;
}

.success-content h2 span {
  color: #a5b4fc;
}

.success-content > p {
  margin: 0 0 24px;
  color: #c4c6e0;
  font-size: 12px;
  line-height: 1.7;
  max-width: 380px;
  margin-left: auto;
  margin-right: auto;
}

.success-profile-preview {
  padding: 16px 18px;
  border: 1px solid rgba(255, 255, 255, 0.12);
  border-radius: 12px;
  background: rgba(255, 255, 255, 0.06);
  margin-bottom: 22px;
  text-align: left;
}

.profile-row {
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 8px 0;
  color: #c4c6e0;
  font-size: 11px;
}

.profile-row:not(:last-child) {
  border-bottom: 1px solid rgba(255, 255, 255, 0.08);
}

.profile-label {
  color: #8b8fa8;
  font-size: 10px;
}

.profile-value {
  color: #e0e2f0;
  font-weight: 600;
}

.profile-value.mono {
  font-family: 'Space Grotesk', monospace;
  letter-spacing: 0.5px;
}

.success-action-btn {
  display: inline-flex;
  align-items: center;
  gap: 10px;
  padding: 14px 28px;
  color: white;
  border: none;
  border-radius: 10px;
  background: linear-gradient(100deg, #4f46e5, #6366f1 60%, #22c55e);
  box-shadow: 0 10px 28px rgba(79, 70, 229, 0.35);
  font: 600 12px 'Space Grotesk', sans-serif;
  cursor: pointer;
  transition: transform 0.2s, box-shadow 0.2s;
  width: 100%;
  justify-content: center;
}

.success-action-btn:hover {
  transform: translateY(-2px);
  box-shadow: 0 14px 34px rgba(79, 70, 229, 0.45);
}

.success-action-btn span {
  font-size: 15px;
}

.success-subtext {
  margin: 16px 0 0;
  color: #8b8fa8;
  font-size: 9px;
  letter-spacing: 0.3px;
}

@media (max-width: 600px) {
  .success-glass {
    padding: 36px 24px 32px;
    margin: 16px;
  }
  .success-content h2 {
    font-size: 22px;
  }
  .success-profile-preview {
    padding: 12px 14px;
  }
  .profile-row {
    font-size: 10px;
  }
}"""

# Insert before the closing of the file
if 'success-overlay' not in css:
    open(css_path, 'w', encoding='utf-8').write(css + success_css)
    print('CSS added')
else:
    print('CSS already exists')
