import re

f = r'D:\2026\Hackthon\AI-Learning-DNADemo\frontend\src\App.tsx'
c = open(f, encoding='utf-8').read()

# The new RegistrationScreen with enhanced success modal
new_screen = '''function RegistrationScreen({ onDemo, onStartAssessment }: { onDemo: () => void; onStartAssessment: (data: RegistrationData) => void | Promise<void> }) {
  const [form, setForm] = useState<RegistrationData>({
    studentName: '',
    class: '',
    schoolName: '',
    email: '',
    contactNumber: '',
    preferredSubjects: [],
    learningGoal: '',
    registrationDate: new Date().toISOString(),
  })
  const [terms, setTerms] = useState(false)
  const [saving, setSaving] = useState(false)
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({})
  const [successData, setSuccessData] = useState<SuccessData | null>(null)

  useEffect(() => {
    const header = document.querySelector('.registration-screen .walk-header')
    if (!header) return
    const demoButton = header.querySelector('.registration-demo-link') || document.createElement('button')
    if (!demoButton.parentElement) {
      demoButton.className = 'header-quiet registration-demo-link'
      demoButton.type = 'button'
      demoButton.textContent = 'Learning Demo ↗'
      header.appendChild(demoButton)
    }
    demoButton.onclick = onDemo
    header.appendChild(demoButton)
  }, [onDemo])

  const update = (key: keyof RegistrationData, value: string | string[]) => setForm((current) => ({ ...current, [key]: value }))
  const toggleSubject = (subject: string) => update('preferredSubjects', form.preferredSubjects.includes(subject) ? form.preferredSubjects.filter((item) => item !== subject) : [...form.preferredSubjects, subject])

  const validateForm = () => {
    const errors: Record<string, string> = {}
    if (!form.studentName.trim()) errors.studentName = 'Student Name is required.'
    if (!form.class.trim()) errors.class = 'Class is required.'
    if (!form.schoolName.trim()) errors.schoolName = 'School Name is required.'
    if (!form.email.trim() || !/^[^\\s@]+@[^\\s@]+\\.[^\\s@]+$/.test(form.email)) errors.email = 'A valid Email ID is required.'
    if (!form.contactNumber.trim()) errors.contactNumber = 'Contact Number is required.'
    if (!form.learningGoal) errors.learningGoal = 'Learning Goal is required.'
    if (!form.preferredSubjects.length) errors.preferredSubjects = 'Please select at least one preferred subject.'
    if (!terms) errors.terms = 'Please accept the Terms & Conditions to continue.'
    return errors
  }

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    const validationErrors = validateForm()
    const hasErrors = Object.keys(validationErrors).length > 0
    setFieldErrors(validationErrors)
    if (hasErrors) return

    setSaving(true)
    setFieldErrors({})

    try {
      const response = await axios.post('/api/students/register', {
        studentName: form.studentName.trim(),
        class: form.class,
        schoolName: form.schoolName.trim(),
        email: form.email.trim(),
        contactNumber: form.contactNumber.trim(),
        preferredSubjects: form.preferredSubjects,
        learningGoal: form.learningGoal.trim(),
        registrationDate: new Date().toISOString(),
      })

      const studentId = response.data?.studentId || response.data?.student_id || 'DNA10001'
      setSuccessData({ studentId, studentName: form.studentName.trim(), preferredSubjects: form.preferredSubjects })
    } catch (submissionError) {
      setFieldErrors({ submission: 'Registration failed. Please try again.' })
    } finally {
      setSaving(false)
    }
  }

  const handleStartAssessment = useCallback(() => {
    if (!successData) return
    onStartAssessment({
      ...form,
      id: successData.studentId,
      studentName: successData.studentName,
      preferredSubjects: successData.preferredSubjects,
    })
  }, [successData, form, onStartAssessment])

  return <div className="registration-screen"><header className="walk-header"><Logo /><span className="registration-tagline">Discover how you learn, not just your score</span></header>{fieldErrors.submission && <div className="form-error-global" role="alert">{fieldErrors.submission}</div>}{successData && <div className="success-overlay" onClick={(e) => e.stopPropagation()}><div className="success-backdrop" /><motion.div className="success-glass" initial={{ opacity: 0, scale: 0.85, y: 30 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.85, y: 30 }} transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}><div className="success-confetti-burst" aria-hidden="true">{Array.from({ length: 24 }, (_, i) => <span key={i} className={`confetti-piece c${i % 4}`} style={{ left: `${(i * 13.5) % 100}%`, animationDelay: `${(i % 7) * 0.05}s` }} />)}</div><div className="success-icon-wrap"><motion.div className="success-circle" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 260, damping: 20, delay: 0.2 }}><span className="success-checkmark">✓</span></motion.div></div><motion.div className="success-content" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.4 }}><div className="success-tag"><motion.span className="success-emoji" initial={{ rotate: -15 }} animate={{ rotate: 0 }} transition={{ type: "spring", stiffness: 300, delay: 0.4 }}>🎉</motion.span>Congratulations!</div><h2>Welcome to <span>AI Learning DNA</span></h2><p>Your learner intelligence profile is ready. We\'ve captured your strengths, preferences, and learning goals to personalize your journey.</p><div className="success-profile-preview"><div className="profile-row"><span className="profile-label">Name</span><span className="profile-value">{successData.studentName}</span></div><div className="profile-row"><span className="profile-label">Student ID</span><span className="profile-value mono">{successData.studentId}</span></div><div className="profile-row"><span className="profile-label">Subjects</span><span className="profile-value">{successData.preferredSubjects.join(' · ')}</span></div></div><button className="success-action-btn" type="button" onClick={handleStartAssessment}>Start Baseline Assessment <span>↗</span></button><p className="success-subtext">Your first assessment will create your Chapter DNA profile.</p></motion.div></motion.div></div>}<main className="registration-layout"><section className="registration-story"><div className="walk-eyebrow"><span /> YOUR JOURNEY STARTS HERE</div><h1>Create your<br /><em>Learning DNA.</em></h1><p>Build a personalized learner intelligence profile that grows with you, beyond marks and grades.</p><div className="registration-flow">{['Assessment', 'Chapter DNA', 'AI Companion', 'Growth Plan'].map((step, index) => <div key={step}><span>{index + 1}</span><b>{step}</b>{index < 3 && <i>→</i>}</div>)}</div><div className="registration-visual"><DNAHelix small /><span className="registration-orbit one" /><span className="registration-orbit two" /></div></section><form className="registration-card" onSubmit={submit} noValidate><div className="section-kicker">YOUR STORY STARTS HERE</div><h2>Create your <span>Learning DNA</span></h2><p>Tell us a little about yourself. There are no right or wrong answers.</p><div className="registration-fields"><label>Student Name <em>*</em><input value={form.studentName} onChange={(event) => update('studentName', event.target.value)} placeholder="e.g. Ananya Sharma" className={fieldErrors.studentName ? 'input-error' : ''} /><span className="field-error">{fieldErrors.studentName}</span></label><label>Class <em>*</em><select value={form.class} onChange={(event) => update('class', event.target.value)} className={fieldErrors.class ? 'input-error' : ''}><option value="">Select your class</option>{Array.from({ length: 12 }, (_, index) => <option key={index + 1}>Class {index + 1}</option>)}</select><span className="field-error">{fieldErrors.class}</span></label><label>School Name <em>*</em><input value={form.schoolName} onChange={(event) => update('schoolName', event.target.value)} placeholder="e.g. Greenwood High School" className={fieldErrors.schoolName ? 'input-error' : ''} /><span className="field-error">{fieldErrors.schoolName}</span></label><label>Email ID <em>*</em><input type="email" value={form.email} onChange={(event) => update('email', event.target.value)} placeholder="you@example.com" className={fieldErrors.email ? 'input-error' : ''} /><span className="field-error">{fieldErrors.email}</span></label><label>Contact Number <em>*</em><input value={form.contactNumber} onChange={(event) => update('contactNumber', event.target.value)} placeholder="e.g. +91 98765 43210" className={fieldErrors.contactNumber ? 'input-error' : ''} /><span className="field-error">{fieldErrors.contactNumber}</span></label><label>Learning Goal<em>*</em><select value={form.learningGoal} onChange={(event) => update('learningGoal', event.target.value)} className={fieldErrors.learningGoal ? 'input-error' : ''}><option value="">Select a goal</option><option value="Improve my grades">Improve my grades</option><option value="Understand concepts deeply">Understand concepts deeply</option><option value="Score well in exams">Score well in exams</option><option value="Build strong foundations">Build strong foundations</option><option value="Clear exam doubts">Clear exam doubts</option></select><span className="field-error">{fieldErrors.learningGoal}</span></label><div><span className="registration-label">Preferred Subjects <em>*</em></span><div className="registration-subjects">{['Mathematics', 'Science', 'English', 'Computer Science'].map((subject) => <button type="button" key={subject} className={form.preferredSubjects.includes(subject) ? 'selected' : ''} onClick={() => toggleSubject(subject)}>{form.preferredSubjects.includes(subject) ? '✓ ' : ''}{subject}</button>)}</div></div></div><span className="field-error field-error-top">{fieldErrors.preferredSubjects}</span><label className="registration-consent"><input type="checkbox" checked={terms} onChange={(event) => setTerms(event.target.checked)} /><span>✓</span>I agree to Terms &amp; Conditions</label><span className="field-error">{fieldErrors.terms}</span>{saving ? <button className="primary-button registration-submit" type="submit" disabled={saving}>Creating Your Learning DNA... <span>↗</span></button> : <button className="primary-button registration-submit" type="submit">Register <span>↗</span>}</button><small className="registration-secure">⌁ Your information is secure and used only to personalize your learning journey.</small></form></main></div>
}'''

# Find the start and end of RegistrationScreen
start_pattern = r'function RegistrationScreen\(\{ onDemo'
end_pattern = r'function DNAHelix\(\{'

start_match = re.search(start_pattern, c)
end_match = re.search(end_pattern, c)

if start_match and end_match:
    c = c[:start_match.start()] + new_screen + '\n\n' + c[end_match.start():]
    open(f, 'w', encoding='utf-8').write(c)
    print('SUCCESS')
else:
    print(f'START: {start_match is not None}, END: {end_match is not None}')
