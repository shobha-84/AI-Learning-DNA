// ---- ASSESSMENT REVIEW ENGINE ----
// Question-level insight for a completed baseline: step-by-step explanation,
// the reason a wrong answer is wrong, the misconception behind it with a
// confidence score, and the remediation to launch next.
//
// Everything here is derived from the question text and the learner's answer,
// so it works offline and stays consistent with how the answer was graded.

export interface ReviewableQuestion {
  questionId: number
  chapter: string
  concept: string
  type: string
  difficulty: string
  question: string
  options?: string[]
  correctAnswer: string
  acceptedAnswers?: string[]
}

export interface MisconceptionFinding {
  label: string
  evidence: string
  confidence: number
}

export interface RemediationPlan {
  title: string
  focus: string
  activities: string[]
}

export interface QuestionReview {
  questionId: number
  subject: string
  chapter: string
  concept: string
  questionType: string
  difficulty: string
  question: string
  options?: string[]
  userAnswer: string
  correctAnswer: string
  isCorrect: boolean
  isBlank: boolean
  steps: string[]
  whyIncorrect: string | null
  misconception: MisconceptionFinding | null
  remediation: RemediationPlan | null
}

const normalize = (value: string): string => (value || '').trim().toLowerCase().replace(/\s+/g, ' ')

const gcd = (a: number, b: number): number => (b === 0 ? a : gcd(b, a % b))
const lcm = (a: number, b: number): number => (a / gcd(a, b)) * b

const parseFraction = (value: string): { n: number; d: number } | null => {
  const match = /^\s*(\d+)\s*\/\s*(\d+)\s*$/.exec(value || '')
  return match ? { n: Number(match[1]), d: Number(match[2]) } : null
}

const toNumber = (value: string): number | null => {
  const trimmed = (value || '').trim()
  if (/^-?\d+(\.\d+)?$/.test(trimmed)) return Number(trimmed)
  const fraction = parseFraction(trimmed)
  if (fraction && fraction.d !== 0) return fraction.n / fraction.d
  return null
}

const isSameValue = (a: string, b: string): boolean => {
  const left = toNumber(a)
  const right = toNumber(b)
  if (left !== null && right !== null) return Math.abs(left - right) < 1e-9
  return normalize(a) === normalize(b)
}

// ---- STEP-BY-STEP EXPLANATIONS ----
// Each branch reads the question text and rebuilds the working, so the
// explanation always matches the question the learner actually answered.

const conceptNotes: Record<string, string> = {
  Photosynthesis: 'Plants use sunlight, water and carbon dioxide to make food (glucose), and they release oxygen during the process.',
  'Plant Parts': 'The root anchors the plant and takes in water, the stem carries water upward, the leaf makes food, and the flower helps in reproduction.',
  'Plant Functions': 'Each plant part has one job: roots absorb, stems transport, leaves make food and flowers reproduce.',
  'Skeletal System': 'The skeleton gives the body shape, protects organs such as the heart and lungs, and stores calcium.',
  'Digestive System': 'Food is broken down as it travels mouth -> esophagus -> stomach -> small intestine, where nutrients are absorbed.',
  'Respiratory System': 'The lungs take in oxygen and remove carbon dioxide; breathing rate rises when the body needs more oxygen.',
  'Circulatory System': 'The heart pumps blood, and blood carries oxygen and nutrients to every part of the body.',
  'Nervous System': 'The brain, spinal cord and nerves control thinking, sensing and all body responses.',
  'Organs': 'Each organ has a specialised job, such as the heart pumping blood and the lungs breathing.',
  'Sense Organs': 'Eyes see, ears hear, nose smells, tongue tastes and skin feels.',
  'States of Water': 'Water is solid below 0 degrees C, liquid between 0 and 100 degrees C, and a gas (steam) above 100 degrees C.',
  'Water Cycle': 'Evaporation turns water into vapour, condensation forms clouds, and precipitation returns water as rain, snow or hail.',
  'Water Sources': 'Rivers, lakes, wells and rainwater are fresh water sources; the ocean is salt water.',
  'Water Conservation': 'Saving water means using it carefully: turn off taps, repair leaks, reuse water and water plants with drip irrigation.',
  Weather: 'Weather is the condition of the atmosphere right now, while climate is the average weather over many years.',
  Temperature: 'Temperature is measured with a thermometer and shows how hot or cold something is.',
  Seasons: 'Seasons change because Earth is tilted as it orbits the Sun, which changes the daylight each hemisphere receives.',
  'Magnetic Properties': 'Iron, nickel and cobalt are magnetic; wood, plastic, glass and copper are not.',
  'Magnet Poles': 'Like poles repel and opposite poles attract; every magnet has a north and a south pole.',
  'Magnet Uses': 'Compasses, door catches and electric motors all use magnets.',
  'Magnet Direction': 'A freely suspended magnet always points north-south, which is how a compass finds direction.',
  'Water Sources and Conservation': 'Fresh water is limited, so it must be used carefully and reused whenever possible.',
  'Human Body': 'The body works as a system: organs and systems each depend on the others to stay healthy.',
}

const fractionOfSteps = (n: number, d: number, whole: number, answer: string): string[] => [
  `"${n}/${d} of ${whole}" means: divide ${whole} into ${d} equal parts, then take ${n} of those parts.`,
  `Step 1: Divide by the denominator -> ${whole} ÷ ${d} = ${whole / d}.`,
  `Step 2: Multiply by the numerator -> ${whole / d} × ${n} = ${answer}.`,
  `So the answer is ${answer}.`,
]

const additionSteps = (a: { n: number; d: number }, b: { n: number; d: number }, answer: string): string[] => {
  if (a.d === b.d) {
    return [
      `The denominators match (${a.d}), so keep ${a.d} and add only the numerators.`,
      `Step 1: Add the numerators -> ${a.n} + ${b.n} = ${a.n + b.n}.`,
      `Step 2: Keep the same denominator -> ${a.n + b.n}/${a.d}.`,
      `So the answer is ${answer}.`,
    ]
  }
  const common = lcm(a.d, b.d)
  const na = (a.n * common) / a.d
  const nb = (b.n * common) / b.d
  return [
    `The denominators are different (${a.d} and ${b.d}), so first make them the same.`,
    `Step 1: Find a common denominator -> ${common}.`,
    `Step 2: Rewrite both fractions -> ${na}/${common} + ${nb}/${common}.`,
    `Step 3: Add the numerators -> ${na} + ${nb} = ${na + nb}.`,
    `So the answer is ${answer}.`,
  ]
}

const simplifySteps = (n: number, d: number, answer: string): string[] => {
  const divisor = gcd(n, d)
  return [
    `To simplify, divide the numerator and denominator by their highest common factor.`,
    `Step 1: Highest common factor of ${n} and ${d} is ${divisor}.`,
    `Step 2: Divide both parts -> ${n} ÷ ${divisor} = ${n / divisor} and ${d} ÷ ${divisor} = ${d / divisor}.`,
    `So the answer is ${answer}.`,
  ]
}

const comparisonSteps = (a: { n: number; d: number }, b: { n: number; d: number }, answer: string, larger: boolean): string[] => {
  const word = larger ? 'larger' : 'smaller'
  const left = a.n * b.d
  const right = b.n * a.d
  const winner = left === right ? 'Equal' : (left > right ? `${a.n}/${a.d}` : `${b.n}/${b.d}`)
  return [
    `You cannot compare two fractions by looking at the numerators alone.`,
    `Step 1: Cross multiply -> ${a.n} × ${b.d} = ${left} and ${b.n} × ${a.d} = ${right}.`,
    `Step 2: Compare the results -> ${left} ${left === right ? '=' : left > right ? '>' : '<'} ${right}.`,
    `Step 3: The ${word} fraction is ${winner}, so the answer is ${answer}.`,
  ]
}

const equivalentSteps = (n: number, d: number, answer: string): string[] => {
  const candidate = parseFraction(answer)
  const factor = candidate ? candidate.n / n : 2
  return [
    `Equivalent fractions have the same value, so multiply the numerator and the denominator by the same number.`,
    `Step 1: Multiply ${n} and ${d} by ${factor}.`,
    `Step 2: ${n} × ${factor} = ${candidate ? candidate.n : n * factor} and ${d} × ${factor} = ${candidate ? candidate.d : d * factor}.`,
    `So the equivalent fraction is ${answer}.`,
  ]
}

const sequenceOf = (text: string): number[] =>
  (text.match(/-?\d+(?:\.\d+)?/g) || []).map(Number)

const patternSteps = (series: number[], answer: string): string[] => {
  const diffs = series.slice(1).map((value, i) => value - series[i])
  const ratios = series.slice(1).map((value, i) => (series[i] === 0 ? 0 : value / series[i]))
  const sameDiff = diffs.every(d => d === diffs[0])
  const sameRatio = ratios.every(r => r === ratios[0])

  if (sameRatio && ratios[0] !== 1) {
    return [
      `Each term is obtained by multiplying the previous term by ${ratios[0]}.`,
      `Step 1: Find the rule -> ${series[0]} × ${ratios[0]} = ${series[1]}.`,
      `Step 2: Continue the rule -> ${series[series.length - 1]} × ${ratios[0]} = ${answer}.`,
      `So the missing term is ${answer}.`,
    ]
  }
  if (sameDiff) {
    return [
      `Each term increases by the same amount.`,
      `Step 1: Find the rule -> ${series[1]} − ${series[0]} = ${diffs[0]}.`,
      `Step 2: Continue the rule -> ${series[series.length - 1]} + ${diffs[0]} = ${answer}.`,
      `So the missing term is ${answer}.`,
    ]
  }
  return [
    `Work out how each term is built from the previous one, then apply that rule once more.`,
    `Step 1: The series is ${series.join(', ')}.`,
    `Step 2: Applying the rule to the last term gives ${answer}.`,
    `So the answer is ${answer}.`,
  ]
}

const likeTermsSteps = (expression: string, answer: string): string[] => {
  const terms: { letter: string; coefficient: number }[] = []
  const pattern = /([+-])?\s*(\d*)\s*([a-z])/gi
  let match: RegExpExecArray | null
  while ((match = pattern.exec(expression)) !== null) {
    const sign = match[1] === '-' ? -1 : 1
    const coefficient = (match[2] ? Number(match[2]) : 1) * sign
    const letter = match[3].toLowerCase()
    const existing = terms.find(t => t.letter === letter)
    if (existing) existing.coefficient += coefficient
    else terms.push({ letter, coefficient })
  }
  const parts = terms.map(t => `${t.coefficient === 1 ? '' : t.coefficient === -1 ? '-' : `${t.coefficient} `}${t.letter}`)
  return [
    `Only like terms can be combined, meaning terms with the same variable.`,
    `Step 1: Group the terms by variable -> ${parts.length} group${parts.length === 1 ? '' : 's'}.`,
    `Step 2: Add the coefficients of each group -> ${answer}.`,
    `So the simplified expression is ${answer}.`,
  ]
}

const equationSteps = (steps: string[]): string[] => steps

export const buildExplanationSteps = (question: ReviewableQuestion): string[] => {
  const text = question.question
  const answer = question.correctAnswer

  let match = /(\d+)\s*\/\s*(\d+)\s+of\s+(\d+)/i.exec(text)
  if (match) return fractionOfSteps(Number(match[1]), Number(match[2]), Number(match[3]), answer)

  match = /(\d+)\s*\/\s*(\d+)\s*\+\s*(\d+)\s*\/\s*(\d+)/.exec(text)
  if (match) {
    return additionSteps(
      { n: Number(match[1]), d: Number(match[2]) },
      { n: Number(match[3]), d: Number(match[4]) },
      answer
    )
  }

  match = /simplify[:\s]+(\d+)\s*\/\s*(\d+)/i.exec(text)
  if (match) return simplifySteps(Number(match[1]), Number(match[2]), answer)

  match = /(larger|smaller|greater|more)[:\s]+(\d+)\s*\/\s*(\d+)\s*(?:or|and)\s*(\d+)\s*\/\s*(\d+)/i.exec(text)
  if (match) {
    return comparisonSteps(
      { n: Number(match[2]), d: Number(match[3]) },
      { n: Number(match[4]), d: Number(match[5]) },
      answer,
      /larger|greater|more/i.test(match[1])
    )
  }

  match = /equivalent to\s+(\d+)\s*\/\s*(\d+)/i.exec(text)
  if (match) return equivalentSteps(Number(match[1]), Number(match[2]), answer)

  match = /if\s+([a-z])\s*=\s*(-?\d+)\s*,\s*what is\s+([0-9a-z+\-*/()\s]+?)\??$/i.exec(text)
  if (match) {
    const variable = match[1]
    const value = match[2]
    // Parenthesised so a value such as 3 cannot run into a digit already in the
    // expression and read as a two-digit number.
    const substituted = match[3].replace(new RegExp(variable, 'gi'), `(${value})`)
    return equationSteps([
      `Replace the variable with its given value.`,
      `Step 1: ${variable} = ${value}.`,
      `Step 2: Substitute -> ${match[3]} becomes ${substituted}.`,
      `Step 3: Work it out -> the result is ${answer}.`,
    ])
  }

  match = /if\s+([a-z])\s*([+\-])\s*(\d+)\s*=\s*(\d+)/i.exec(text)
  if (match) {
    const operator = match[2] as '+' | '-'
    const inverse = operator === '+' ? 'subtracting' : 'adding'
    const symbol = operator === '+' ? '−' : '+'
    const amount = Number(match[3])
    const total = Number(match[4])
    return equationSteps([
      `Keep the equation balanced by ${inverse} ${amount} from both sides.`,
      `Step 1: ${operator} ${amount} on both sides -> ${match[1]} = ${total} ${symbol} ${amount}.`,
      `Step 2: ${total} ${symbol} ${amount} = ${answer}.`,
      `So ${match[1]} = ${answer}.`,
    ])
  }

  match = /solve[:\s]+(\d*)\s*([a-z])\s*=\s*(\d+)/i.exec(text)
  if (match) {
    const divisor = match[1] ? Number(match[1]) : 1
    const total = Number(match[3])
    return equationSteps([
      match[1]
        ? `Divide both sides by ${divisor} so the coefficient of ${match[2]} becomes 1.`
        : `The variable stands for the value on the right-hand side.`,
      `Step 1: ${match[1] ? `${total} ÷ ${divisor} = ${total / divisor}.` : `Read ${match[2]} straight from the equation.`}`,
      `Step 2: The value is ${answer}.`,
    ])
  }

  match = /solve[:\s]+([a-z])\s*\/\s*(\d+)\s*=\s*(\d+)/i.exec(text)
  if (match) {
    const divisor = Number(match[2])
    const result = Number(match[3])
    return equationSteps([
      `Multiply both sides by ${divisor} to remove the division.`,
      `Step 1: ${divisor} on both sides -> ${match[1]} = ${divisor} × ${result}.`,
      `Step 2: ${divisor} × ${result} = ${answer}.`,
      `So ${match[1]} = ${answer}.`,
    ])
  }

  match = /length \(([a-z])\s*\+\s*(\d+)\) and width \1\b.*?perimeter is (\d+)/i.exec(text)
  if (match) {
    const variable = match[1]
    const extra = Number(match[2])
    const perimeter = Number(match[3])
    // Perimeter is 2 * (length + width), which expands to 4x + 2 * extra.
    const value = (perimeter - 2 * extra) / 4
    return [
      `The perimeter of a rectangle is 2 × (length + width).`,
      `Step 1: Substitute the sides -> 2 × ((${variable} + ${extra}) + ${variable}).`,
      `Step 2: Expand -> 4${variable} + ${2 * extra} = ${perimeter}.`,
      `Step 3: Subtract ${2 * extra} from both sides -> 4${variable} = ${perimeter - 2 * extra}.`,
      `Step 4: Divide by 4 -> ${variable} = ${value}.`,
      `Check: 2 × ((${value} + ${extra}) + ${value}) = ${2 * (value + extra + value)} = ${perimeter}.`,
      `So the answer is ${answer}.`,
    ]
  }

  match = /you have (\d+)\s*\/\s*(\d+).*?friend has (\d+)\s*\/\s*(\d+)/i.exec(text)
  if (match) {
    const mine = { n: Number(match[1]), d: Number(match[2]) }
    const theirs = { n: Number(match[3]), d: Number(match[4]) }
    return comparisonSteps(mine, theirs, answer, true)
  }

  match = /simplify[:\s]+([0-9a-z+\-*\s]+)$/i.exec(text.trim())
  if (match && /[a-z]/i.test(match[1])) return likeTermsSteps(match[1], answer)

  match = /(?:next|pattern)[:\s]+(.*?)_{2,}/i.exec(text)
  if (match) {
    const series = sequenceOf(match[1])
    if (series.length >= 3) return patternSteps(series, answer)
  }

  const note = conceptNotes[question.concept]
  if (note) {
    return [
      note,
      `Step 1: Recall what "${question.concept}" means.`,
      `Step 2: Compare that fact with the question.`,
      `Step 3: The correct choice is ${answer}.`,
    ]
  }

  return [
    `Step 1: Read what the question is asking for.`,
    `Step 2: Apply the rule for ${question.concept}.`,
    `Step 3: The correct answer is ${answer}.`,
  ]
}



// ---- MISCONCEPTION DETECTION ----

interface NumericPath {
  value: number
  label: string
  evidence: string
}

const numericPaths = (question: ReviewableQuestion): NumericPath[] => {
  const text = question.question
  const paths: NumericPath[] = []

  let match = /(\d+)\s*\/\s*(\d+)\s+of\s+(\d+)/i.exec(text)
  if (match) {
    const n = Number(match[1])
    const d = Number(match[2])
    const whole = Number(match[3])
    paths.push(
      {
        value: n * whole,
        label: 'Fraction of Quantity Misunderstanding',
        evidence: `multiplied ${whole} by ${n} (the numerator) but did not divide by ${d} (the denominator) first.`,
      },
      {
        value: n * d,
        label: 'Fraction of Quantity Misunderstanding',
        evidence: `multiplied the two parts of the fraction together (${n} × ${d}) instead of applying the fraction to ${whole}.`,
      },
      {
        value: whole / d,
        label: 'Denominator-Only Error',
        evidence: `divided ${whole} by ${d} but stopped there without multiplying by the numerator ${n}.`,
      },
      {
        value: whole * d,
        label: 'Fraction of Quantity Misunderstanding',
        evidence: `multiplied ${whole} by ${d} (the denominator) instead of dividing by it first.`,
      },
      {
        value: whole - d,
        label: 'Part-Whole Reversal',
        evidence: `took ${d} away from ${whole} instead of finding what ${n}/${d} of ${whole} is.`,
      },
      {
        value: whole - n,
        label: 'Part-Whole Reversal',
        evidence: `took the numerator away from the whole number instead of finding the fraction of it.`,
      },
      {
        value: whole / n,
        label: 'Numerator-Denominator Confusion',
        evidence: `divided by the numerator ${n} instead of the denominator ${d}.`,
      },
      {
        value: n + d,
        label: 'Numerator-Denominator Confusion',
        evidence: `added the numerator and the denominator together instead of using the fraction on ${whole}.`,
      },
      {
        value: whole - whole / d,
        label: 'Part-Whole Reversal',
        evidence: `calculated the part NOT taken and gave the remainder instead.`,
      }
    )
  }

  match = /(\d+)\s*\/\s*(\d+)\s*\+\s*(\d+)\s*\/\s*(\d+)/.exec(text)
  if (match) {
    const a = { n: Number(match[1]), d: Number(match[2]) }
    const b = { n: Number(match[3]), d: Number(match[4]) }
    const wrong = (a.n + b.n) / (a.d + b.d)
    paths.push({
      value: wrong,
      label: 'Fraction Denominator Confusion',
      evidence: `added the numerators and the denominators together (${a.n}/${a.d} + ${b.n}/${b.d} treated as ${a.n + b.n}/${a.d + b.d}) instead of making the denominators match.`,
    })
    paths.push({
      value: a.n / b.d,
      label: 'Fraction Denominator Confusion',
      evidence: `used the numerator of one fraction over the denominator of the other.`,
    })
  }

  match = /(larger|smaller|greater|more)[:\s]+(\d+)\s*\/\s*(\d+)\s*(?:or|and)\s*(\d+)\s*\/\s*(\d+)/i.exec(text)
  if (match) {
    const a = { n: Number(match[2]), d: Number(match[3]) }
    const b = { n: Number(match[4]), d: Number(match[5]) }
    if (a.n !== b.n) {
      paths.push({
        value: a.n < b.n ? a.d / a.n : a.n / a.d,
        label: 'Numerator Comparison Error',
        evidence: `compared the numerators directly (${a.n} against ${b.n}) instead of cross multiplying.`,
      })
    }
    if (a.d !== b.d) {
      paths.push({
        value: a.d < b.d ? a.d / a.n : a.n / a.d,
        label: 'Denominator Comparison Error',
        evidence: `compared the denominators directly (${a.d} against ${b.d}) and picked the wrong fraction because of it.`,
      })
    }
  }

  match = /equivalent to\s+(\d+)\s*\/\s*(\d+)/i.exec(text)
  if (match) {
    const n = Number(match[1])
    const d = Number(match[2])
    paths.push({ value: n / (d * 2), label: 'Numerator-Denominator Confusion', evidence: `kept the numerator and doubled the denominator instead of scaling both parts equally.` })
    paths.push({ value: (n * 2) / d, label: 'Numerator-Denominator Confusion', evidence: `doubled the numerator but left the denominator unchanged.` })
  }

  match = /if\s+([a-z])\s*=\s*(-?\d+)\s*,\s*what is\s+([0-9a-z+\-*/()\s]+?)\??$/i.exec(text)
  if (match) {
    const substituted = match[3].replace(new RegExp(match[1], 'gi'), match[2])
    const expected = toNumber(question.correctAnswer) ?? answerOf(match[3])
    paths.push({
      value: -expected,
      label: 'Sign Confusion',
      evidence: `lost the sign while substituting the value for ${match[1]}.`,
    })
    paths.push({
      value: toNumberSafe(substituted) * 2,
      label: 'Arithmetic Slip',
      evidence: 'substituted correctly but made an arithmetic error in the final step.',
    })
  }

  match = /if\s+([a-z])\s*([+\-])\s*(\d+)\s*=\s*(\d+)/i.exec(text)
  if (match) {
    const op = match[2] === '+' ? '+' : '-'
    const inverted = match[2] === '+' ? Number(match[3]) + Number(match[4]) : Number(match[4]) - Number(match[3])
    paths.push({
      value: inverted,
      label: 'Inverse Operation Error',
      evidence: `applied ${op === '+' ? 'addition' : 'subtraction'} instead of the inverse operation when isolating the variable.`,
    })
  }

  match = /you have (\d+)\s*\/\s*(\d+).*?friend has (\d+)\s*\/\s*(\d+)/i.exec(text)
  if (match) {
    const mine = { n: Number(match[1]), d: Number(match[2]) }
    const theirs = { n: Number(match[3]), d: Number(match[4]) }
    paths.push({
      value: mine.n < theirs.n ? mine.d / mine.n : mine.n / mine.d,
      label: 'Numerator Comparison Error',
      evidence: `compared the numerators directly (${mine.n} against ${theirs.n}) instead of cross multiplying.`,
    })
    paths.push({
      value: mine.d < theirs.d ? mine.d / mine.n : mine.n / mine.d,
      label: 'Denominator Comparison Error',
      evidence: `compared the denominators directly (${mine.d} against ${theirs.d}) and picked the wrong share because of it.`,
    })
  }

  return paths.filter(path => Number.isFinite(path.value))
}

const answerOf = (expression: string): number => toNumberSafe(expression) || 0

// Minimal left-to-right evaluator for the arithmetic left after the variable
// letters are substituted. Deliberately not eval: the input is learner data.
const evaluateArithmetic = (expression: string): number => {
  const cleaned = (expression || '').replace(/[^0-9+\-*/.\s]/g, ' ').trim()
  if (!cleaned || !/[0-9]/.test(cleaned)) return NaN

  const tokens = cleaned.match(/\d+(?:\.\d+)?|[+\-*/]/g)
  if (!tokens) return NaN

  let total = Number(tokens[0])
  if (!Number.isFinite(total)) return NaN

  // Multiplication and division bind tighter than addition and subtraction.
  const apply = (operator: string, left: number, right: number): number => {
    switch (operator) {
      case '+': return left + right
      case '-': return left - right
      case '*': return left * right
      case '/': return right === 0 ? NaN : left / right
      default: return NaN
    }
  }

  for (let i = 1; i < tokens.length; i += 2) {
    total = apply(tokens[i], total, Number(tokens[i + 1]))
    if (!Number.isFinite(total)) return NaN
  }
  return total
}

const toNumberSafe = (value: string): number => {
  const direct = toNumber(value)
  if (direct !== null) return direct
  return evaluateArithmetic(value)
}

// A true transposition keeps the same digits, only in the wrong positions. Two
// positions differing is not enough on its own: 24 against 32 also differs twice
// but shares no digits, so the digit sets are compared as well.
const transposed = (given: number, correct: number): boolean => {
  const a = String(given)
  const b = String(correct)
  if (a === b || a.length !== b.length) return false
  if (!/^\d+$/.test(a) || !/^\d+$/.test(b)) return false
  const sortedA = a.split('').sort().join('')
  const sortedB = b.split('').sort().join('')
  if (sortedA !== sortedB) return false
  return a.split('').filter((digit, i) => digit !== b[i]).length === 2
}

const baseConfidence = (label: string): number => {
  switch (label) {
    case 'No Attempt Recorded': return 96
    case 'Fraction of Quantity Misunderstanding': return 88
    case 'Denominator-Only Error':
    case 'Fraction Denominator Confusion':
    case 'Fraction Comparison Error':
    case 'Inverse Operation Error':
    case 'Numerator Comparison Error':
    case 'Denominator Comparison Error':
    case 'Numerator-Denominator Confusion':
    case 'Part-Whole Reversal':
    case 'Sign Confusion':
    case 'Place Value Error': return 82
    case 'Arithmetic Slip': return 68
    case 'Incomplete Simplification': return 74
    case 'Rote Memorisation': return 58
    case 'Fact Recall Weakness': return 62
    case 'Distractor Selection': return 54
    default: return 60
  }
}

// When the exact arithmetic path does not match, the concept still points at the
// method that was most likely skipped, which is far more useful to the learner
// than "a distractor was chosen".
const conceptFallbacks: Record<string, { label: string; evidence: string }> = {
  'Fraction of a Whole': {
    label: 'Fraction of Quantity Misunderstanding',
    evidence: 'the quantity was not split into denominator-sized parts before the numerator was applied.',
  },
  'Fraction Comparison': {
    label: 'Fraction Comparison Error',
    evidence: 'the two fractions were compared without cross multiplying them first.',
  },
  'Fraction Addition': {
    label: 'Fraction Denominator Confusion',
    evidence: 'the denominators were not made equal before the numerators were added.',
  },
  'Equivalent Fractions': {
    label: 'Numerator-Denominator Confusion',
    evidence: 'the numerator and denominator were not scaled by the same factor.',
  },
  Simplification: {
    label: 'Incomplete Simplification',
    evidence: 'the common factor was not cancelled in both the numerator and the denominator.',
  },
  'Basic Equations': {
    label: 'Inverse Operation Error',
    evidence: 'the inverse operation was not applied to both sides of the equation.',
  },
  Variables: {
    label: 'Inverse Operation Error',
    evidence: 'the equation was not kept balanced while isolating the variable.',
  },
  Substitution: {
    label: 'Substitution Error',
    evidence: 'the given value was not substituted carefully for the variable.',
  },
  'Pattern Recognition': {
    label: 'Pattern Rule Misread',
    evidence: 'the rule generating each term was not identified before extending the series.',
  },
  'Algebraic Expressions': {
    label: 'Like Terms Confusion',
    evidence: 'terms that do not share a variable were combined.',
  },
}

const detectMisconception = (
  question: ReviewableQuestion,
  userAnswer: string,
  frequencySeed: Map<string, number>
): MisconceptionFinding | null => {
  const given = normalize(userAnswer)
  if (!given) {
    return {
      label: 'No Attempt Recorded',
      evidence: 'the question was left blank, so no reasoning could be read from the answer.',
      confidence: 96,
    }
  }

  for (const path of numericPaths(question)) {
    const value = toNumber(userAnswer)
    if (value !== null && Math.abs(value - path.value) < 1e-9) {
      return finish(path.label, path.evidence, frequencySeed)
    }
  }

  // "Who has more, X or Y" is answered with a word, so the numeric error paths
  // above can never match it. The mistake is always the same though: the two
  // shares were compared without cross multiplying.
  if (/you have \d+\s*\/\s*\d+.*?friend has \d+\s*\/\s*\d+/i.test(question.question)) {
    const pickedFriend = /\b(friend|they|them|he|she)\b/.test(given)
    return finish(
      pickedFriend ? 'Numerator Comparison Error' : 'Denominator Comparison Error',
      pickedFriend
        ? 'the smaller share was chosen, which happens when the fractions are compared by their numerators instead of being cross multiplied.'
        : 'the larger share was rejected, which happens when a bigger denominator is assumed to mean a bigger share.',
      frequencySeed
    )
  }

  const correct = toNumber(question.correctAnswer)
  const value = toNumber(userAnswer)

  // Fraction structure is checked before raw values: a fraction can share the
  // correct value and still be wrong, and only its parts reveal why.
  const givenFraction = parseFraction(given)
  const correctFraction = parseFraction(question.correctAnswer)
  if (givenFraction && correctFraction) {
    if (givenFraction.n === correctFraction.n || givenFraction.d === correctFraction.d) {
      return finish(
        'Numerator-Denominator Confusion',
        'one part of the fraction was changed while the other was left exactly as it should be.',
        frequencySeed
      )
    }
    // Same value, just not reduced: the learner stopped before cancelling.
    const givenValue = givenFraction.d === 0 ? NaN : givenFraction.n / givenFraction.d
    const correctValue = correctFraction.d === 0 ? NaN : correctFraction.n / correctFraction.d
    if (Number.isFinite(givenValue) && Math.abs(givenValue - correctValue) < 1e-9) {
      return finish(
        'Incomplete Simplification',
        'the fraction has the right value but was left unreduced instead of being simplified.',
        frequencySeed
      )
    }
  }

  if (correct !== null && value !== null) {
    if (transposed(value, correct)) {
      return finish('Place Value Error', 'the digits of the answer are in the wrong places, which points to weak place-value tracking.', frequencySeed)
    }
    if (value * correct < 0 && Math.abs(Math.abs(value) - Math.abs(correct)) < 1e-9) {
      return finish('Sign Confusion', 'the magnitude is right but the sign was dropped.', frequencySeed)
    }
    if (Math.abs(value - correct - 1) < 1e-9 || Math.abs(value - correct + 1) < 1e-9) {
      return finish('Arithmetic Slip', 'the answer is only one step away from the correct value, so the method is nearly right.', frequencySeed)
    }
  }

  if (question.type === 'truefalse') {
    return finish('Fact Recall Weakness', `the statement was judged "${userAnswer}" when the underlying fact does not support that answer.`, frequencySeed)
  }

  const conceptFallback = conceptFallbacks[question.concept]
  if (conceptFallback) {
    return finish(conceptFallback.label, conceptFallback.evidence, frequencySeed)
  }

  if (question.options && question.options.some(option => isSameValue(option, userAnswer))) {
    return finish('Distractor Selection', 'a listed but incorrect option was chosen, which usually means the underlying rule was not applied.', frequencySeed)
  }

  if (['reasoning', 'criticalthinking', 'problemsolving', 'viva'].includes(question.type)) {
    // An answer that only echoes the words in the question has been recalled from
    // the wording rather than reasoned out.
    const questionWords = new Set(
      question.question.toLowerCase().match(/[a-z]{4,}/g) || []
    )
    const answerWords = (userAnswer.toLowerCase().match(/[a-z]{4,}/g) || [])
      .filter(word => questionWords.has(word))
    if (answerWords.length > 0 && answerWords.length >= answerWords.length / 2) {
      return finish(
        'Rote Memorisation',
        'the answer repeats the wording of the question rather than applying the underlying idea.',
        frequencySeed
      )
    }
    return finish('Concept Misunderstanding', 'the reasoning described does not match the method required for this concept.', frequencySeed)
  }

  return finish('Arithmetic Slip', 'the working behind the answer does not lead to the correct result.', frequencySeed)
}

const finish = (label: string, evidence: string, frequencySeed: Map<string, number>): MisconceptionFinding => {
  const seen = (frequencySeed.get(label) || 0) + 1
  frequencySeed.set(label, seen)
  // A misconception seen on several questions is a habit, not a one-off slip, so
  // the evidence for it becomes stronger.
  const confidence = Math.min(97, baseConfidence(label) + (seen - 1) * 6)
  return { label, evidence, confidence }
}

// ---- REMEDIATION ----

const remediationByConcept: Record<string, { title: string; focus: string }> = {
  'Fraction Addition': { title: 'Adding Fractions', focus: 'Making denominators match before adding numerators.' },
  'Equivalent Fractions': { title: 'Equivalent Fractions', focus: 'Scaling the numerator and the denominator by the same number.' },
  'Fraction Comparison': { title: 'Comparing Fractions', focus: 'Cross multiplication as a reliable way to compare any two fractions.' },
  Simplification: { title: 'Simplifying Fractions', focus: 'Finding and cancelling the highest common factor.' },
  'Fraction of a Whole': { title: 'Fractions of Quantities', focus: 'Divide by the denominator first, then multiply by the numerator.' },
  Variables: { title: 'Solving for a Variable', focus: 'Keeping an equation balanced while isolating the letter.' },
  'Basic Equations': { title: 'One-Step Equations', focus: 'Applying the inverse operation to both sides of an equation.' },
  'Pattern Recognition': { title: 'Number Patterns', focus: 'Finding the rule that generates each term.' },
  'Algebraic Expressions': { title: 'Combining Like Terms', focus: 'Adding coefficients of terms that share a variable.' },
  Substitution: { title: 'Substituting Values', focus: 'Replacing a variable with its value and simplifying carefully.' },
  Photosynthesis: { title: 'How Plants Make Food', focus: 'The inputs and outputs of photosynthesis.' },
  'Plant Parts': { title: 'Parts of a Plant', focus: 'Matching each plant part to its job.' },
  'Plant Functions': { title: 'What Each Plant Part Does', focus: 'Transport, absorption and reproduction in plants.' },
  'Skeletal System': { title: 'The Skeletal System', focus: 'Support, protection and calcium storage.' },
  'Digestive System': { title: 'The Digestive System', focus: 'The path food takes through the body.' },
  'Respiratory System': { title: 'Breathing and the Lungs', focus: 'Oxygen uptake and carbon dioxide removal.' },
  'Circulatory System': { title: 'The Circulatory System', focus: 'How the heart and blood deliver oxygen.' },
  'Nervous System': { title: 'The Nervous System', focus: 'How the brain, spinal cord and nerves control the body.' },
  Organs: { title: 'Organs and Their Jobs', focus: 'The specialised role of each major organ.' },
  'Sense Organs': { title: 'The Five Sense Organs', focus: 'Which organ handles which sense.' },
  'States of Water': { title: 'States of Water', focus: 'Solid, liquid and gas at different temperatures.' },
  'Water Cycle': { title: 'The Water Cycle', focus: 'Evaporation, condensation and precipitation.' },
  'Water Sources': { title: 'Sources of Water', focus: 'Fresh water against salt water.' },
  'Water Conservation': { title: 'Conserving Water', focus: 'Practical ways to reduce water waste.' },
  Weather: { title: 'Weather and Climate', focus: 'Short-term conditions against long-term averages.' },
  Temperature: { title: 'Measuring Temperature', focus: 'Reading a thermometer correctly.' },
  Seasons: { title: 'Why Seasons Change', focus: 'Earth\'s tilt and the daylight it causes.' },
  'Magnetic Properties': { title: 'Magnetic and Non-magnetic Materials', focus: 'Which materials a magnet attracts.' },
  'Magnet Poles': { title: 'Attract and Repel', focus: 'Like poles repel, opposite poles attract.' },
  'Magnet Uses': { title: 'Uses of Magnets', focus: 'Compasses, catches and motors.' },
  'Magnet Direction': { title: 'Finding Direction', focus: 'How a compass uses a magnet to point north.' },
  'Human Body': { title: 'Body Systems Working Together', focus: 'How the systems depend on each other.' },
}

const buildRemediation = (question: ReviewableQuestion, misconception: MisconceptionFinding | null): RemediationPlan => {
  const mapped = remediationByConcept[question.concept] || {
    title: question.concept,
    focus: `Review the core idea behind ${question.concept}.`,
  }
  const activities = [
    `Work through the worked examples for ${mapped.title.toLowerCase()}.`,
    'Read the learner document for this chapter to see the rule stated clearly.',
    'Attempt 10 targeted practice questions on this skill.',
    'Retake the chapter assessment once the practice set feels easy.',
  ]
  if (misconception && misconception.label !== 'Arithmetic Slip') {
    activities.unshift(`Focus on avoiding this specific error: ${misconception.label.toLowerCase()}.`)
  }
  return { title: mapped.title, focus: mapped.focus, activities }
}

// ---- REVIEW BUILDER ----

export const buildQuestionReview = (
  question: ReviewableQuestion,
  result: { questionId: number; isCorrect: boolean; userAnswer: string; correctAnswer: string },
  subject: string,
  frequencySeed: Map<string, number>
): QuestionReview => {
  const isCorrect = result.isCorrect
  const userAnswer = result.userAnswer || ''
  const misconception = isCorrect ? null : detectMisconception(question, userAnswer, frequencySeed)
  const steps = buildExplanationSteps(question)

  let whyIncorrect: string | null = null
  if (!isCorrect) {
    const given = userAnswer.trim() || 'no answer'
    const because = misconception?.evidence ? ` ${capitalize(misconception.evidence)}` : ''
    const concept = misconception && misconception.label === 'Arithmetic Slip'
      ? ''
      : ` This indicates a weakness in ${question.concept.toLowerCase()}.`
    whyIncorrect = `You answered "${given}" but the correct answer is "${question.correctAnswer}".${because}${concept}`
  }

  return {
    questionId: question.questionId,
    subject,
    chapter: question.chapter,
    concept: question.concept,
    questionType: question.type,
    difficulty: question.difficulty,
    question: question.question,
    options: question.options,
    userAnswer,
    correctAnswer: question.correctAnswer,
    isCorrect,
    isBlank: !userAnswer.trim(),
    steps,
    whyIncorrect,
    misconception,
    remediation: isCorrect ? null : buildRemediation(question, misconception),
  }
}

const capitalize = (value: string): string => value.charAt(0).toUpperCase() + value.slice(1)