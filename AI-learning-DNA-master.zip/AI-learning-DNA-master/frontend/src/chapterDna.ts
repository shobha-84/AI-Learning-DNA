// ---- AI-POWERED CHAPTER DNA ----
// Turns one chapter attempt into the full learner intelligence profile shown in
// the Chapter DNA modal: concept mastery, strengths, gaps, misconceptions,
// learning risk, predictive insights, readiness, an AI coach plan, remediation
// resources and the growth trend.
//
// Everything is derived from the attempt's per-question results, so the profile
// always explains itself instead of asserting a score.

import { buildQuestionReview, type QuestionReview, type ReviewableQuestion } from './assessmentReview'

export type MasteryLevel = 'Emerging' | 'Developing' | 'Proficient' | 'Mastered'
export type RiskLevel = 'Low' | 'Medium' | 'High'

export interface AttemptQuestionResult {
  questionId: number
  isCorrect: boolean
  concept: string
  questionType: string
  userAnswer: string
  correctAnswer: string
  difficulty: string
}

export interface AttemptSummary {
  attempt: number
  kind: 'assessment' | 'retest'
  score: number
  date: string
}

export interface ConceptMastery {
  concept: string
  mastery: number
  correct: number
  total: number
}

export interface MisconceptionSummary {
  label: string
  description: string
  confidence: number
  occurrences: number
  questionIds: number[]
  // Concepts this misconception was seen on, so advice can be tied to a concept.
  concepts: string[]
}

export interface RiskInsight {
  level: RiskLevel
  reason: string
}

export interface ReadinessInsight {
  score: number
  ready: boolean
  nextChapter: string | null
  revisionConcepts: string[]
}

export interface CoachPlan {
  focusArea: string
  minutes: number
  modes: string[]
  recommendation: string
}

export interface RemediationResource {
  id: string
  label: string
  icon: string
  detail: string
  mode: 'document' | 'ppt' | 'voice' | 'video'
}

export interface EvolutionPoint {
  label: string
  score: number
  kind: 'assessment' | 'retest'
}

export interface ChapterDnaProfile {
  score: number
  version: number
  date: string
  mastery: number
  masteryLevel: MasteryLevel
  cognitive: { label: string; value: number }[]
  conceptMastery: ConceptMastery[]
  strengths: ConceptMastery[]
  gaps: ConceptMastery[]
  misconceptions: MisconceptionSummary[]
  risk: RiskInsight
  predictive: PredictiveInsight
  readiness: ReadinessInsight
  coach: CoachPlan
  resources: RemediationResource[]
  evolution: EvolutionPoint[]
  trend: number
  reviews: QuestionReview[]
  hasQuestionDetail: boolean
}

// ---- PREREQUISITE KNOWLEDGE GRAPH ----
// Which concepts unlock which later ones. This is what lets the profile reason
// forward: a weak concept puts the concepts that depend on it at risk.

interface ConceptLink {
  unlocks: string[]
  nextChapter: string
}

const CONCEPT_GRAPH: Record<string, ConceptLink> = {
  'Fraction Basics': { unlocks: ['Equivalent Fractions', 'Fraction Comparison', 'Simplification', 'Fraction of a Whole'], nextChapter: 'Decimals' },
  'Fraction Addition': { unlocks: ['Fraction of a Whole'], nextChapter: 'Decimals' },
  'Equivalent Fractions': { unlocks: ['Fraction Comparison', 'Simplification'], nextChapter: 'Decimals' },
  'Fraction Comparison': { unlocks: ['Decimals', 'Percentages', 'Ratio & Proportion'], nextChapter: 'Decimals' },
  Simplification: { unlocks: ['Fraction Comparison', 'Fraction of a Whole'], nextChapter: 'Decimals' },
  'Fraction of a Whole': { unlocks: ['Ratio & Proportion', 'Percentages'], nextChapter: 'Ratio & Proportion' },
  Variables: { unlocks: ['Basic Equations', 'Substitution'], nextChapter: 'Linear Equations' },
  'Basic Equations': { unlocks: ['Algebraic Expressions'], nextChapter: 'Linear Equations' },
  Substitution: { unlocks: ['Algebraic Expressions'], nextChapter: 'Linear Equations' },
  'Pattern Recognition': { unlocks: ['Algebraic Expressions'], nextChapter: 'Linear Equations' },
  'Algebraic Expressions': { unlocks: ['Linear Equations'], nextChapter: 'Linear Equations' },
  'Plant Parts': { unlocks: ['Plant Functions', 'Photosynthesis'], nextChapter: 'Plant Life Cycles' },
  'Plant Functions': { unlocks: ['Photosynthesis'], nextChapter: 'Plant Life Cycles' },
  Photosynthesis: { unlocks: ['Plant Life Cycles'], nextChapter: 'Plant Life Cycles' },
  'Skeletal System': { unlocks: ['Human Body'], nextChapter: 'Circulatory System' },
  'Digestive System': { unlocks: ['Human Body'], nextChapter: 'Nervous System' },
  'Respiratory System': { unlocks: ['Circulatory System'], nextChapter: 'Circulatory System' },
  'Circulatory System': { unlocks: ['Human Body'], nextChapter: 'Nervous System' },
  'Nervous System': { unlocks: ['Human Body'], nextChapter: 'Human Body' },
  'Sense Organs': { unlocks: ['Nervous System'], nextChapter: 'Nervous System' },
  'States of Water': { unlocks: ['Water Cycle'], nextChapter: 'Water Cycle' },
  'Water Cycle': { unlocks: ['Rain'], nextChapter: 'Water Conservation' },
  'Water Sources': { unlocks: ['Water Conservation'], nextChapter: 'Water Conservation' },
  'Water Conservation': { unlocks: [], nextChapter: 'Water Conservation' },
  Weather: { unlocks: ['Seasons', 'Temperature'], nextChapter: 'Seasons' },
  'Temperature': { unlocks: ['Seasons'], nextChapter: 'Seasons' },
  Seasons: { unlocks: [], nextChapter: 'Seasons' },
  'Magnetic Properties': { unlocks: ['Magnet Poles', 'Magnet Uses'], nextChapter: 'Magnet Uses' },
  'Magnet Poles': { unlocks: ['Magnet Uses'], nextChapter: 'Magnet Uses' },
  'Magnet Uses': { unlocks: ['Magnet Direction'], nextChapter: 'Magnet Direction' },
  'Magnet Direction': { unlocks: [], nextChapter: 'Magnet Direction' },
  'Human Body': { unlocks: [], nextChapter: 'Human Body' },
  Organs: { unlocks: ['Human Body'], nextChapter: 'Human Body' },
}

const DEFAULT_LINK: ConceptLink = { unlocks: [], nextChapter: '' }

// Concepts at or above this are treated as a strength, below GAP_THRESHOLD as a gap.
const STRONG_THRESHOLD = 75
const GAP_THRESHOLD = 55

const clamp = (value: number): number => Math.max(0, Math.min(100, Math.round(value)))

const masteryLevelFor = (mastery: number): MasteryLevel => {
  if (mastery >= 85) return 'Mastered'
  if (mastery >= 70) return 'Proficient'
  if (mastery >= 45) return 'Developing'
  return 'Emerging'
}

const riskFor = (score: number): RiskLevel => {
  if (score >= 70) return 'Low'
  if (score >= 45) return 'Medium'
  return 'High'
}

// ---- SECTION 2: CONCEPT MASTERY ----
const buildConceptMastery = (reviews: QuestionReview[]): ConceptMastery[] => {
  const byConcept = new Map<string, { correct: number; total: number }>()
  reviews.forEach(review => {
    const entry = byConcept.get(review.concept) || { correct: 0, total: 0 }
    entry.total += 1
    if (review.isCorrect) entry.correct += 1
    byConcept.set(review.concept, entry)
  })
  return [...byConcept.entries()]
    .map(([concept, stats]) => ({
      concept,
      correct: stats.correct,
      total: stats.total,
      mastery: clamp((stats.correct / stats.total) * 100),
    }))
    // Weakest first: the point of this section is to show where the work is.
    .sort((a, b) => a.mastery - b.mastery)
}

// ---- SECTION 5: MISCONCEPTION ANALYSIS ----
// The per-question reviews already carry a labelled misconception with a
// confidence score, so the summary is a roll-up rather than a second opinion.
const summariseMisconceptions = (reviews: QuestionReview[]): MisconceptionSummary[] => {
  const byLabel = new Map<string, { confidences: number[]; questionIds: number[]; descriptions: string[]; concepts: string[] }>()
  reviews.forEach(review => {
    const found = review.misconception
    if (!found) return
    const entry = byLabel.get(found.label) || { confidences: [], questionIds: [], descriptions: [], concepts: [] }
    entry.confidences.push(found.confidence)
    entry.questionIds.push(review.questionId)
    if (!entry.concepts.includes(review.concept)) entry.concepts.push(review.concept)
    if (found.evidence) entry.descriptions.push(found.evidence)
    byLabel.set(found.label, entry)
  })
  return [...byLabel.entries()]
    .map(([label, entry]) => ({
      label,
      description: entry.descriptions[0] || 'Detected across several questions on this chapter.',
      // A habit, not a slip: repeated sightings raise the confidence.
      confidence: clamp(Math.max(...entry.confidences) + (entry.questionIds.length - 1) * 3),
      occurrences: entry.questionIds.length,
      questionIds: entry.questionIds,
      concepts: entry.concepts,
    }))
    .sort((a, b) => b.confidence - a.confidence || b.occurrences - a.occurrences)
}

// ---- SECTION 7: PREDICTIVE INSIGHT ----
// Five forecasts about the learner themselves: what the next assessment will
// test, what is still untouched in this chapter, how the retest is likely to go,
// what could stop them finishing, and which way mastery is moving.

export interface NextAssessmentForecast {
  label: string
  focusConcepts: string[]
  unattemptedQuestions: number
  predictedScore: number
  confidence: number
}

export interface ProgressionForecast {
  from: number
  to: number
  direction: 'up' | 'flat' | 'down' | 'unknown'
  note: string
}

export interface PredictiveInsight {
  nextAssessment: NextAssessmentForecast
  remainingConcepts: { concept: string; questions: number }[]
  retest: ProgressionForecast
  completionRisk: RiskInsight
  progression: ProgressionForecast
}

// How much of the remaining score remediation is assumed to recover. A learner
// who has already worked through the modes is expected to close more of the gap
// than one who has not, so the projection stays honest rather than optimistic.
const LIFT_AFTER_REMEDIATION = 0.45
const LIFT_WITHOUT_REMEDIATION = 0.25

const buildPredictiveInsight = (input: {
  questions: ReviewableQuestion[]
  questionResults: AttemptQuestionResult[]
  attempts: AttemptSummary[]
  conceptMastery: ConceptMastery[]
  gaps: ConceptMastery[]
  misconceptions: MisconceptionSummary[]
  readiness: ReadinessInsight
  hasAttempted: boolean
}): PredictiveInsight => {
  const { questions, questionResults, attempts, conceptMastery, gaps, misconceptions, readiness } = input
  const latest = attempts[attempts.length - 1]
  const currentScore = Math.round(latest?.score ?? 0)

  // Concepts the chapter covers that this attempt never reached. The runner
  // shuffles the whole pool, so these are the ones a retest is likely to serve.
  const attemptedIds = new Set(questionResults.map(result => result.questionId))
  const remainingCount = new Map<string, number>()
  questions.forEach(question => {
    if (attemptedIds.has(question.questionId)) return
    remainingCount.set(question.concept, (remainingCount.get(question.concept) || 0) + 1)
  })
  const remainingConcepts = [...remainingCount.entries()]
    .map(([concept, count]) => ({ concept, questions: count }))
    .sort((a, b) => b.questions - a.questions)

  // The weakest concepts are what the next assessment should be read against.
  const focusConcepts = gaps.slice(0, 3).map(gap => gap.concept)

  const lift = readiness.ready ? LIFT_AFTER_REMEDIATION : LIFT_WITHOUT_REMEDIATION
  const predictedScore = clamp(currentScore + Math.round((100 - currentScore) * lift))
  // Fewer recorded attempts means less evidence to forecast from.
  const confidence = clamp(45 + attempts.length * 15 + (input.hasAttempted ? 15 : 0))

  const nextAssessment: NextAssessmentForecast = {
    label: latest?.kind === 'assessment' ? 'Next chapter assessment' : 'Next retest',
    focusConcepts,
    unattemptedQuestions: questions.filter(q => !attemptedIds.has(q.questionId)).length,
    predictedScore,
    confidence,
  }

  // Retest forecast: one attempt is no trend, so it is reported as unknown rather
  // than dressed up as a projection.
  const first = attempts[0]
  const retest: ProgressionForecast = attempts.length > 1
    ? {
        from: first.score,
        to: currentScore,
        direction: currentScore > first.score ? 'up' : currentScore < first.score ? 'down' : 'flat',
        note: currentScore > first.score
          ? `You gained ${currentScore - first.score} points since your first attempt.`
          : currentScore < first.score
            ? `You are ${first.score - currentScore} points below your first attempt, so revise before the retest.`
            : 'Your score is unchanged since your first attempt.',
      }
    : { from: currentScore, to: currentScore, direction: 'unknown', note: 'Take another attempt to start tracking progress.' }

  // Completion risk: what could actually stop this chapter being finished.
  const blockers = [
    ...(gaps.length > 0 ? [`${gaps.length} concept${gaps.length === 1 ? '' : 's'} below ${GAP_THRESHOLD}%`] : []),
    ...(misconceptions.length > 0 ? [`${misconceptions.length} unresolved misconception${misconceptions.length === 1 ? '' : 's'}`] : []),
    ...(remainingConcepts.length > 0 ? [`${nextAssessment.unattemptedQuestions} questions not yet assessed`] : []),
  ]
  const riskLevel: RiskLevel = (gaps.length >= 3 || currentScore < 45) ? 'High' : (gaps.length >= 1 || currentScore < 70) ? 'Medium' : 'Low'
  const completionRisk: RiskInsight = blockers.length === 0
    ? { level: 'Low', reason: 'Nothing is standing between this chapter and being completed.' }
    : {
        level: riskLevel,
        reason: `${riskLevel === 'High' ? 'You are unlikely to finish this chapter unaided' : riskLevel === 'Medium' ? 'Some work is needed before this chapter is secure' : 'This chapter is close to complete'}, because of ${blockers.join(', ')}.`,
      }

  const progression: ProgressionForecast = attempts.length > 1
    ? retest
    : {
        from: currentScore,
        to: predictedScore,
        direction: readiness.ready ? 'up' : 'flat',
        note: readiness.ready
          ? `With the recommended revision, ${conceptMastery.filter(c => c.mastery >= STRONG_THRESHOLD).length} strong concept${conceptMastery.filter(c => c.mastery >= STRONG_THRESHOLD).length === 1 ? '' : 's'} should carry into the retest.`
          : 'Mastery is unlikely to move without remediating the gaps above.',
      }

  return { nextAssessment, remainingConcepts, retest, completionRisk, progression }
}

// ---- SECTION 8: READINESS ----
const buildReadiness = (
  conceptMastery: ConceptMastery[],
  score: number,
  misconceptions: MisconceptionSummary[],
  chapterName: string,
  availableChapters: string[]
): ReadinessInsight => {
  const revisionConcepts = conceptMastery
    .filter(item => item.mastery < GAP_THRESHOLD)
    .map(item => item.concept)

  // The graph's ideal next step (Decimals after Fractions, say) usually does not
  // exist yet. Recommending it anyway would be a dead end, so fall back to the
  // next chapter the learner can actually open, and null when there is none.
  const ideal = conceptMastery
    .map(item => (CONCEPT_GRAPH[item.concept] || DEFAULT_LINK).nextChapter)
    .find(Boolean) || ''
  const afterCurrent = availableChapters[availableChapters.indexOf(chapterName) + 1]

  const nextChapter = availableChapters.includes(ideal)
    ? ideal
    : afterCurrent || null

  // A concept the learner is weak on, which also unlocks something later, drags
  // readiness down twice: once for the weakness and once for the dependency.
  const weighted = conceptMastery.reduce((sum, item) => {
    const unlocksSomething = (CONCEPT_GRAPH[item.concept]?.unlocks.length || 0) > 0
    return sum + item.mastery * (unlocksSomething ? 1.35 : 1)
  }, 0)
  const weight = conceptMastery.reduce((sum, item) => {
    const unlocksSomething = (CONCEPT_GRAPH[item.concept]?.unlocks.length || 0) > 0
    return sum + (unlocksSomething ? 1.35 : 1)
  }, 0)

  const base = weight > 0 ? weighted / weight : score
  // Confident misconceptions are a truer signal of unreadiness than a raw score,
  // because they show the learner does not yet know what they got wrong.
  const penalty = misconceptions.reduce((sum, item) => sum + item.confidence / misconceptions.length * 0.12, 0)
  const readiness = clamp(base * 0.85 + score * 0.15 - penalty)

  return {
    score: readiness,
    ready: readiness >= 70,
    nextChapter,
    revisionConcepts,
  }
}

// ---- SECTION 9: AI COACH ----
const LEARNING_MODES = ['Document', 'Video', 'Audio', 'PPT']

const buildCoachPlan = (gaps: ConceptMastery[], misconceptions: MisconceptionSummary[], readiness: ReadinessInsight): CoachPlan => {
  const focus = gaps[0]?.concept || misconceptions[0]?.concepts[0] || 'the whole chapter'

  // Pair the focus area with a misconception actually seen on that concept.
  // Quoting an unrelated error reads as a non-sequitur.
  const onFocus = misconceptions.find(item => item.concepts.includes(focus))
  const driver = onFocus || misconceptions[0]

  // Weakest concept decides the dose: more gaps, more time. Rounded to 5 minutes
  // so the number reads as guidance rather than a measurement.
  const raw = 15 + gaps.length * 8 + misconceptions.length * 3
  const minutes = Math.min(60, Math.max(15, Math.round(raw / 5) * 5))

  // A visual misconception is best fixed by seeing it, a symbolic one by reading.
  const modes = misconceptions.some(item => /place value|visual|comparison/i.test(item.label))
    ? ['Video', 'Document', 'PPT']
    : LEARNING_MODES

  // The plan ends on whatever the learner can actually open next.
  const nextStep = readiness.nextChapter
    ? `before moving to ${readiness.nextChapter}`
    : 'before moving on'

  const recommendation = driver
    ? `Review ${focus} and correct this specific error first: ${driver.label.toLowerCase()}. Complete guided practice ${nextStep}.`
    : `Work through ${focus} with worked examples, then retake the chapter assessment to confirm ${nextStep.replace('before moving to ', '')} is unblocked.`

  return { focusArea: focus, minutes, modes, recommendation }
}

// ---- SECTION 10: REMEDIATION RESOURCES ----
// Only the four content modes are offered here. Practice and the AI Companion
// stay reachable from the learning screen itself, so listing them here as well
// would just repeat what the learner already has one click away.
const buildResources = (focus: string): RemediationResource[] => [
  { id: 'document', mode: 'document', icon: '\uD83D\uDCD6', label: 'Document Learning', detail: `Read the ${focus} section with worked examples.` },
  { id: 'ppt', mode: 'ppt', icon: '\uD83D\uDCCA', label: 'PPT Learning', detail: 'Slide-by-slide visual walkthrough of the concept.' },
  { id: 'voice', mode: 'voice', icon: '\uD83D\uDCA7', label: 'Audio Learning', detail: 'Listen and revise while on the move.' },
  { id: 'video', mode: 'video', icon: '\uD83C\uDFAC', label: 'Video Learning', detail: 'Watch the chapter explained step by step.' },
]

// ---- SECTION 6: LEARNING RISK ----
const buildRisk = (gaps: ConceptMastery[], misconceptions: MisconceptionSummary[], score: number, inChapter: string[]): RiskInsight => {
  const level = riskFor(score)
  if (level === 'Low') {
    return {
      level,
      reason: misconceptions.length === 0
        ? 'No misconception pattern was detected, so nothing here should block the concepts ahead.'
        : `Only ${misconceptions.length} low-confidence misconception${misconceptions.length === 1 ? '' : 's'} remain, which is unlikely to hold up later topics.`,
    }
  }
  const driver = gaps[0]
  // Name a consequence the learner has not already met inside this chapter.
  const downstream = [...new Set(
    gaps.flatMap(gap => (CONCEPT_GRAPH[gap.concept] || DEFAULT_LINK).unlocks)
      .filter(concept => !inChapter.includes(concept))
  )].slice(0, 2)

  const consequence = downstream.length > 0
    ? `Weak ${driver?.concept || 'foundation'} mastery may impact ${downstream.join(' and ')}.`
    : `Weak ${driver?.concept || 'foundation'} mastery makes the next steps harder to follow.`
  const severity = level === 'High'
    ? ' Remediate before moving on.'
    : ' Targeted support recommended before the next chapter.'
  return { level, reason: `${consequence}${severity}` }
}

// ---- SECTION 11: EVOLUTION ----
// Every point here is a chapter attempt. The baseline is a separate, global
// assessment, so calling this chapter's first attempt "Baseline Assessment"
// would wrongly imply the learner is looking at their baseline score.
const buildEvolution = (attempts: AttemptSummary[]): { points: EvolutionPoint[]; trend: number } => {
  const points = [...attempts]
    .sort((a, b) => a.attempt - b.attempt)
    .map(attempt => ({
      label: attempt.kind === 'retest'
        ? 'Retest'
        : attempt.attempt === 1
          ? 'Chapter Assessment'
          : `Chapter Assessment v${attempt.attempt}`,
      score: attempt.score,
      kind: attempt.kind,
    }))
  const trend = points.length > 1 ? points[points.length - 1].score - points[0].score : 0
  return { points, trend }
}

// ---- ENTRY POINT ----
export const buildChapterDna = (input: {
  questions: ReviewableQuestion[]
  questionResults: AttemptQuestionResult[]
  attempts: AttemptSummary[]
  version: number
  score: number
  mastery: number
  date: string
  reasoning: number
  problemSolving: number
  criticalThinking: number
  chapterName: string
  // Chapter names the learner can actually open, in curriculum order.
  availableChapters: string[]
}): ChapterDnaProfile => {
  const questionIndex = new Map(input.questions.map(question => [question.questionId, question]))

  // One seed shared across the chapter, so a misconception repeated on several
  // questions is reported with the higher confidence it deserves.
  const frequencySeed = new Map<string, number>()
  const reviews = input.questionResults
    .map(result => {
      const question = questionIndex.get(result.questionId)
      if (!question) return null
      return buildQuestionReview(question, result, '', frequencySeed)
    })
    .filter((review): review is QuestionReview => Boolean(review))

  const score = clamp(input.score)
  const mastery = clamp(input.mastery)
  const conceptMastery = buildConceptMastery(reviews)
  const strengths = conceptMastery.filter(item => item.mastery >= STRONG_THRESHOLD)
  const gaps = conceptMastery.filter(item => item.mastery < GAP_THRESHOLD)
  const misconceptions = summariseMisconceptions(reviews)
  const { points: evolution, trend } = buildEvolution(input.attempts)

  const readiness = buildReadiness(conceptMastery, score, misconceptions, input.chapterName, input.availableChapters)
  const coach = buildCoachPlan(gaps, misconceptions, readiness)

  return {
    score,
    version: input.version,
    date: input.date,
    mastery,
    masteryLevel: masteryLevelFor(mastery),
    cognitive: [
      { label: 'Reasoning', value: clamp(input.reasoning) },
      { label: 'Problem Solving', value: clamp(input.problemSolving) },
      { label: 'Critical Thinking', value: clamp(input.criticalThinking) },
    ],
    conceptMastery,
    strengths,
    gaps,
    misconceptions,
    risk: buildRisk(gaps, misconceptions, score, conceptMastery.map(item => item.concept)),
    predictive: buildPredictiveInsight({
    questions: input.questions,
    questionResults: input.questionResults,
    attempts: input.attempts,
    conceptMastery,
    gaps,
    misconceptions,
    readiness,
    hasAttempted: reviews.length > 0,
  }),
    readiness,
    coach,
    resources: buildResources(coach.focusArea),
    evolution,
    trend,
    reviews,
    hasQuestionDetail: reviews.length > 0,
  }
}