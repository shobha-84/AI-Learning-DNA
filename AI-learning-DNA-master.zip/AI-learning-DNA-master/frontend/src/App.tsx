import { Fragment, useEffect, useRef, useState, useCallback, useMemo } from 'react'
import axios from 'axios'
import { motion, AnimatePresence, useInView, useMotionValue, useSpring, useTransform } from 'framer-motion'
import { buildQuestionReview, type QuestionReview } from './assessmentReview'
import { buildChapterDna, type AttemptQuestionResult, type ChapterDnaProfile } from './chapterDna'

type Screen = 'register' | 'overview' | 'questions' | 'complete' | 'dashboard' | 'chapter-dna' | 'learning-mode' | 'chapter-assessment' | 'chapter-result' | 'chapter-content' | 'repository' | 'baseline' | 'learning-dna'
type DashboardTab = 'profile' | 'subjects' | 'assessment'
type LearningMode = 'document' | 'ppt' | 'video' | 'voice' | 'companion' | null
type Confidence = 'Very Confident' | 'Confident' | 'Unsure' | 'Guessing'

interface BaselineAssessmentState {
  studentId: string
  studentName: string
  className: string
  preferredSubjects: string[]
}

interface ConfidenceResponse {
  questionId: number
  selectedAnswer: string
  confidenceLevel: Confidence
}

interface RegistrationData {
  id?: string
  studentName: string
  class: string
  schoolName: string
  email: string
  contactNumber: string
  preferredSubjects: string[]
  learningGoal: string
  registrationDate?: string
}

interface SuccessData {
  studentId: string
  studentName: string
  preferredSubjects: string[]
}

interface AssessmentQuestion {
  questionId: number
  chapter: string
  concept: string
  type: 'mcq' | 'truefalse' | 'fillblank' | 'match' | 'oneword' | 'reasoning' | 'criticalthinking' | 'problemsolving' | 'viva'
  difficulty: 'Easy' | 'Medium' | 'Hard'
  question: string
  options?: string[]
  correctAnswer: string
  acceptedAnswers?: string[]
  explanation?: string
}

interface SubjectWiseResult {
  subject: string
  score: number
  total: number
  percentage: number
  questionIds: number[]
  correctQuestionIds: number[]
  incorrectQuestionIds: number[]
  conceptsCorrect: string[]
  conceptsIncorrect: string[]
}

interface SubjectDNAPayload {
  subject: string
  score: number
  percentage: number
  risk: 'Low' | 'Medium' | 'High'
  mastery: number
  confidence: number
  answeredCorrectly: number
  totalQuestions: number
  strengths: string[]
  gaps: string[]
}

interface CognitiveSkills {
  reasoning: number
  problemSolving: number
  criticalThinking: number
  reasoningBasis: string
  problemSolvingBasis: string
  criticalThinkingBasis: string
}

interface LearningDNAInput {
  mathematicsScore: number
  scienceScore: number
  totalScore: number
  totalCorrect: number
  totalQuestions: number
  overallPercentage: number
  cognitiveSkills: CognitiveSkills
  subjectWiseResults: SubjectWiseResult[]
  subjectDNA: SubjectDNAPayload[]
}

interface AssessmentResult {
  studentId: string
  studentName: string
  className: string
  subjects: string[]
  score: number
  totalQuestions: number
  answeredCorrectly: number
  questionResults: { questionId: number; isCorrect: boolean; concept: string; questionType: string; userAnswer: string; correctAnswer: string; subject?: string; difficulty?: string }[]
}

interface AssessmentSubmissionData {
  studentId: string
  studentName: string
  className: string
  selectedSubjects: string[]
  assessmentResults: AssessmentResult
  confidenceResponses: ConfidenceResponse[]
  subjectWiseResults: SubjectWiseResult[]
  dnaInput: LearningDNAInput
}

interface ChapterDNA {
  chapter: string
  subject: string
  score: number
  mastery: number
  confidence: number
  risk: 'Low' | 'Medium' | 'High'
  strengths: string[]
  gaps: string[]
  misconceptions: string
}

interface DNAVersion {
  version: number
  score: number
  mastery: number
  risk: string
  date: string
  assessmentResult: AssessmentResult | null
  reasoning?: number
  problemSolving?: number
  criticalThinking?: number
}

interface ChapterAttempt {
  kind: 'assessment' | 'retest'
  attempt: number
  chapterName: string
  score: number
  mastery: number
  risk: 'Low' | 'Medium' | 'High'
  correct: number
  total: number
  date: string
  reasoning: number
  problemSolving: number
  criticalThinking: number
  // Per-question results of this attempt, when they were recorded.
  answers?: ChapterQuestionResult[]
}

interface ChapterAssessmentTracking {
  chapterId: string
  chapterName: string
  subject: string
  assessmentCompleted: boolean
  retestCompleted: boolean
  retestAvailable: boolean
  currentVersion: DNAVersion | null
  completedModes: string[]
  assessmentScore: number
  reasoningScore: number
  problemSolvingScore: number
  criticalThinkingScore: number
  attempts: ChapterAttempt[]
}

interface SubjectDNA {
  subject: string
  score: number
  mastery: number
  confidence: number
  risk: 'Low' | 'Medium' | 'High'
  strengths: string[]
  gaps: string[]
  reasoning: number
  problemSolving: number
  criticalThinking: number
  chaptersTotal: number
  chaptersCompleted: number
  allChaptersCompleted: boolean
}

interface EvolutionEntry {
  date: string
  type: string
  chapter: string
  score: number
  mastery: number
  risk: string
  version: number
}

interface LearningModeMeta {
  id: LearningMode
  label: string
  icon: string
  blurb: string
}

const LEARNING_MODES: LearningModeMeta[] = [
  { id: 'document', label: 'Learner Document', icon: '\uD83D\uDCC4', blurb: 'Introduction, concepts, examples and summary' },
  { id: 'ppt', label: 'PPT Learning', icon: '\uD83D\uDCCA', blurb: 'Slide-by-slide visual walkthrough' },
  { id: 'video', label: 'Video Learning', icon: '\uD83C\uDFAC', blurb: 'Watch the chapter explained' },
  { id: 'voice', label: 'Audio Learning', icon: '\uD83D\uDCA7', blurb: 'Listen and revise on the go' }
]

interface ChapterContentItem {
  id: string
  title: string
  type: string
  text: string
  url: string
  duration: string
  description: string
}

interface ChapterLearningContext {
  chapter: { id: string; title: string; subject: string; grade: string; description: string }
  modes: Record<string, ChapterContentItem[]>
  question_count: number
  dna: {
    version: number
    overall_score: number
    strengths: { concept?: string }[]
    gaps: { concept?: string }[]
    misconceptions: { description?: string; type?: string }[]
    recommendations: string[]
  } | null
  suggested_questions: string[]
}

interface CompanionMessage {
  id: string
  role: 'learner' | 'companion'
  text: string
  sources?: { heading: string; source: string }[]
  usedDna?: boolean
}

const API_URL = '/api'

const CountUp = ({ value, suffix = '%' }: { value: number; suffix?: string }) => {
  const ref = useRef<HTMLSpanElement>(null)
  const inView = useInView(ref, { once: true, margin: '-60px' })
  const motionValue = useMotionValue(0)
  const spring = useSpring(motionValue, { duration: 1100, bounce: 0 })
  const rounded = useTransform(spring, (latest) => `${Math.round(latest)}${suffix}`)
  useEffect(() => { if (inView) motionValue.set(value) }, [inView, motionValue, value])
  return <motion.span ref={ref}>{rounded}</motion.span>
}

const Reveal = ({ children, className = '', delay = 0 }: { children: React.ReactNode; className?: string; delay?: number }) => (
  <motion.div className={className} initial={{ opacity: 0, y: 28 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true, margin: '-80px' }} transition={{ duration: .6, delay, ease: 'easeOut' }}>{children}</motion.div>
)

function Logo() { return <div className="walk-logo"><span>{'\uD83E\uDDE0'}</span><strong>AI Learning <b>DNA</b></strong></div> }

function DNAHelix({ small = false }: { small?: boolean }) {
  return <div className={`dna-helix ${small ? 'small' : ''}`} aria-hidden="true"><div className="helix-curve curve-one" /><div className="helix-curve curve-two" />{Array.from({ length: small ? 5 : 8 }, (_, index) => <i key={index} style={{ top: `${14 + index * (small ? 17 : 11)}%`, animationDelay: `${index * -.18}s` }} />)}</div>
}

const shuffleArray = <T,>(array: T[]): T[] => {
  const arr = [...array]
  for (let i = arr.length - 1; i > 0; i--) {
    const j = Math.floor(Math.random() * (i + 1))
    ;[arr[i], arr[j]] = [arr[j], arr[i]]
  }
  return arr
}

const getRandomInt = (min: number, max: number) => Math.floor(Math.random() * (max - min + 1)) + min

// Chapters that stay in the repository (backend content, questions, DNA) but are
// hidden from the learner for now. Clear the list to publish them.
const HIDDEN_CHAPTERS: string[] = ['Water', 'Weather and Seasons', 'Fun with Magnets']

const isChapterVisible = (chapterName: string) => !HIDDEN_CHAPTERS.includes(chapterName)

// Every chapter list the learner can browse or be assessed on goes through here,
// so hiding a chapter removes it from the explorer, the assessment tab and the
// baseline question pool in one place.
const visibleChapters = (subject: string) =>
  (subjectsData[subject]?.chapters || []).filter(c => isChapterVisible(c.name))

const subjectsData: Record<string, { chapters: { name: string; questions: AssessmentQuestion[] }[] }> = {
  Mathematics: {
    chapters: [
      { name: 'Fractions', questions: [
        { questionId: 1, chapter: 'Fractions', concept: 'Fraction Addition', type: 'mcq', difficulty: 'Easy', question: 'What is 1/2 + 1/4?', options: ['3/4', '2/6', '1/3', '2/4'], correctAnswer: '3/4' },
        { questionId: 2, chapter: 'Fractions', concept: 'Equivalent Fractions', type: 'mcq', difficulty: 'Medium', question: 'Which fraction is equivalent to 1/2?', options: ['2/4', '1/3', '3/5', '1/4'], correctAnswer: '2/4' },
        { questionId: 3, chapter: 'Fractions', concept: 'Fraction Comparison', type: 'mcq', difficulty: 'Medium', question: 'Which is larger: 2/3 or 3/5?', options: ['2/3', '3/5', 'Equal', 'Cannot compare'], correctAnswer: '2/3' },
        { questionId: 4, chapter: 'Fractions', concept: 'Simplification', type: 'mcq', difficulty: 'Easy', question: 'Simplify 4/8', options: ['1/2', '2/3', '1/4', '3/4'], correctAnswer: '1/2' },
        { questionId: 5, chapter: 'Fractions', concept: 'Fraction of a Whole', type: 'mcq', difficulty: 'Easy', question: 'What is 1/3 of 12?', options: ['4', '3', '6', '8'], correctAnswer: '4' },
        { questionId: 101, chapter: 'Fractions', concept: 'Fraction Addition', type: 'mcq', difficulty: 'Easy', question: 'What is 2/5 + 1/5?', options: ['3/5', '3/10', '2/5', '1/5'], correctAnswer: '3/5' },
        { questionId: 102, chapter: 'Fractions', concept: 'Equivalent Fractions', type: 'mcq', difficulty: 'Medium', question: 'Which is equivalent to 3/4?', options: ['6/8', '3/5', '4/6', '2/4'], correctAnswer: '6/8' },
        { questionId: 103, chapter: 'Fractions', concept: 'Fraction Comparison', type: 'mcq', difficulty: 'Medium', question: 'Which is smaller: 1/4 or 1/2?', options: ['1/4', '1/2', 'Equal', 'Cannot tell'], correctAnswer: '1/4' },
        { questionId: 104, chapter: 'Fractions', concept: 'Simplification', type: 'mcq', difficulty: 'Easy', question: 'Simplify 6/9', options: ['2/3', '3/4', '1/3', '6/9'], correctAnswer: '2/3' },
        { questionId: 105, chapter: 'Fractions', concept: 'Fraction of a Whole', type: 'mcq', difficulty: 'Easy', question: 'What is 2/5 of 15?', options: ['6', '5', '10', '3'], correctAnswer: '6' },
        { questionId: 106, chapter: 'Fractions', concept: 'Fraction Addition', type: 'fillblank', difficulty: 'Medium', question: 'What is 3/7 + 2/7? Write as a fraction.', correctAnswer: '5/7', acceptedAnswers: ['5/7'] },
        { questionId: 107, chapter: 'Fractions', concept: 'Equivalent Fractions', type: 'truefalse', difficulty: 'Easy', question: '1/2 and 2/4 are equivalent fractions.', correctAnswer: 'True', acceptedAnswers: ['True', 'true', 'T', 't'] },
        { questionId: 108, chapter: 'Fractions', concept: 'Fraction Comparison', type: 'reasoning', difficulty: 'Hard', question: 'Explain why 2/3 is greater than 3/5 even though 2 is less than 3 and 3 is less than 5.', correctAnswer: 'cross multiply', acceptedAnswers: ['cross multiply', 'common denominator', '2/3 equals', 'convert'] },
        { questionId: 109, chapter: 'Fractions', concept: 'Simplification', type: 'oneword', difficulty: 'Medium', question: 'What do you call a fraction where numerator is greater than denominator?', correctAnswer: 'improper', acceptedAnswers: ['improper', 'improper fraction'] },
        { questionId: 110, chapter: 'Fractions', concept: 'Fraction Addition', type: 'problemsolving', difficulty: 'Hard', question: 'You have 3/4 of a pizza and your friend has 2/3. Who has more? Show your reasoning.', correctAnswer: 'you', acceptedAnswers: ['you', 'i have more', '3/4', 'me', 'my share', 'common denominator', 'convert'] },
      ]},
      { name: 'Algebra', questions: [
        { questionId: 6, chapter: 'Algebra', concept: 'Variables', type: 'mcq', difficulty: 'Easy', question: 'If x + 5 = 12, what is x?', options: ['7', '17', '5', '12'], correctAnswer: '7' },
        { questionId: 7, chapter: 'Algebra', concept: 'Basic Equations', type: 'mcq', difficulty: 'Medium', question: 'Solve: 3x = 15', options: ['5', '3', '45', '12'], correctAnswer: '5' },
        { questionId: 8, chapter: 'Algebra', concept: 'Pattern Recognition', type: 'mcq', difficulty: 'Medium', question: 'What comes next: 2, 4, 8, 16, ___?', options: ['32', '24', '20', '28'], correctAnswer: '32' },
        { questionId: 9, chapter: 'Algebra', concept: 'Algebraic Expressions', type: 'mcq', difficulty: 'Hard', question: 'Simplify: 2x + 3x', options: ['5x', '6x', '5x\u00B2', '6x\u00B2'], correctAnswer: '5x' },
        { questionId: 10, chapter: 'Algebra', concept: 'Substitution', type: 'mcq', difficulty: 'Medium', question: 'If x=3, what is 2x+1?', options: ['7', '6', '5', '8'], correctAnswer: '7' },
        { questionId: 111, chapter: 'Algebra', concept: 'Variables', type: 'mcq', difficulty: 'Easy', question: 'If y - 4 = 9, what is y?', options: ['13', '5', '9', '4'], correctAnswer: '13' },
        { questionId: 112, chapter: 'Algebra', concept: 'Basic Equations', type: 'mcq', difficulty: 'Medium', question: 'Solve: x/4 = 3', options: ['12', '7', '3', '4'], correctAnswer: '12' },
        { questionId: 113, chapter: 'Algebra', concept: 'Pattern Recognition', type: 'mcq', difficulty: 'Medium', question: 'What comes next: 3, 6, 12, 24, ___?', options: ['48', '36', '42', '38'], correctAnswer: '48' },
        { questionId: 114, chapter: 'Algebra', concept: 'Algebraic Expressions', type: 'mcq', difficulty: 'Hard', question: 'Simplify: 4a + 2b - a + b', options: ['3a + 3b', '5a + 3b', '3a + 2b', '5a + 2b'], correctAnswer: '3a + 3b' },
        { questionId: 115, chapter: 'Algebra', concept: 'Substitution', type: 'mcq', difficulty: 'Medium', question: 'If a=2, b=3, what is 2a + 3b?', options: ['13', '10', '11', '12'], correctAnswer: '13' },
        { questionId: 116, chapter: 'Algebra', concept: 'Variables', type: 'fillblank', difficulty: 'Easy', question: 'If x + 8 = 15, then x = _____.', correctAnswer: '7', acceptedAnswers: ['7'] },
        { questionId: 117, chapter: 'Algebra', concept: 'Basic Equations', type: 'truefalse', difficulty: 'Medium', question: 'In the equation 2x = 10, x equals 5.', correctAnswer: 'True', acceptedAnswers: ['True', 'true', 'T', 't'] },
        { questionId: 118, chapter: 'Algebra', concept: 'Pattern Recognition', type: 'fillblank', difficulty: 'Medium', question: 'Complete the pattern: 5, 10, 15, 20, ___.', correctAnswer: '25', acceptedAnswers: ['25'] },
        { questionId: 119, chapter: 'Algebra', concept: 'Algebraic Expressions', type: 'reasoning', difficulty: 'Hard', question: 'Why can you not combine 3x and 5y into a single term?', correctAnswer: 'different variables', acceptedAnswers: ['different variables', 'different', 'different variables x and y', 'not like terms'] },
        { questionId: 120, chapter: 'Algebra', concept: 'Substitution', type: 'problemsolving', difficulty: 'Hard', question: 'A rectangle has length (x+3) and width x. If perimeter is 20, find x.', correctAnswer: '3.5', acceptedAnswers: ['3.5', 'x equals 3.5', 'x=3.5', '7/2'] },
      ]},
    ],
  },
  Science: {
    chapters: [
      { name: 'Plants', questions: [
        { questionId: 21, chapter: 'Plants', concept: 'Plant Parts', type: 'mcq', difficulty: 'Easy', question: 'Which part of the plant grows below the soil?', options: ['Root', 'Stem', 'Leaf', 'Flower'], correctAnswer: 'Root' },
        { questionId: 22, chapter: 'Plants', concept: 'Photosynthesis', type: 'truefalse', difficulty: 'Medium', question: 'Plants make their own food using sunlight.', correctAnswer: 'True', acceptedAnswers: ['True', 'true', 'T', 't'] },
        { questionId: 23, chapter: 'Plants', concept: 'Plant Functions', type: 'fillblank', difficulty: 'Medium', question: 'The _______ of a plant absorbs water from the soil.', correctAnswer: 'root', acceptedAnswers: ['root', 'roots'] },
        { questionId: 24, chapter: 'Plants', concept: 'Plant Parts', type: 'oneword', difficulty: 'Easy', question: 'Name the green pigment found in leaves.', correctAnswer: 'chlorophyll', acceptedAnswers: ['chlorophyll', 'chlorophyll'] },
        { questionId: 25, chapter: 'Plants', concept: 'Plant Parts', type: 'reasoning', difficulty: 'Hard', question: 'Why do plants need sunlight? Explain your answer.', correctAnswer: 'to make food', acceptedAnswers: ['make food', 'photosynthesis', 'food', 'energy'] },
        { questionId: 131, chapter: 'Plants', concept: 'Plant Parts', type: 'mcq', difficulty: 'Easy', question: 'Which part of the plant makes food?', options: ['Leaf', 'Root', 'Stem', 'Flower'], correctAnswer: 'Leaf' },
        { questionId: 132, chapter: 'Plants', concept: 'Photosynthesis', type: 'mcq', difficulty: 'Medium', question: 'What gas do plants take in during photosynthesis?', options: ['Carbon dioxide', 'Oxygen', 'Nitrogen', 'Hydrogen'], correctAnswer: 'Carbon dioxide' },
        { questionId: 133, chapter: 'Plants', concept: 'Plant Functions', type: 'fillblank', difficulty: 'Medium', question: 'The _______ of a plant carries water from roots to leaves.', correctAnswer: 'stem', acceptedAnswers: ['stem'] },
        { questionId: 134, chapter: 'Plants', concept: 'Plant Parts', type: 'truefalse', difficulty: 'Easy', question: 'Flowers are involved in plant reproduction.', correctAnswer: 'True', acceptedAnswers: ['True', 'true', 'T', 't'] },
        { questionId: 135, chapter: 'Plants', concept: 'Photosynthesis', type: 'oneword', difficulty: 'Medium', question: 'What is the process by which plants make food using sunlight?', correctAnswer: 'photosynthesis', acceptedAnswers: ['photosynthesis'] },
        { questionId: 136, chapter: 'Plants', concept: 'Plant Functions', type: 'fillblank', difficulty: 'Easy', question: 'Plants lose water through tiny holes in leaves called _______.', correctAnswer: 'stomata', acceptedAnswers: ['stomata', 'stomata'] },
        { questionId: 137, chapter: 'Plants', concept: 'Plant Parts', type: 'mcq', difficulty: 'Medium', question: 'What type of root system do monocots have?', options: ['Fibrous roots', 'Tap root', 'No roots', 'Adventitious roots'], correctAnswer: 'Fibrous roots' },
        { questionId: 138, chapter: 'Plants', concept: 'Photosynthesis', type: 'reasoning', difficulty: 'Hard', question: 'What would happen to a plant if it is kept in a dark room for two weeks?', correctAnswer: 'it will die', acceptedAnswers: ['die', 'will die', 'wilt', 'no food', 'no sunlight'] },
        { questionId: 139, chapter: 'Plants', concept: 'Plant Functions', type: 'criticalthinking', difficulty: 'Hard', question: 'If a plant has yellowing leaves, what could be the reason? Think of at least two possibilities.', correctAnswer: 'nutrient deficiency', acceptedAnswers: ['nutrient', 'lack of nutrients', 'less light', 'overwatering', 'nitrogen deficiency'] },
        { questionId: 140, chapter: 'Plants', concept: 'Photosynthesis', type: 'problemsolving', difficulty: 'Hard', question: 'You want to test if plants need light to photosynthesize. Design a simple experiment.', correctAnswer: 'control experiment', acceptedAnswers: ['control', 'two plants', 'one in light', 'one in dark', 'compare'] },
      ]},
      { name: 'Human Body', questions: [
        { questionId: 26, chapter: 'Human Body', concept: 'Skeletal System', type: 'mcq', difficulty: 'Easy', question: 'How many bones does an adult human body have?', options: ['206', '106', '306', '156'], correctAnswer: '206' },
        { questionId: 27, chapter: 'Human Body', concept: 'Organs', type: 'match', difficulty: 'Medium', question: 'Match the organ with its function:', correctAnswer: 'Heart-Blood Pumping|Lungs-Breathing|Brain-Thinking|Stomach-Digestion', acceptedAnswers: ['Heart-Blood Pumping|Lungs-Breathing|Brain-Thinking|Stomach-Digestion'] },
        { questionId: 28, chapter: 'Human Body', concept: 'Digestive System', type: 'fillblank', difficulty: 'Easy', question: 'Digestion of food starts in the _______.', correctAnswer: 'mouth', acceptedAnswers: ['mouth'] },
        { questionId: 29, chapter: 'Human Body', concept: 'Sense Organs', type: 'truefalse', difficulty: 'Easy', question: 'We hear with the help of our ears.', correctAnswer: 'True', acceptedAnswers: ['True', 'true', 'T', 't'] },
        { questionId: 30, chapter: 'Human Body', concept: 'Human Body', type: 'criticalthinking', difficulty: 'Hard', question: 'If someone has a broken leg, which system of the body is affected? Why?', correctAnswer: 'skeletal system', acceptedAnswers: ['skeletal', 'bones', 'skeletal system', 'bones system'] },
        { questionId: 141, chapter: 'Human Body', concept: 'Circulatory System', type: 'mcq', difficulty: 'Medium', question: 'Which organ pumps blood throughout the body?', options: ['Heart', 'Lungs', 'Brain', 'Liver'], correctAnswer: 'Heart' },
        { questionId: 142, chapter: 'Human Body', concept: 'Respiratory System', type: 'mcq', difficulty: 'Easy', question: 'What is the main function of the lungs?', options: ['Breathing', 'Digestion', 'Thinking', 'Movement'], correctAnswer: 'Breathing' },
        { questionId: 143, chapter: 'Human Body', concept: 'Digestive System', type: 'fillblank', difficulty: 'Medium', question: 'Food travels from the mouth to the stomach through a tube called the _______.', correctAnswer: 'esophagus', acceptedAnswers: ['esophagus', 'food pipe', 'oesophagus'] },
        { questionId: 144, chapter: 'Human Body', concept: 'Nervous System', type: 'mcq', difficulty: 'Easy', question: 'Which part of the brain controls thinking?', options: ['Brain', 'Heart', 'Stomach', 'Liver'], correctAnswer: 'Brain' },
        { questionId: 145, chapter: 'Human Body', concept: 'Skeletal System', type: 'truefalse', difficulty: 'Easy', question: 'Your ribs protect your heart and lungs.', correctAnswer: 'True', acceptedAnswers: ['True', 'true', 'T', 't'] },
        { questionId: 146, chapter: 'Human Body', concept: 'Circulatory System', type: 'oneword', difficulty: 'Medium', question: 'What is the fluid that carries oxygen in your blood?', correctAnswer: 'blood', acceptedAnswers: ['blood'] },
        { questionId: 147, chapter: 'Human Body', concept: 'Digestive System', type: 'fillblank', difficulty: 'Medium', question: 'The process of breaking down food in the body is called _______.', correctAnswer: 'digestion', acceptedAnswers: ['digestion'] },
        { questionId: 148, chapter: 'Human Body', concept: 'Nervous System', type: 'truefalse', difficulty: 'Easy', question: 'Your nervous system includes your brain, spinal cord, and nerves.', correctAnswer: 'True', acceptedAnswers: ['True', 'true', 'T', 't'] },
        { questionId: 149, chapter: 'Human Body', concept: 'Respiratory System', type: 'reasoning', difficulty: 'Hard', question: 'Why do you breathe faster when you run? Explain your answer.', correctAnswer: 'need more oxygen', acceptedAnswers: ['more oxygen', 'need oxygen', 'exercise', 'muscles need', 'faster breathing'] },
        { questionId: 150, chapter: 'Human Body', concept: 'Human Body', type: 'problemsolving', difficulty: 'Hard', question: 'A person cannot see objects far away. What problem might they have and what could cause it?', correctAnswer: 'near-sighted', acceptedAnswers: ['near-sighted', 'myopia', 'long-sighted', 'vision problem', 'eyesight'] },
      ]},
      { name: 'Water', questions: [
        { questionId: 31, chapter: 'Water', concept: 'States of Water', type: 'mcq', difficulty: 'Easy', question: 'Water exists in how many states?', options: ['3', '2', '4', '5'], correctAnswer: '3' },
        { questionId: 32, chapter: 'Water', concept: 'Water Cycle', type: 'fillblank', difficulty: 'Medium', question: 'The process of water changing into vapour is called _______.', correctAnswer: 'evaporation', acceptedAnswers: ['evaporation'] },
        { questionId: 33, chapter: 'Water', concept: 'Rain', type: 'truefalse', difficulty: 'Easy', question: 'Rain, snow and hail are different forms of precipitation.', correctAnswer: 'True', acceptedAnswers: ['True', 'true', 'T', 't'] },
        { questionId: 34, chapter: 'Water', concept: 'Water Sources', type: 'oneword', difficulty: 'Easy', question: 'Name the source of water that comes from the sky.', correctAnswer: 'rain', acceptedAnswers: ['rain', 'rainwater', 'rain water'] },
        { questionId: 35, chapter: 'Water', concept: 'Water Conservation', type: 'reasoning', difficulty: 'Hard', question: 'Why should we save water? Give two reasons.', correctAnswer: 'water is limited', acceptedAnswers: ['limited', 'not enough', 'save', 'conservation', 'future'] },
        { questionId: 151, chapter: 'Water', concept: 'States of Water', type: 'mcq', difficulty: 'Easy', question: 'At what temperature does water freeze?', options: ['0\u00B0C', '100\u00B0C', '10\u00B0C', '50\u00B0C'], correctAnswer: '0\u00B0C' },
        { questionId: 152, chapter: 'Water', concept: 'Water Cycle', type: 'mcq', difficulty: 'Medium', question: 'What is the process of water vapour turning into liquid called?', options: ['Condensation', 'Evaporation', 'Precipitation', 'Transpiration'], correctAnswer: 'Condensation' },
        { questionId: 153, chapter: 'Water', concept: 'Water Sources', type: 'mcq', difficulty: 'Easy', question: 'Which of these is a source of fresh water?', options: ['River', 'Ocean', 'Sea', 'Gulf'], correctAnswer: 'River' },
        { questionId: 154, chapter: 'Water', concept: 'Water Cycle', type: 'truefalse', difficulty: 'Medium', question: 'The water cycle has no beginning or end.', correctAnswer: 'True', acceptedAnswers: ['True', 'true', 'T', 't'] },
        { questionId: 155, chapter: 'Water', concept: 'States of Water', type: 'fillblank', difficulty: 'Easy', question: 'When water is heated to 100\u00B0C, it turns into _______.', correctAnswer: 'steam', acceptedAnswers: ['steam', 'water vapour', 'vapor'] },
        { questionId: 156, chapter: 'Water', concept: 'Water Conservation', type: 'mcq', difficulty: 'Medium', question: 'Which of these helps conserve water?', options: ['Turning off tap while brushing', 'Leaving tap running', 'Using hose to wash car', 'Taking long baths'], correctAnswer: 'Turning off tap while brushing' },
        { questionId: 157, chapter: 'Water', concept: 'Water Cycle', type: 'fillblank', difficulty: 'Medium', question: 'Water falls from clouds as rain, snow or hail. This is called _______.', correctAnswer: 'precipitation', acceptedAnswers: ['precipitation'] },
        { questionId: 158, chapter: 'Water', concept: 'Water Sources', type: 'truefalse', difficulty: 'Easy', question: 'Most of the Earth\'s water is fresh and available for drinking.', correctAnswer: 'False', acceptedAnswers: ['False', 'false', 'F', 'f'] },
        { questionId: 159, chapter: 'Water', concept: 'Water Conservation', type: 'reasoning', difficulty: 'Hard', question: 'If all the water on Earth is 100 gallons, about how much is drinking water? Explain.', correctAnswer: 'very small amount', acceptedAnswers: ['small amount', 'very little', 'not much', '1%', 'less than 1', 'small'] },
        { questionId: 160, chapter: 'Water', concept: 'Water Cycle', type: 'problemsolving', difficulty: 'Hard', question: 'A farmer needs to save water for his crops in a dry area. Suggest two methods.', correctAnswer: 'drip irrigation', acceptedAnswers: ['drip', 'drip irrigation', 'irrigation', 'mulching', 'rainwater', 'save water', 'timing'] },
      ]},
      { name: 'Weather and Seasons', questions: [
        { questionId: 36, chapter: 'Weather and Seasons', concept: 'Weather', type: 'mcq', difficulty: 'Easy', question: 'The average weather conditions of a place over a long time is called:', options: ['Climate', 'Weather', 'Temperature', 'Rainfall'], correctAnswer: 'Climate' },
        { questionId: 37, chapter: 'Weather and Seasons', concept: 'Seasons', type: 'match', difficulty: 'Medium', question: 'Match the season with the weather:', correctAnswer: 'Summer-Hot|Winter-Cold|Monsoon-Rainy|Spring-Mild', acceptedAnswers: ['Summer-Hot|Winter-Cold|Monsoon-Rainy|Spring-Mild'] },
        { questionId: 38, chapter: 'Weather and Seasons', concept: 'Temperature', type: 'fillblank', difficulty: 'Medium', question: 'The hottest time of the day is usually in the _______.', correctAnswer: 'afternoon', acceptedAnswers: ['afternoon', 'noon', 'middle of day'] },
        { questionId: 39, chapter: 'Weather and Seasons', concept: 'Weather', type: 'truefalse', difficulty: 'Easy', question: 'Wind is moving air.', correctAnswer: 'True', acceptedAnswers: ['True', 'true', 'T', 't'] },
        { questionId: 40, chapter: 'Weather and Seasons', concept: 'Seasons', type: 'criticalthinking', difficulty: 'Hard', question: 'Why do we wear different clothes in different seasons?', correctAnswer: 'different temperatures', acceptedAnswers: ['temperature', 'weather', 'hot', 'cold', 'protection'] },
        { questionId: 161, chapter: 'Weather and Seasons', concept: 'Weather', type: 'mcq', difficulty: 'Easy', question: 'Which instrument is used to measure temperature?', options: ['Thermometer', 'Barometer', 'Rain gauge', 'Anemometer'], correctAnswer: 'Thermometer' },
        { questionId: 162, chapter: 'Weather and Seasons', concept: 'Seasons', type: 'mcq', difficulty: 'Medium', question: 'What causes seasons to change?', options: ['Earth tilted orbit around sun', 'Moon phases', 'Cloud cover', 'Wind patterns'], correctAnswer: 'Earth tilted orbit around sun' },
        { questionId: 163, chapter: 'Weather and Seasons', concept: 'Weather', type: 'fillblank', difficulty: 'Medium', question: 'The amount of water in the air is called _______.', correctAnswer: 'humidity', acceptedAnswers: ['humidity', 'humidity'] },
        { questionId: 164, chapter: 'Weather and Seasons', concept: 'Seasons', type: 'truefalse', difficulty: 'Easy', question: 'Summer in India happens at the same time as in Australia.', correctAnswer: 'False', acceptedAnswers: ['False', 'false', 'F', 'f'] },
        { questionId: 165, chapter: 'Weather and Seasons', concept: 'Weather', type: 'mcq', difficulty: 'Easy', question: 'What do we call fast-moving air?', options: ['Wind', 'Cloud', 'Rain', 'Storm'], correctAnswer: 'Wind' },
        { questionId: 166, chapter: 'Weather and Seasons', concept: 'Seasons', type: 'fillblank', difficulty: 'Medium', question: 'India has mainly _______ seasons.', correctAnswer: 'six', acceptedAnswers: ['six', '6', 'six season', '6 season'] },
        { questionId: 167, chapter: 'Weather and Seasons', concept: 'Weather', type: 'oneword', difficulty: 'Medium', question: 'What is falling water from clouds called?', correctAnswer: 'rain', acceptedAnswers: ['rain', 'rainfall', 'precipitation'] },
        { questionId: 168, chapter: 'Weather and Seasons', concept: 'Seasons', type: 'truefalse', difficulty: 'Easy', question: 'The equator region has three distinct seasons like India.', correctAnswer: 'False', acceptedAnswers: ['False', 'false', 'F', 'f'] },
        { questionId: 169, chapter: 'Weather and Seasons', concept: 'Weather', type: 'reasoning', difficulty: 'Hard', question: 'Why does the desert have very little rainfall? Explain.', correctAnswer: 'hot and dry', acceptedAnswers: ['hot', 'dry', 'no clouds', 'far from sea', 'high temperature', 'desert conditions'] },
        { questionId: 170, chapter: 'Weather and Seasons', concept: 'Seasons', type: 'problemsolving', difficulty: 'Hard', question: 'You notice birds flying south in autumn. Why do they do this? What other adaptations help animals survive winter?', correctAnswer: 'migration', acceptedAnswers: ['migration', 'move south', 'warmer place', 'fur', 'hibernate', 'store food'] },
      ]},
      { name: 'Fun with Magnets', questions: [
        { questionId: 41, chapter: 'Fun with Magnets', concept: 'Magnetic Properties', type: 'mcq', difficulty: 'Easy', question: 'Which metal is attracted to a magnet?', options: ['Iron', 'Wood', 'Plastic', 'Glass'], correctAnswer: 'Iron' },
        { questionId: 42, chapter: 'Fun with Magnets', concept: 'Magnet Poles', type: 'fillblank', difficulty: 'Medium', question: 'A magnet has _______ poles.', correctAnswer: 'two', acceptedAnswers: ['two', '2', 'two poles', '2 poles'] },
        { questionId: 43, chapter: 'Fun with Magnets', concept: 'Magnet Uses', type: 'truefalse', difficulty: 'Easy', question: 'A magnet can attract paper clips made of iron.', correctAnswer: 'True', acceptedAnswers: ['True', 'true', 'T', 't'] },
        { questionId: 44, chapter: 'Fun with Magnets', concept: 'Magnet Direction', type: 'oneword', difficulty: 'Easy', question: 'A suspended magnet always aligns in which direction?', correctAnswer: 'north south', acceptedAnswers: ['north south', 'north-south', 'north', 'south'] },
        { questionId: 45, chapter: 'Fun with Magnets', concept: 'Magnet Properties', type: 'problemsolving', difficulty: 'Hard', question: 'You have a mixture of iron filings and sand. How will you separate them using a magnet?', correctAnswer: 'use magnet', acceptedAnswers: ['magnet', 'use magnet', 'attract', 'pick up'] },
        { questionId: 171, chapter: 'Fun with Magnets', concept: 'Magnetic Properties', type: 'mcq', difficulty: 'Easy', question: 'Which of these is NOT magnetic?', options: ['Copper', 'Iron', 'Nickel', 'Cobalt'], correctAnswer: 'Copper' },
        { questionId: 172, chapter: 'Fun with Magnets', concept: 'Magnet Poles', type: 'mcq', difficulty: 'Medium', question: 'Like poles of two magnets ______ each other.', options: ['Repel', 'Attract', 'Neutralize', 'Nothing'], correctAnswer: 'Repel' },
        { questionId: 173, chapter: 'Fun with Magnets', concept: 'Magnet Uses', type: 'mcq', difficulty: 'Easy', question: 'Compass uses a magnet to show which direction?', options: ['North-South', 'East-West', 'Up-Down', 'Left-Right'], correctAnswer: 'North-South' },
        { questionId: 174, chapter: 'Fun with Magnets', concept: 'Magnet Poles', type: 'truefalse', difficulty: 'Easy', question: 'Opposite poles of magnets attract each other.', correctAnswer: 'True', acceptedAnswers: ['True', 'true', 'T', 't'] },
        { questionId: 175, chapter: 'Fun with Magnets', concept: 'Magnetic Properties', type: 'fillblank', difficulty: 'Medium', question: 'A magnet can attract objects made of ______ and ______.', correctAnswer: 'iron nickel', acceptedAnswers: ['iron nickel', 'iron and nickel', 'iron cobalt', 'iron steel'] },
        { questionId: 176, chapter: 'Fun with Magnets', concept: 'Magnet Uses', type: 'oneword', difficulty: 'Medium', question: 'What device uses a magnet to find direction?', correctAnswer: 'compass', acceptedAnswers: ['compass'] },
        { questionId: 177, chapter: 'Fun with Magnets', concept: 'Magnet Poles', type: 'fillblank', difficulty: 'Medium', question: 'The two ends of a magnet are called _______.', correctAnswer: 'poles', acceptedAnswers: ['poles', 'magnet poles', 'two poles'] },
        { questionId: 178, chapter: 'Fun with Magnets', concept: 'Magnetic Properties', type: 'truefalse', difficulty: 'Easy', question: 'A magnetic substance loses its magnetic property when heated strongly.', correctAnswer: 'True', acceptedAnswers: ['True', 'true', 'T', 't'] },
        { questionId: 179, chapter: 'Fun with Magnets', concept: 'Magnet Uses', type: 'reasoning', difficulty: 'Hard', question: 'Why is a compass important for travelers in the past when they could not see the sun?', correctAnswer: 'direction', acceptedAnswers: ['direction', 'north', 'finding way', 'navigation', 'lost'] },
        { questionId: 180, chapter: 'Fun with Magnets', concept: 'Magnetic Properties', type: 'problemsolving', difficulty: 'Hard', question: 'How would you test whether an unknown object is magnetic? Describe your method.', correctAnswer: 'test with magnet', acceptedAnswers: ['magnet', 'test with', 'paper clips', 'iron filings', 'suspend', 'attract'] },
      ]},
    ],
  },
}

// ---- VOICE NARRATION HOOK ----
function useVoiceNarration() {
  const [speaking, setSpeaking] = useState(false)
  const [paused, setPaused] = useState(false)
  const [volume, setVolume] = useState(80)

  const speak = useCallback((text: string, onEnd?: () => void) => {
    if (!('speechSynthesis' in window)) { onEnd?.(); return }
    window.speechSynthesis.cancel()
    const utterance = new SpeechSynthesisUtterance(text)
    utterance.volume = volume / 100
    utterance.rate = 0.9
    utterance.pitch = 1
    utterance.onstart = () => { setSpeaking(true); setPaused(false) }
    utterance.onend = () => { setSpeaking(false); setPaused(false); onEnd?.() }
    utterance.onerror = () => { setSpeaking(false); setPaused(false); onEnd?.() }
    window.speechSynthesis.speak(utterance)
  }, [volume])

  const pause = useCallback(() => {
    if ('speechSynthesis' in window) window.speechSynthesis.pause()
    setPaused(true)
  }, [])

  const resume = useCallback(() => {
    if ('speechSynthesis' in window) window.speechSynthesis.resume()
    setPaused(false)
  }, [])

  const stop = useCallback(() => {
    if ('speechSynthesis' in window) window.speechSynthesis.cancel()
    setSpeaking(false)
    setPaused(false)
  }, [])

  const togglePause = useCallback(() => {
    if (paused) resume()
    else pause()
  }, [paused, pause, resume])

  useEffect(() => () => {
    if ('speechSynthesis' in window) window.speechSynthesis.cancel()
  }, [])

  return { speak, pause, resume, stop, togglePause, speaking, paused, volume, setVolume }
}

// ---- SPEECH CONTROLS ----
// Presentational Play / Pause / Resume / Stop set shared by the PPT and Audio
// modes. Speech state is owned by the parent so narration can be stopped when the
// learner moves on to another slide or mode.
type SpeechControlsProps = {
  playLabel: string
  speaking: boolean
  paused: boolean
  onPlay: () => void
  onTogglePause: () => void
  onStop: () => void
}

function SpeechControls({ playLabel, speaking, paused, onPlay, onTogglePause, onStop }: SpeechControlsProps) {
  const supported = typeof window !== 'undefined' && 'speechSynthesis' in window
  if (!supported) return null

  return (
    <div className="speech-controls">
      {speaking ? (
        <>
          <button type="button" className="speech-btn is-primary" onClick={onTogglePause}>
            <span>{paused ? '\u25B6' : '\u23F8'}</span> {paused ? 'Resume' : 'Pause'}
          </button>
          <button type="button" className="speech-btn" onClick={onStop}>
            <span>{'\u23F9'}</span> Stop
          </button>
          <span className="speech-status">{paused ? 'Paused' : 'Reading aloud...'}</span>
        </>
      ) : (
        <>
          <button type="button" className="speech-btn is-primary" onClick={onPlay}>
            <span>{'\uD83D\uDD0E'}</span> {playLabel}
          </button>
          <button type="button" className="speech-btn" onClick={onStop}>
            <span>{'\u23F9'}</span> Stop
          </button>
        </>
      )}
    </div>
  )
}

// ---- HELPERS ----
const normalizeAnswer = (value: string): string => value.trim().toLowerCase().replace(/\s+/g, ' ')

const checkAnswer = (q: AssessmentQuestion, userAnswer: string): boolean => {
  if (!userAnswer) return false
  const normalizedUser = normalizeAnswer(userAnswer)

  if (q.type === 'match') {
    const expected = q.correctAnswer.split('|').map(normalizeAnswer).sort()
    const actual = userAnswer.split('|').map(normalizeAnswer).sort()
    return expected.length === actual.length && expected.every((pair, i) => pair === actual[i])
  }

  const accepted = (q.acceptedAnswers && q.acceptedAnswers.length > 0 ? q.acceptedAnswers : [q.correctAnswer]).map(normalizeAnswer)

  if (q.type === 'mcq' || q.type === 'truefalse' || q.type === 'match') {
    return accepted.includes(normalizedUser)
  }

  return accepted.some(a => normalizedUser === a || normalizedUser.includes(a))
}

const getTypeBadge = (type: string): string => {
  const badges: Record<string, string> = {
    mcq: 'MCQ', truefalse: 'T/F', fillblank: 'Fill Blank', match: 'Match',
    oneword: 'One Word', reasoning: 'Reasoning', criticalthinking: 'Critical Think',
    problemsolving: 'Problem Solve', viva: 'Viva'
  }
  return badges[type] || type
}

const getTypeColor = (type: string): string => {
  const colors: Record<string, string> = {
    mcq: '#6557d8', truefalse: '#50c1b4', fillblank: '#8b7ee4', match: '#d6819a',
    oneword: '#f59e0b', reasoning: '#ef4444', criticalthinking: '#ec4899',
    problemsolving: '#f97316', viva: '#6366f1'
  }
  return colors[type] || '#9b9fb4'
}

const getRiskColor = (risk: string): string => {
  if (risk === 'High') return '#ef4444'
  if (risk === 'Medium') return '#f59e0b'
  return '#22c55e'
}

const getRiskBadge = (score: number): 'Low' | 'Medium' | 'High' => {
  if (score >= 70) return 'Low'
  if (score >= 40) return 'Medium'
  return 'High'
}

const calcMastery = (score: number, confidence: number): number => Math.round((score * 0.7 + confidence * 0.3))
const calcConfidence = (answers: Record<number, string>, confidenceMap: Record<number, Confidence>): number => {
  if (Object.keys(confidenceMap).length === 0) return 0
  const weights: Record<string, number> = { 'Very Confident': 100, 'Confident': 75, 'Unsure': 40, 'Guessing': 15 }
  const entries = Object.values(confidenceMap)
  return Math.round(entries.reduce((sum, c) => sum + (weights[c] || 0), 0) / entries.length)
}

const SUBJECT_META: Record<string, { emoji: string; icon: string }> = {
  Mathematics: { emoji: '\uD83D\uDCD8', icon: '\uD83D\uDED9' },
  Science: { emoji: '\uD83D\uDCD7', icon: '\uD83D\uDD2C' }
}

const subjectEmoji = (subject: string) => SUBJECT_META[subject]?.emoji ?? '\uD83D\uDCD6'
const subjectIcon = (subject: string) => SUBJECT_META[subject]?.icon ?? '\uD83D\uDCDD'

// Seeded chapters carry placeholder media links (example.com) until real assets are
// attached. Offering those as a playable source just leads to a dead link, so they
// are detected and the chapter falls back to a clear "not attached" state.
const PLACEHOLDER_HOSTS = ['example.com', 'example.org', 'example.net']
const isPlayableUrl = (url?: string): boolean => {
  const trimmed = (url || '').trim()
  if (!trimmed) return false
  try {
    const parsed = new URL(trimmed, window.location.origin)
    if (parsed.protocol !== 'http:' && parsed.protocol !== 'https:') return false
    const host = parsed.hostname.toLowerCase()
    return !PLACEHOLDER_HOSTS.some(placeholder => host === placeholder || host.endsWith(`.${placeholder}`))
  } catch {
    return false
  }
}

const buildSubjectWiseResults = (
  subjectOrder: string[],
  groupedQuestions: Record<string, AssessmentQuestion[]>,
  results: AssessmentResult['questionResults'],
  confidenceMap: Record<number, Confidence>
): SubjectWiseResult[] => subjectOrder.map(subject => {
  const subjectQuestions = groupedQuestions[subject] || []
  const subjectResults = results.filter(r => subjectQuestions.some(q => q.questionId === r.questionId))
  const correct = subjectResults.filter(r => r.isCorrect)
  const incorrect = subjectResults.filter(r => !r.isCorrect)
  return {
    subject,
    score: correct.length,
    total: subjectQuestions.length,
    percentage: subjectQuestions.length > 0 ? Math.round((correct.length / subjectQuestions.length) * 100) : 0,
    questionIds: subjectQuestions.map(q => q.questionId),
    correctQuestionIds: correct.map(r => r.questionId),
    incorrectQuestionIds: incorrect.map(r => r.questionId),
    conceptsCorrect: [...new Set(correct.map(r => r.concept))],
    conceptsIncorrect: [...new Set(incorrect.map(r => r.concept))]
  }
})

const DIFFICULTY_WEIGHT: Record<string, number> = { Easy: 0.6, Medium: 0.8, Hard: 1 }

// Each cognitive skill is measured from the question types that actually exercise it.
// When the pool contains no question of that type we fall back to difficulty-weighted
// accuracy, and say so, rather than printing an unqualified zero.
const COGNITIVE_SKILL_TYPES: Record<'reasoning' | 'problemSolving' | 'criticalThinking', string[]> = {
  reasoning: ['reasoning', 'viva'],
  problemSolving: ['problemsolving'],
  criticalThinking: ['criticalthinking']
}

const computeCognitiveSkills = (results: AssessmentResult['questionResults']): CognitiveSkills => {
  const overall = results.length > 0
    ? Math.round(results.reduce((sum, r) => sum + (r.isCorrect ? 1 : 0), 0) / results.length * 100)
    : 0

  const difficultyWeighted = () => {
    if (results.length === 0) return 0
    const total = results.reduce((sum, r) => sum + (DIFFICULTY_WEIGHT[r.difficulty || 'Medium'] ?? 0.8), 0)
    if (total === 0) return overall
    const earned = results.reduce((sum, r) => sum + (r.isCorrect ? (DIFFICULTY_WEIGHT[r.difficulty || 'Medium'] ?? 0.8) : 0), 0)
    return Math.round((earned / total) * 100)
  }

  const measure = (types: string[]) => {
    const matching = results.filter(r => types.includes(r.questionType))
    if (matching.length === 0) return { value: difficultyWeighted(), basis: `estimated from ${results.length} assessed questions` }
    const correct = matching.filter(r => r.isCorrect).length
    return {
      value: Math.round((correct / matching.length) * 100),
      basis: `${correct}/${matching.length} ${types[0] === 'viva' ? 'reasoning' : types[0]} questions`
    }
  }

  const reasoning = measure(COGNITIVE_SKILL_TYPES.reasoning)
  const problemSolving = measure(COGNITIVE_SKILL_TYPES.problemSolving)
  const criticalThinking = measure(COGNITIVE_SKILL_TYPES.criticalThinking)

  return {
    reasoning: reasoning.value,
    problemSolving: problemSolving.value,
    criticalThinking: criticalThinking.value,
    reasoningBasis: reasoning.basis,
    problemSolvingBasis: problemSolving.basis,
    criticalThinkingBasis: criticalThinking.basis
  }
}

const buildDNAInput = (subjectWiseResults: SubjectWiseResult[], totalCorrect: number, totalQuestions: number, confidenceMap: Record<number, Confidence>, questionResults: AssessmentResult['questionResults']): LearningDNAInput => {
  const bySubject = (name: string) => subjectWiseResults.find(s => s.subject === name)
  const subjectDNA: SubjectDNAPayload[] = subjectWiseResults.map(result => {
    const subjectConfidence = result.questionIds.length > 0
      ? Math.round(result.questionIds.reduce((sum, id) => sum + (calcConfidence({}, { [id]: confidenceMap[id] || 'Unsure' })), 0) / result.questionIds.length)
      : 0
    return {
      subject: result.subject,
      score: result.score,
      percentage: result.percentage,
      risk: getRiskBadge(result.percentage),
      mastery: result.percentage,
      confidence: subjectConfidence,
      answeredCorrectly: result.score,
      totalQuestions: result.total,
      strengths: result.conceptsCorrect,
      gaps: result.conceptsIncorrect
    }
  })

  return {
    mathematicsScore: bySubject('Mathematics')?.score ?? 0,
    scienceScore: bySubject('Science')?.score ?? 0,
    totalScore: totalCorrect,
    totalCorrect,
    totalQuestions,
    overallPercentage: totalQuestions > 0 ? Math.round((totalCorrect / totalQuestions) * 100) : 0,
    cognitiveSkills: computeCognitiveSkills(questionResults),
    subjectWiseResults,
    subjectDNA
  }
}

// ---- REGISTRATION ----
function RegistrationScreen({ onStartAssessment }: { onStartAssessment: (data: RegistrationData) => void }) {
  const [form, setForm] = useState<RegistrationData>({
    studentName: '', class: '', schoolName: '', email: '', contactNumber: '',
    preferredSubjects: [], learningGoal: '', registrationDate: new Date().toISOString(),
  })
  const [terms, setTerms] = useState(false)
  const [saving, setSaving] = useState(false)
  const [fieldErrors, setFieldErrors] = useState<Record<string, string>>({})
  const [successData, setSuccessData] = useState<SuccessData | null>(null)

  const update = (key: keyof RegistrationData, value: string | string[]) => setForm((current) => ({ ...current, [key]: value }))
  const toggleSubject = (subject: string) => update('preferredSubjects', form.preferredSubjects.includes(subject) ? form.preferredSubjects.filter((item) => item !== subject) : [...form.preferredSubjects, subject])

  const validateForm = () => {
    const errors: Record<string, string> = {}
    if (!form.studentName.trim()) errors.studentName = 'Student Name is required.'
    if (!form.class.trim()) errors.class = 'Class is required.'
    if (!form.schoolName.trim()) errors.schoolName = 'School Name is required.'
    if (!form.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(form.email)) errors.email = 'A valid Email ID is required.'
    if (!form.contactNumber.trim()) errors.contactNumber = 'Contact Number is required.'
    else if (!/^\d{10}$/.test(form.contactNumber.trim())) errors.contactNumber = 'Contact Number must be exactly 10 digits.'
    if (!form.preferredSubjects.length) errors.preferredSubjects = 'Please select at least one preferred subject.'
    if (!terms) errors.terms = 'Please accept the Terms & Conditions to continue.'
    return errors
  }

  const submit = async (event: React.FormEvent) => {
    event.preventDefault()
    const validationErrors = validateForm()
    if (Object.keys(validationErrors).length > 0) { setFieldErrors(validationErrors); return }
setSaving(true); setFieldErrors({})
      try {
        const response = await axios.post('/api/students/register', { ...form, studentName: form.studentName.trim(), schoolName: form.schoolName.trim(), email: form.email.trim(), contactNumber: form.contactNumber.trim(), learningGoal: form.learningGoal.trim() })
        const studentId = response.data?.studentId || response.data?.student_id
        if (!studentId) throw new Error('No learner id returned')
        setSuccessData({ studentId, studentName: form.studentName.trim(), preferredSubjects: form.preferredSubjects })
      } catch {
        // Never fall back to a shared id: that would hand this learner another
        // learner's saved progress. Generate a unique device-local id instead so
        // their profile starts empty and is clearly not synced.
        setSuccessData({
          studentId: `LOCAL-${Date.now().toString(36).toUpperCase()}`,
          studentName: form.studentName.trim(),
          preferredSubjects: form.preferredSubjects
        })
      }
      finally { setSaving(false) }
  }

  return (
    <div className="registration-screen">
      <header className="walk-header"><Logo /><span className="registration-tagline">Discover how you learn, not just your score</span></header>
      {fieldErrors.submission && <div className="form-error-global" role="alert">{fieldErrors.submission}</div>}
      {successData && (
        <div className="success-overlay" onClick={(e) => e.stopPropagation()}>
          <div className="success-backdrop" />
          <AnimatePresence>
            <motion.div className="success-glass" key="success-modal" initial={{ opacity: 0, scale: 0.85, y: 30 }} animate={{ opacity: 1, scale: 1, y: 0 }} exit={{ opacity: 0, scale: 0.85, y: 30 }} transition={{ duration: 0.4, ease: [0.22, 1, 0.36, 1] }}>
              <div className="success-confetti-burst" aria-hidden="true">{Array.from({ length: 24 }, (_, i) => <span key={`${successData.studentId}-${i}`} className={`confetti-piece c${i % 4}`} style={{ left: `${(i * 13.5) % 100}%`, animationDelay: `${(i % 7) * 0.05}s` }} />)}</div>
              <div className="success-icon-wrap"><motion.div className="success-circle" initial={{ scale: 0 }} animate={{ scale: 1 }} transition={{ type: "spring", stiffness: 260, damping: 20, delay: 0.2 }}><span className="success-checkmark">{"\u2713"}</span></motion.div></div>
              <motion.div className="success-content" initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.3, duration: 0.4 }}>
                <div className="success-tag"><motion.span className="success-emoji" initial={{ rotate: -15 }} animate={{ rotate: 0 }} transition={{ type: "spring", stiffness: 300, delay: 0.4 }}>{"\uD83C\uDF89"}</motion.span>Congratulations!</div>
                <h2>Welcome to <span>AI Learning DNA</span></h2>
                <p>Your learner intelligence profile is ready.</p>
                {successData.studentId.startsWith('LOCAL-') && (
                  <div className="success-offline-note">
                    Saved on this device only — the profile service was unreachable, so this
                    profile will not sync or appear on other devices.
                  </div>
                )}
                <div className="success-profile-preview">
                  <div className="profile-row"><span className="profile-label">Name</span><span className="profile-value">{successData.studentName}</span></div>
                  <div className="profile-row"><span className="profile-label">Student ID</span><span className="profile-value mono">{successData.studentId}</span></div>
                  <div className="profile-row"><span className="profile-label">Subjects</span><span className="profile-value">{successData.preferredSubjects.join(' \u00B7 ')}</span></div>
                </div>
                <button className="success-action-btn" type="button" onClick={() => onStartAssessment({ ...form, id: successData.studentId, studentName: successData.studentName, preferredSubjects: successData.preferredSubjects })}>
                  Start Baseline Assessment <span>{"\u2197"}</span>
                </button>
                <p className="success-subtext">Your first assessment will create your Chapter DNA profile.</p>
              </motion.div>
            </motion.div>
          </AnimatePresence>
        </div>
      )}
      <main className="registration-layout">
        <section className="registration-story">
          <div className="walk-eyebrow"><span /> YOUR JOURNEY STARTS HERE</div>
          <h1>Create your<br /><em>Learning DNA.</em></h1>
          <p>Build a personalized learner intelligence profile.</p>
          <div className="registration-flow">{['Assessment', 'Chapter DNA', 'AI Companion', 'Growth Plan'].map((step, i) => <div key={step}><span>{i + 1}</span><b>{step}</b>{i < 3 && <i>{"\u2192"}</i>}</div>)}</div>
          <div className="registration-visual"><DNAHelix small /><span className="registration-orbit one" /><span className="registration-orbit two" /></div>
        </section>
        <form className="registration-card" onSubmit={submit} noValidate>
          <div className="section-kicker">YOUR STORY STARTS HERE</div><h2>Create your <span>Learning DNA</span></h2><p>Tell us a little about yourself.</p>
          <div className="registration-fields">
            <label>Student Name <em>*</em><input value={form.studentName} onChange={(e) => update('studentName', e.target.value)} placeholder="e.g. Ananya Sharma" className={fieldErrors.studentName ? 'input-error' : ''} /><span className="field-error">{fieldErrors.studentName}</span></label>
            <label>Class <em>*</em><select value={form.class} onChange={(e) => update('class', e.target.value)} className={fieldErrors.class ? 'input-error' : ''}><option value="">Select your class</option>{Array.from({ length: 12 }, (_, i) => <option key={i + 1}>Class {i + 1}</option>)}</select><span className="field-error">{fieldErrors.class}</span></label>
            <label>School Name <em>*</em><input value={form.schoolName} onChange={(e) => update('schoolName', e.target.value)} placeholder="e.g. Greenwood High" className={fieldErrors.schoolName ? 'input-error' : ''} /><span className="field-error">{fieldErrors.schoolName}</span></label>
            <label>Email ID <em>*</em><input type="email" value={form.email} onChange={(e) => update('email', e.target.value)} placeholder="you@example.com" className={fieldErrors.email ? 'input-error' : ''} /><span className="field-error">{fieldErrors.email}</span></label>
            <label>Contact Number <em>*</em><input value={form.contactNumber} onChange={(e) => update('contactNumber', e.target.value)} placeholder="e.g. +91 98765 43210" className={fieldErrors.contactNumber ? 'input-error' : ''} /><span className="field-error">{fieldErrors.contactNumber}</span></label>
            <div><span className="registration-label">Preferred Subjects <em>*</em></span>
              <div className="registration-subjects">{['Mathematics', 'Science', 'English', 'Computer Science'].map((s) => <button type="button" key={s} className={form.preferredSubjects.includes(s) ? 'selected' : ''} onClick={() => toggleSubject(s)}>{form.preferredSubjects.includes(s) ? <>{"\u2713"} </> : ''}{s}</button>)}</div>
            </div>
          </div>
          <span className="field-error field-error-top">{fieldErrors.preferredSubjects}</span>
          <label className="registration-consent"><input type="checkbox" checked={terms} onChange={(e) => setTerms(e.target.checked)} />I agree to Terms &amp; Conditions</label>
          <span className="field-error">{fieldErrors.terms}</span>
          {saving ? <button className="primary-button registration-submit" type="submit" disabled>Creating Your Learning DNA...</button>
            : <button className="primary-button registration-submit" type="submit">Register <span>{"\u2197"}</span></button>}
          <small className="registration-secure">{"\u231B"} Your information is secure and used only to personalize your learning journey.</small>
        </form>
      </main>
    </div>
  )
}
// ---- BASELINE ASSESSMENT PAGE ----
function BaselineAssessmentPage({ student, onBack, onComplete }: {
  student: BaselineAssessmentState
  onBack: () => void
  onComplete: (data: AssessmentSubmissionData) => void
}) {
  const [phase, setPhase] = useState<'overview' | 'assessment' | 'complete'>('overview')
  const [currentSubjectIndex, setCurrentSubjectIndex] = useState(0)
  const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [matchAnswers, setMatchAnswers] = useState<Record<number, Record<string, string>>>({})
  const [confidenceMap, setConfidenceMap] = useState<Record<number, Confidence>>({})

  const selectedSubjects = useMemo(() => student.preferredSubjects.filter(s => s === 'Mathematics' || s === 'Science'), [student.preferredSubjects])

  const subjectQuestions = useMemo(() => {
    const grouped: Record<string, AssessmentQuestion[]> = {}
selectedSubjects.forEach(subject => {
        const chapters = visibleChapters(subject)
        const allSubjectQuestions = chapters.flatMap(c => c.questions)
      const shuffled = shuffleArray(allSubjectQuestions)
      grouped[subject] = shuffled.slice(0, 5)
    })
    return grouped
  }, [selectedSubjects])

  const subjectOrder = useMemo(() => {
    const order: string[] = []
    if (selectedSubjects.includes('Mathematics')) order.push('Mathematics')
    if (selectedSubjects.includes('Science')) order.push('Science')
    return order
  }, [selectedSubjects])

  // Option / match-option order is fixed once per session so re-renders never reshuffle selections.
  const optionOrder = useMemo(() => {
    const map: Record<number, string[]> = {}
    Object.values(subjectQuestions).flat().forEach(q => {
      if (q.type === 'match') {
        map[q.questionId] = shuffleArray([...new Set(q.correctAnswer.split('|').map(p => p.split('-').slice(1).join('-').trim()))])
      } else {
        map[q.questionId] = shuffleArray(q.options || [])
      }
    })
    return map
  }, [subjectQuestions])

  const matchTerms = useMemo(() => {
    const map: Record<number, { term: string; correct: string }[]> = {}
    Object.values(subjectQuestions).flat().forEach(q => {
      if (q.type !== 'match') return
      map[q.questionId] = q.correctAnswer.split('|').map(pair => {
        const idx = pair.indexOf('-')
        return { term: pair.slice(0, idx), correct: pair.slice(idx + 1) }
      })
    })
    return map
  }, [subjectQuestions])

  const currentSubject = subjectOrder[currentSubjectIndex] || subjectOrder[0]
  const currentSubjectQuestions = subjectQuestions[currentSubject] || []
  const question = currentSubjectQuestions[currentQuestionIndex]

  const currentGlobalIndex = useMemo(() => {
    let offset = 0
    for (const s of subjectOrder) {
      if (s === currentSubject) break
      offset += (subjectQuestions[s] || []).length
    }
    return offset + currentQuestionIndex
  }, [subjectOrder, subjectQuestions, currentSubject, currentQuestionIndex])

  const totalQuestions = subjectOrder.reduce((sum, s) => sum + (subjectQuestions[s]?.length || 0), 0)
  const estTime = subjectOrder.length === 2 ? '15' : '10'

  // Single source of truth: a match question is answered only when every pair is chosen.
  const answerFor = useCallback((q: AssessmentQuestion): string => {
    if (q.type === 'match') {
      const pairs = (matchTerms[q.questionId] || [])
      if (pairs.length === 0) return ''
      const picks = matchAnswers[q.questionId] || {}
      if (!pairs.every(p => picks[p.term])) return ''
      return pairs.map(p => `${p.term}-${picks[p.term]}`).join('|')
    }
    return answers[q.questionId] || ''
  }, [matchAnswers, answers, matchTerms])

  const isQuestionAnswered = useCallback((q: AssessmentQuestion): boolean => answerFor(q) !== '', [answerFor])

  const answeredCount = subjectOrder.reduce((sum, s) => sum + (subjectQuestions[s] || []).filter(isQuestionAnswered).length, 0)
  const overallProgressPercent = totalQuestions > 0 ? Math.round((answeredCount / totalQuestions) * 100) : 0

  const currentSubjectAnswered = currentSubjectQuestions.filter(isQuestionAnswered).length
  const currentSubjectProgressPercent = currentSubjectQuestions.length > 0 ? Math.round((currentSubjectAnswered / currentSubjectQuestions.length) * 100) : 0

  const isFirstQuestion = currentQuestionIndex === 0 && currentSubjectIndex === 0
  const currentQuestionAnswered = question ? isQuestionAnswered(question) : false
  const isLastQuestionInSubject = currentQuestionIndex === currentSubjectQuestions.length - 1
  const isLastSubject = currentSubjectIndex === subjectOrder.length - 1

  const selectAnswer = (answer: string) => {
    if (!question) return
    const id = question.questionId
    if (question.type === 'match') return
    setAnswers(prev => ({ ...prev, [id]: answer }))
  }
  const selectMatchAnswer = (term: string, value: string) => {
    if (!question) return
    const id = question.questionId
    setMatchAnswers(prev => ({ ...prev, [id]: { ...(prev[id] || {}), [term]: value } }))
    setAnswers(prev => ({ ...prev, [id]: '' }))
  }
  const selectConfidence = (level: Confidence) => question && setConfidenceMap(prev => ({ ...prev, [question.questionId]: level }))

  const goNext = () => {
    if (!question || !isQuestionAnswered(question)) return

    if (isLastQuestionInSubject) {
      if (isLastSubject) {
        const allQuestionsFlat = subjectOrder.flatMap(s => (subjectQuestions[s] || []).map(q => ({ q, subject: s })))
        const questionResults = allQuestionsFlat.map(({ q, subject }) => {
          const userAnswer = answerFor(q)
          return {
            questionId: q.questionId,
            isCorrect: checkAnswer(q, userAnswer),
            concept: q.concept,
            questionType: q.type,
            userAnswer,
            correctAnswer: q.correctAnswer,
            subject,
            difficulty: q.difficulty
          }
        })

        const subjectWiseResults = buildSubjectWiseResults(subjectOrder, subjectQuestions, questionResults, confidenceMap)

        const correctCount = questionResults.filter(r => r.isCorrect).length
        const overallPercentage = totalQuestions > 0 ? Math.round((correctCount / totalQuestions) * 100) : 0
        const submissionData: AssessmentSubmissionData = {
          studentId: student.studentId,
          studentName: student.studentName,
          className: student.className,
          selectedSubjects: subjectOrder,
          assessmentResults: {
            studentId: student.studentId,
            studentName: student.studentName,
            className: student.className,
            subjects: subjectOrder,
            score: overallPercentage,
            totalQuestions,
            answeredCorrectly: correctCount,
            questionResults
          },
          confidenceResponses: allQuestionsFlat.map(({ q }) => ({
            questionId: q.questionId,
            selectedAnswer: answerFor(q),
            confidenceLevel: confidenceMap[q.questionId] || 'Unsure'
          })),
          subjectWiseResults,
          dnaInput: buildDNAInput(subjectWiseResults, correctCount, totalQuestions, confidenceMap, questionResults)
        }
        onComplete(submissionData)
      } else {
        setCurrentSubjectIndex(prev => prev + 1)
        setCurrentQuestionIndex(0)
      }
    } else {
      setCurrentQuestionIndex(prev => prev + 1)
    }
  }

  const goPrev = () => {
    if (currentQuestionIndex > 0) {
      setCurrentQuestionIndex(prev => prev - 1)
    } else if (currentSubjectIndex > 0) {
      setCurrentSubjectIndex(prev => prev - 1)
      const prevSubject = subjectOrder[currentSubjectIndex - 1]
      const prevSubjectQuestions = subjectQuestions[prevSubject] || []
      setCurrentQuestionIndex(prevSubjectQuestions.length - 1)
    }
  }

  // OVERVIEW PHASE
  if (phase === 'overview') {
    return (
      <motion.div className="assessment-screen" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
        <header className="walk-header assessment-sticky-header">
          <Logo />
          <div className="assessment-header-progress">
            <span>Baseline Assessment</span>
            <i><em style={{ width: '0%' }} /></i>
            <b>0%</b>
          </div>
          <button className="header-quiet" onClick={onBack}>{"\u2190"} Back</button>
        </header>
        <main className="assessment-intro">
          <Reveal>
            <div className="assessment-kicker" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 14px', borderRadius: 20, background: 'rgba(101,88,213,0.08)', marginBottom: 20 }}>
              <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#6558d7' }} />
              BASELINE ASSESSMENT {"\u00B7"} STEP 01
            </div>
          </Reveal>
          <Reveal delay={0.1}>
            <h1 style={{ marginBottom: 16 }}>Let's understand<br /><span>how you think.</span></h1>
          </Reveal>
          <Reveal delay={0.15}>
            <p style={{ maxWidth: 480, color: '#8c92ab', fontSize: 13, lineHeight: 1.7, marginBottom: 36 }}>This assessment creates your first Learning DNA profile. Your results help identify strengths, gaps, and personalized learning paths.</p>
          </Reveal>

          <Reveal delay={0.2}>
            <div className="student-info-card">
              <div className="student-info-head">
                <div className="student-avatar">{student.studentName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}</div>
                <div>
                  <small>LEARNER PROFILE</small>
                  <h2>{student.studentName}</h2>
                </div>
                <span className="baseline-pill">BASELINE</span>
              </div>
              <div className="student-info-grid">
                <div className="info-cell"><span>Class</span><b>{student.className}</b></div>
                <div className="info-cell"><span>Selected subjects</span><b>{subjectOrder.join(' \u00B7 ')}</b></div>
                <div className="info-cell"><span>Assessment type</span><b>Baseline Assessment</b></div>
                <div className="info-cell"><span>Estimated time</span><b>{estTime} minutes</b></div>
                <div className="info-cell"><span>Total questions</span><b>{totalQuestions}</b></div>
                <div className="info-cell"><span>Progress</span><b>0%</b></div>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.3}>
            <div style={{ display: 'flex', gap: 14, marginTop: 24, alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap' }}>
              {subjectOrder.map((s, i) => (
                <div key={s} className="subject-plan-card" style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 20px', borderRadius: 12, border: '1px solid #e0e1ed', background: '#fafaff' }}>
                  <span style={{ fontSize: 22 }}>{subjectEmoji(s)}</span>
                  <div>
                    <div style={{ color: '#7c829e', fontSize: 9, fontWeight: 600, letterSpacing: 0.5 }}>SUBJECT {i + 1} {"\u00B7"} {s.toUpperCase()}</div>
                    <div style={{ color: '#545b80', fontSize: 11, fontWeight: 600 }}>{(subjectQuestions[s] || []).length} questions</div>
                  </div>
                </div>
              ))}
              <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 20px', borderRadius: 12, border: '1px solid #e0e1ed', background: '#fafaff' }}>
                <span style={{ fontSize: 22 }}>{"\u23F1\uFE0F"}</span>
                <div>
                  <div style={{ color: '#7c829e', fontSize: 9, fontWeight: 600, letterSpacing: 0.5 }}>ESTIMATED TIME</div>
                  <div style={{ color: '#545b80', fontSize: 11, fontWeight: 600 }}>{estTime} minutes</div>
                </div>
              </div>
            </div>
          </Reveal>

          <Reveal delay={0.35}>
            <div style={{ textAlign: 'center', marginTop: 36 }}>
              <button className="primary-button start-assessment" onClick={() => setPhase('assessment')} disabled={totalQuestions === 0} style={{ padding: '16px 40px', fontSize: 12, opacity: totalQuestions === 0 ? .5 : 1, cursor: totalQuestions === 0 ? 'not-allowed' : 'pointer' }}>
                Start Assessment <span>{"\u2197"}</span>
              </button>
              <p style={{ color: '#9ca2b5', fontSize: 10, marginTop: 12 }}>Your responses are confidential and used only to build your learning profile</p>
            </div>
          </Reveal>
        </main>
      </motion.div>
    )
  }

  // ASSESSMENT PHASE
  if (phase === 'assessment' && question) {
    const isMCQ = question.type === 'mcq'
    const isTF = question.type === 'truefalse'
    const isMatchType = question.type === 'match'
    const isLast = isLastQuestionInSubject && isLastSubject
    const nextSubject = isLastQuestionInSubject && !isLastSubject ? subjectOrder[currentSubjectIndex + 1] : null

    return (
      <motion.div className="assessment-screen" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
        <header className="walk-header assessment-sticky-header">
          <Logo />
          <div className="assessment-header-progress">
            <span>{subjectEmoji(currentSubject)} {currentSubject} {"\u00B7"} {currentQuestionIndex + 1} of {currentSubjectQuestions.length}</span>
            <i><em style={{ width: `${overallProgressPercent}%` }} /></i>
            <b>{overallProgressPercent}%</b>
          </div>
          <button className="header-quiet" onClick={onBack}>{"\u2190"} Back</button>
        </header>

        <main className="assessment-content">
          <Reveal>
            <div className="subject-banner">
              <span className="subject-banner-emoji">{subjectEmoji(currentSubject)}</span>
              <div className="subject-banner-copy">
                <small>SUBJECT</small>
                <b>{currentSubject}</b>
                <small>Question {currentQuestionIndex + 1} of {currentSubjectQuestions.length} {"\u00B7"} {currentGlobalIndex + 1} of {totalQuestions} overall</small>
              </div>
              <div className="subject-banner-progress">
                <div className="subject-progress-track">
                  <div className="subject-progress-fill" style={{ width: `${currentSubjectProgressPercent}%` }} />
                </div>
                <small>{currentSubjectAnswered}/{currentSubjectQuestions.length} answered</small>
              </div>
            </div>
          </Reveal>

          <Reveal>
            <div className="assessment-progress-meta">
              <div className="progress-meta-cell">
                <span>Current Subject</span>
                <b>{subjectEmoji(currentSubject)} {currentSubject}</b>
              </div>
              <div className="progress-meta-cell">
                <span>Subject Progress</span>
                <b>{currentSubject} {currentSubjectAnswered}/{currentSubjectQuestions.length}</b>
              </div>
              <div className="progress-meta-cell">
                <span>Overall Progress</span>
                <b>{answeredCount}/{totalQuestions} {"\u00B7"} {overallProgressPercent}%</b>
              </div>
            </div>
          </Reveal>

          <Reveal>
            <div className="subject-segment-row">
              {subjectOrder.map(s => {
                const sq = subjectQuestions[s] || []
                const answered = sq.filter(isQuestionAnswered).length
                const done = sq.length > 0 && answered === sq.length
                const active = s === currentSubject
                return (
                  <div key={s} className={`subject-segment ${active ? 'active' : ''} ${done ? 'done' : ''}`}>
                    <span className="subject-segment-emoji">{subjectEmoji(s)}</span>
                    <div>
                      <small>{s}</small>
                      <b>{done ? `Completed ${answered}/${sq.length}` : active ? `Question ${currentQuestionIndex + 1} of ${sq.length}` : `Upcoming \u00B7 ${sq.length} questions`}</b>
                    </div>
                    <i><em style={{ width: `${sq.length ? Math.round((answered / sq.length) * 100) : 0}%` }} /></i>
                  </div>
                )
              })}
            </div>
          </Reveal>

          <Reveal>
            <div style={{ display: 'flex', gap: 4, justifyContent: 'center', marginBottom: 28 }}>
              {currentSubjectQuestions.map((sq, i) => {
                const isAnswered = isQuestionAnswered(sq)
                const isCurrent = i === currentQuestionIndex
                return (
                  <button
                    key={sq.questionId}
                    type="button"
                    title={`${currentSubject} question ${i + 1}`}
                    onClick={() => setCurrentQuestionIndex(i)}
                    style={{
                      width: isCurrent ? 16 : 10,
                      height: 10,
                      borderRadius: 5,
                      border: 'none',
                      padding: 0,
                      background: isCurrent ? subjectIcon(currentSubject) : isAnswered ? '#50c1b4' : '#e0e1ed',
                      transition: 'all 0.3s ease',
                      cursor: 'pointer'
                    }}
                  />
                )
              })}
            </div>
          </Reveal>

          <div className="question-card" key={`${currentSubject}-${question.questionId}`}>
            <div className="question-progress">
              <span>{subjectEmoji(currentSubject)} {currentSubject} {"\u00B7"} Question {currentQuestionIndex + 1} of {currentSubjectQuestions.length}</span>
              <span style={{
                padding: '3px 10px',
                borderRadius: 4,
                background: `${getTypeColor(question.type)}15`,
                color: getTypeColor(question.type),
                fontSize: 9,
                fontWeight: 600
              }}>{getTypeBadge(question.type)}</span>
              <span style={{
                padding: '3px 10px',
                borderRadius: 4,
                background: question.difficulty === 'Hard' ? '#fef2f2' : question.difficulty === 'Medium' ? '#fffbeb' : '#f0fdf4',
                color: question.difficulty === 'Hard' ? '#ef4444' : question.difficulty === 'Medium' ? '#f59e0b' : '#22c55e',
                fontSize: 9,
                fontWeight: 600
              }}>{question.difficulty}</span>
            </div>

            <h2 style={{ margin: '32px 0 24px', lineHeight: 1.5 }}>{question.question}</h2>

            {/* MCQ */}
            {isMCQ && (
              <Reveal>
                <div className="answer-grid">
                  {(optionOrder[question.questionId] || question.options || []).map((opt, optIndex) => {
                    const isSelected = answers[question.questionId] === opt
                    return (
                      <button
                        key={`${question.questionId}-${optIndex}`}
                        type="button"
                        className={isSelected ? 'selected' : ''}
                        aria-pressed={isSelected}
                        onClick={() => selectAnswer(opt)}
                        style={{
                          padding: '16px 18px',
                          borderRadius: 10,
                          border: isSelected ? '2px solid #6557d8' : '1px solid #e0e1ed',
                          background: isSelected ? '#f0edff' : '#fafaff',
                          color: isSelected ? '#6557d8' : '#707795',
                          fontSize: 12,
                          fontWeight: isSelected ? 600 : 400,
                          cursor: 'pointer',
                          transition: 'all 0.2s ease',
                          textAlign: 'left'
                        }}
                      >{opt}</button>
                    )
                  })}
                </div>
              </Reveal>
            )}

            {/* Match */}
            {isMatchType && (
              <Reveal>
                <div className="match-grid" style={{ display: 'flex', flexDirection: 'column', gap: 10 }}>
                  {(matchTerms[question.questionId] || []).map(({ term }) => (
                    <div key={term} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0', borderBottom: '1px solid #f0f1f5' }}>
                      <span style={{ color: '#545b7d', fontSize: 11, fontWeight: 500, minWidth: 140 }}>{term}</span>
                      <select
                        className="match-select"
                        value={(matchAnswers[question.questionId] || {})[term] || ''}
                        onChange={(e) => selectMatchAnswer(term, e.target.value)}
                        style={{ flex: 1, padding: '8px 12px', borderRadius: 6, border: '1px solid #e0e1ed', fontSize: 11, background: '#fafaff', color: '#40486c' }}
                      >
                        <option value="">Select...</option>
                        {(optionOrder[question.questionId] || []).map((opt, optIndex) => (
                          <option key={`${opt}-${optIndex}`} value={opt}>{opt}</option>
                        ))}
                      </select>
                    </div>
                  ))}
                </div>
              </Reveal>
            )}

            {/* True/False */}
            {isTF && (
              <Reveal>
                <div className="answer-grid">
                  {['True', 'False'].map((opt) => {
                    const isSelected = answers[question.questionId] === opt
                    return (
                      <button
                        key={opt}
                        type="button"
                        className={isSelected ? 'selected' : ''}
                        aria-pressed={isSelected}
                        onClick={() => selectAnswer(opt)}
                        style={{
                          padding: '18px',
                          borderRadius: 10,
                          border: isSelected ? '2px solid #6557d8' : '1px solid #e0e1ed',
                          background: isSelected ? '#f0edff' : '#fafaff',
                          color: isSelected ? '#6557d8' : '#707795',
                          fontSize: 13,
                          fontWeight: 600,
                          cursor: 'pointer',
                          transition: 'all 0.2s ease'
                        }}
                      >{opt}</button>
                    )
                  })}
                </div>
              </Reveal>
            )}

            {/* Text inputs */}
            {!isMCQ && !isMatchType && !isTF && (
              <Reveal>
                <div>
                  <input
                    type="text"
                    placeholder={question.type === 'fillblank' ? 'Type your answer...' : question.type === 'oneword' ? 'One word answer...' : 'Type your response...'}
                    value={answers[question.questionId] || ''}
                    onChange={(e) => selectAnswer(e.target.value)}
                    style={{
                      width: '100%',
                      padding: '14px 16px',
                      borderRadius: 10,
                      border: '1px solid #e0e1ed',
                      fontSize: 12,
                      fontFamily: 'inherit',
                      background: '#fafaff',
                      color: '#40486c',
                      outline: 'none',
                      transition: 'border-color 0.2s'
                    }}
                    onFocus={(e) => { e.target.style.borderColor = '#8b7ee4'; e.target.style.boxShadow = '0 0 0 3px rgba(139,126,228,0.1)' }}
                    onBlur={(e) => { e.target.style.borderColor = '#e0e1ed'; e.target.style.boxShadow = 'none' }}
                  />
                </div>
              </Reveal>
            )}

            {/* Confidence */}
            <Reveal delay={0.1}>
              <div style={{ marginTop: 28, padding: '16px 18px', borderRadius: 10, background: '#fafaff', border: '1px solid #f0f1f5' }}>
                <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                  <small style={{ color: '#7c829e', fontSize: 11, fontWeight: 600 }}>How confident are you about your answer?</small>
                  <span style={{ fontSize: 16 }}>{"\uD83D\uDCA1"}</span>
                </div>
                <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                  {(['Very Confident', 'Confident', 'Unsure'] as Confidence[]).map((level) => (
                    <button
                      key={level}
                      type="button"
                      onClick={() => selectConfidence(level)}
                      style={{
                        padding: '7px 14px',
                        borderRadius: 6,
                        border: confidenceMap[question.questionId] === level ? '2px solid #6557d8' : '1px solid #e0e1ed',
                        background: confidenceMap[question.questionId] === level ? '#6557d8' : '#ffffff',
                        color: confidenceMap[question.questionId] === level ? '#fff' : '#707795',
                        fontSize: 10,
                        fontWeight: confidenceMap[question.questionId] === level ? 600 : 500,
                        cursor: 'pointer',
                        transition: 'all 0.2s ease'
                      }}
                    >{level}</button>
                  ))}
                </div>
              </div>
            </Reveal>

            {/* Navigation */}
            <Reveal delay={0.15}>
              {nextSubject && (
                <div className="subject-switch-hint">
                  <span className="subject-banner-emoji">{subjectEmoji(nextSubject)}</span>
                  <span>Last question of {currentSubject} {"\u00B7"} next up: <b>{nextSubject}</b></span>
                </div>
              )}
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 28, paddingTop: 20, borderTop: '1px solid #edeef4' }}>
                <button
                  type="button"
                  onClick={goPrev}
                  disabled={isFirstQuestion}
                  style={{
                    padding: '10px 18px',
                    border: '1px solid #d0d2e8',
                    borderRadius: 8,
                    background: '#fafaff',
                    color: isFirstQuestion ? '#d0d2e8' : '#707795',
                    cursor: isFirstQuestion ? 'not-allowed' : 'pointer',
                    fontSize: 11,
                    fontWeight: 500,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6
                  }}
                >{"\u2190"} Previous</button>

                <span className="assessment-progress-pill">
                  {currentSubject} {currentSubjectAnswered}/{currentSubjectQuestions.length} {"\u00B7"} {overallProgressPercent}% overall
                </span>

                <button
                  type="button"
                  onClick={goNext}
                  disabled={!currentQuestionAnswered}
                  style={{
                    padding: '10px 24px',
                    border: 'none',
                    borderRadius: 8,
                    background: currentQuestionAnswered ? 'linear-gradient(100deg,#6255d2,#8073e0 60%,#48c7b8)' : '#d0d2e8',
                    color: '#fff',
                    cursor: currentQuestionAnswered ? 'pointer' : 'not-allowed',
                    fontSize: 11,
                    fontWeight: 600,
                    display: 'flex',
                    alignItems: 'center',
                    gap: 6
                  }}
                >{isLast ? 'Submit Assessment \u2713' : nextSubject ? `Continue to ${nextSubject} \u2192` : 'Next \u2192'}</button>
              </div>
            </Reveal>
          </div>
        </main>
      </motion.div>
    )
  }

  return (
    <motion.div className="assessment-screen" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <header className="walk-header assessment-sticky-header">
        <Logo />
        <button className="header-quiet" onClick={onBack}>{"\u2190"} Back</button>
      </header>
      <main className="assessment-content" style={{ textAlign: 'center' }}>
        <Reveal>
          <div className="question-card">
            <h2 style={{ margin: '0 0 10px' }}>No questions available</h2>
            <p style={{ color: '#8c92ab', fontSize: 12 }}>{student.preferredSubjects.length > 0 ? `${student.preferredSubjects.join(', ')} question banks are not available for this assessment yet.` : 'Please select Mathematics or Science to continue.'}</p>
          </div>
        </Reveal>
      </main>
    </motion.div>
  )
}
// ---- OVERVIEW ----
function AssessmentOverview({ student, onNext }: { student: RegistrationData; onNext: () => void }) {
  const subjects = student.preferredSubjects.filter(s => s === 'Mathematics' || s === 'Science')
  const mathCount = subjects.includes('Mathematics') ? 5 : 0
  const scienceCount = subjects.includes('Science') ? 5 : 0
  const totalQ = mathCount + scienceCount
  const estTime = subjects.includes('Mathematics') && subjects.includes('Science') ? '15' : '10'

  const subjectIcons: Record<string, string> = { Mathematics: '\uD83D\uDED9', Science: '\uD83D\uDD2C' }
  return (
    <motion.div className="assessment-screen" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <header className="walk-header assessment-sticky-header">
        <Logo />
        <div className="assessment-header-progress">
          <span>Baseline Assessment</span>
          <i><em style={{ width: '0%' }} /></i>
          <b>0%</b>
        </div>
        <button className="header-quiet" onClick={() => window.history.back()}>{"\u2190"} Back</button>
      </header>
      <main className="assessment-intro">
        <Reveal>
          <div className="assessment-kicker" style={{ display: 'inline-flex', alignItems: 'center', gap: 8, padding: '6px 14px', borderRadius: 20, background: 'rgba(101,88,213,0.08)', marginBottom: 20 }}>
            <span style={{ width: 8, height: 8, borderRadius: '50%', background: '#6558d7' }} />
            BASELINE ASSESSMENT {"\u00B7"} STEP 01
          </div>
        </Reveal>
        <Reveal delay={0.1}>
          <h1 style={{ marginBottom: 16 }}>Let's understand<br /><span>how you think.</span></h1>
        </Reveal>
        <Reveal delay={0.15}>
          <p style={{ maxWidth: 480, color: '#8c92ab', fontSize: 13, lineHeight: 1.7, marginBottom: 36 }}>This assessment creates your first Learning DNA profile. Your results help identify strengths, gaps, and personalized learning paths.</p>
        </Reveal>

        <Reveal delay={0.2}>
          <div className="student-info-card">
            <div className="student-info-head">
              <div className="student-avatar">{student.studentName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}</div>
              <div>
                <small>LEARNER PROFILE</small>
                <h2>{student.studentName}</h2>
              </div>
              <span className="baseline-pill">BASELINE</span>
            </div>
            <div className="student-info-grid">
              <div className="info-cell"><span>Class</span><b>{student.class}</b></div>
              <div className="info-cell"><span>Selected subjects</span><b>{subjects.join(' \u00B7 ')}</b></div>
              <div className="info-cell"><span>Assessment type</span><b>Baseline Assessment</b></div>
              <div className="info-cell"><span>Estimated time</span><b>{estTime} minutes</b></div>
              <div className="info-cell"><span>Total questions</span><b>{totalQ}</b></div>
              <div className="info-cell"><span>Progress</span><b>0%</b></div>
            </div>
          </div>
        </Reveal>

        <Reveal delay={0.3}>
          <div style={{ display: 'flex', gap: 14, marginTop: 24, alignItems: 'center', justifyContent: 'center', flexWrap: 'wrap' }}>
            {subjects.map(s => (
              <div key={s} style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 20px', borderRadius: 12, border: '1px solid #e0e1ed', background: '#fafaff' }}>
                <span style={{ fontSize: 22 }}>{subjectIcons[s]}</span>
                <div>
                  <div style={{ color: '#7c829e', fontSize: 9, fontWeight: 600, letterSpacing: 0.5 }}>{s.toUpperCase()}</div>
                  <div style={{ color: '#545b80', fontSize: 11, fontWeight: 600 }}>{subjects.length > 1 ? '5 questions' : '5 questions'}</div>
                </div>
              </div>
            ))}
            <div style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '12px 20px', borderRadius: 12, border: '1px solid #e0e1ed', background: '#fafaff' }}>
              <span style={{ fontSize: 22 }}>{"\u23F1\uFE0F"}</span>
              <div>
                <div style={{ color: '#7c829e', fontSize: 9, fontWeight: 600, letterSpacing: 0.5 }}>ESTIMATED TIME</div>
                <div style={{ color: '#545b80', fontSize: 11, fontWeight: 600 }}>{estTime} minutes</div>
              </div>
            </div>
          </div>
        </Reveal>

        <Reveal delay={0.35}>
          <div style={{ textAlign: 'center', marginTop: 36 }}>
            <button className="primary-button start-assessment" onClick={onNext} style={{ padding: '16px 40px', fontSize: 12 }}>
              Start Assessment <span>{"\u2197"}</span>
            </button>
            <p style={{ color: '#9ca2b5', fontSize: 10, marginTop: 12 }}>Your responses are confidential and used only to build your learning profile</p>
          </div>
        </Reveal>
      </main>
    </motion.div>
  )
}

// ---- QUESTIONS ----
function AssessmentQuestions({ student, onComplete }: { student: RegistrationData; onComplete: (result: AssessmentResult) => void }) {
  const subjects = useMemo(() => student.preferredSubjects.filter(s => s === 'Mathematics' || s === 'Science'), [student.preferredSubjects])
  const allQuestions = useMemo(() => {
    const pool: AssessmentQuestion[] = []
    if (subjects.includes('Mathematics')) {
      const mathChapters = subjectsData.Mathematics.chapters
      const mathShuffled = shuffleArray(mathChapters.flatMap(c => c.questions))
      pool.push(...mathShuffled.slice(0, 5))
    }
    if (subjects.includes('Science')) {
      const scienceChapters = subjectsData.Science.chapters
      const scienceShuffled = shuffleArray(scienceChapters.flatMap(c => c.questions))
      pool.push(...scienceShuffled.slice(0, 5))
    }
    return shuffleArray(pool)
  }, [subjects])
  const totalQ = allQuestions.length
  const [current, setCurrent] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [confidence, setConfidence] = useState<Record<number, Confidence>>({})
  const [textAnswers, setTextAnswers] = useState<Record<number, string>>({})
  const [matchAnswers, setMatchAnswers] = useState<Record<number, Record<string, string>>>({})
  const [showExplanation, setShowExplanation] = useState(false)


  const question = allQuestions[current]
  const answered = Object.keys(answers).length
  const progress = Math.round((answered / totalQ) * 100)
  const lastQuestion = current === totalQ - 1

  const isTextInput = (q: AssessmentQuestion) => ['truefalse', 'fillblank', 'oneword', 'reasoning', 'criticalthinking', 'problemsolving', 'viva'].includes(q.type)
  const isMatch = (q: AssessmentQuestion) => q.type === 'match'
  const isMCQ = (q: AssessmentQuestion) => q.type === 'mcq'

  // Fixed once per session so re-renders never reshuffle an already-answered question.
  const optionOrder = useMemo(() => {
    const map: Record<number, string[]> = {}
    allQuestions.forEach(q => {
      if (q.type === 'match') {
        map[q.questionId] = shuffleArray([...new Set(q.correctAnswer.split('|').map(p => p.split('-').slice(1).join('-').trim()))])
      } else {
        map[q.questionId] = shuffleArray(q.options || [])
      }
    })
    return map
  }, [allQuestions])

  const matchPairs = useMemo(() => {
    const map: Record<number, { term: string; correct: string }[]> = {}
    allQuestions.forEach(q => {
      if (q.type !== 'match') return
      map[q.questionId] = q.correctAnswer.split('|').map(pair => {
        const idx = pair.indexOf('-')
        return { term: pair.slice(0, idx), correct: pair.slice(idx + 1) }
      })
    })
    return map
  }, [allQuestions])

  const answerFor = useCallback((q: AssessmentQuestion): string => {
    if (q.type === 'match') {
      const pairs = matchPairs[q.questionId] || []
      const picks = matchAnswers[q.questionId] || {}
      if (pairs.length === 0 || !pairs.every(p => picks[p.term])) return ''
      return pairs.map(p => `${p.term}-${picks[p.term]}`).join('|')
    }
    return answers[q.questionId] || textAnswers[q.questionId] || ''
  }, [matchPairs, matchAnswers, answers, textAnswers])

  const selectAnswer = (answer: string) => setAnswers(prev => ({ ...prev, [question.questionId]: answer }))
  const selectConfidence = (level: Confidence) => setConfidence(prev => ({ ...prev, [question.questionId]: level }))
  const handleTextAnswer = (val: string) => setTextAnswers(prev => ({ ...prev, [question.questionId]: val }))
  const handleMatchAnswer = (pair: string, val: string) => setMatchAnswers(prev => ({ ...prev, [question.questionId]: { ...(prev[question.questionId] || {}), [pair]: val } }))

  const handleNext = () => {
    if (!answerFor(question)) return
    if (!lastQuestion) setCurrent(prev => prev + 1)
    else {
      let correctCount = 0
      const questionResults = allQuestions.map(q => {
        const userAnswer = answerFor(q)
        const isCorrect = checkAnswer(q, userAnswer)
        if (isCorrect) correctCount++
        return { questionId: q.questionId, isCorrect, concept: q.concept, questionType: q.type, userAnswer, correctAnswer: q.correctAnswer }
      })
      onComplete({ studentId: student.id || 'DNA10001', studentName: student.studentName, className: student.class, subjects, score: Math.round((correctCount / totalQ) * 100), totalQuestions: totalQ, answeredCorrectly: correctCount, questionResults })
    }
  }

  const handlePrev = () => { if (current > 0) setCurrent(prev => prev - 1) }

  const renderAnswerUI = () => {
    if (isMCQ(question)) {
      return <div className="answer-grid">{(optionOrder[question.questionId] || question.options || []).map((opt, i) => <button key={`${opt}-${i}`} type="button" className={answers[question.questionId] === opt ? 'selected' : ''} onClick={() => selectAnswer(opt)}>{opt}</button>)}</div>
    }
    if (isMatch(question)) {
      const pairs = matchPairs[question.questionId] || []
      const shuffledOptions = optionOrder[question.questionId] || []
      return (
        <div className="match-grid">
          {pairs.map((pair) => (
            <div key={pair.term} className="match-pair">
              <span className="match-term">{pair.term}</span>
              <select className="match-select" value={matchAnswers[question.questionId]?.[pair.term] || ''} onChange={(e) => handleMatchAnswer(pair.term, e.target.value)}>
                <option value="">Select...</option>
                {shuffledOptions.map((opt, i) => <option key={`${opt}-${i}`} value={opt}>{opt}</option>)}
              </select>
            </div>
          ))}
        </div>
      )
    }
    if (question.type === 'truefalse') {
      return <div className="answer-grid">{['True', 'False'].map((opt) => <button key={opt} type="button" className={answers[question.questionId] === opt ? 'selected' : ''} onClick={() => selectAnswer(opt)}>{opt}</button>)}</div>
    }
    return <input type="text" className="text-answer" placeholder="Type your answer..." value={textAnswers[question.questionId] || ''} onChange={(e) => handleTextAnswer(e.target.value)} />
  }

  return (
    <motion.div className="assessment-screen" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }}>
      <header className="walk-header assessment-sticky-header">
        <Logo />
        <div className="assessment-header-progress">
          <span>Question {current + 1} of {totalQ}</span>
          <i style={{ width: `${progress}%` }} />
          <b>{progress}%</b>
        </div>
        <button className="header-quiet" onClick={() => window.history.back()}>{"\u2190"} Back</button>
      </header>
      <main className="assessment-content">
        {/* Progress dots with context */}
        <Reveal>
          <div style={{ textAlign: 'center', marginBottom: 16 }}>
            <span style={{ color: '#8c92ab', fontSize: 11 }}>{current + 1} / {totalQ}</span>
          </div>
          <div className="question-dots" style={{ display: 'flex', gap: 4, justifyContent: 'center', marginBottom: 28 }}>
            {allQuestions.map((_, i) => (
              <button
                key={i}
                type="button"
                onClick={() => setCurrent(i)}
                style={{
                  width: i === current ? 14 : 10,
                  height: 10,
                  borderRadius: 5,
                  border: 'none',
                  background: i === current ? '#6557d8' : i < current ? '#50c1b4' : '#e0e1ed',
                  transition: 'all 0.3s ease',
                  cursor: 'pointer'
                }}
              />
            ))}
          </div>
        </Reveal>

        <div className="question-card" key={current}>
          {/* Question header */}
          <div className="question-progress">
            <span>Question {current + 1} / {totalQ}</span>
            <span style={{
              padding: '3px 10px',
              borderRadius: 4,
              background: `${getTypeColor(question.type)}15`,
              color: getTypeColor(question.type),
              fontSize: 9,
              fontWeight: 600
            }}>{getTypeBadge(question.type)}</span>
            <span style={{
              padding: '3px 10px',
              borderRadius: 4,
              background: question.difficulty === 'Hard' ? '#fef2f2' : question.difficulty === 'Medium' ? '#fffbeb' : '#f0fdf4',
              color: question.difficulty === 'Hard' ? '#ef4444' : question.difficulty === 'Medium' ? '#f59e0b' : '#22c55e',
              fontSize: 9,
              fontWeight: 600
            }}>{question.difficulty}</span>
          </div>
          <h2 dangerouslySetInnerHTML={{ __html: question.question.replace(/\n/g, '<br/>') }} style={{ margin: '32px 0 24px', lineHeight: 1.5 }} />

          {/* Answer UI */}
          {isMCQ(question) && (
            <Reveal>
              <div className="answer-grid">
                {(optionOrder[question.questionId] || question.options || []).map((opt, optIndex) => {
                  const isSelected = answers[question.questionId] === opt
                  return (
                    <button
                      key={`${question.questionId}-${optIndex}`}
                      type="button"
                      className={isSelected ? 'selected' : ''}
                      aria-pressed={isSelected}
                      onClick={() => selectAnswer(opt)}
                      style={{
                        padding: '16px 18px',
                        borderRadius: 10,
                        border: isSelected ? '2px solid #6557d8' : '1px solid #e0e1ed',
                        background: isSelected ? '#f0edff' : '#fafaff',
                        color: isSelected ? '#6557d8' : '#707795',
                        fontSize: 12,
                        fontWeight: isSelected ? 600 : 400,
                        cursor: 'pointer',
                        transition: 'all 0.2s ease',
                        textAlign: 'left'
                      }}
                    >{opt}</button>
                  )
                })}
              </div>
            </Reveal>
          )}

          {isMatch(question) && (
            <Reveal>
              <div className="match-grid">
                {(matchPairs[question.questionId] || []).map(({ term }) => (
                    <div key={term} className="match-pair" style={{ display: 'flex', alignItems: 'center', gap: 10, padding: '10px 0', borderBottom: '1px solid #f0f1f5' }}>
                      <span style={{ color: '#545b7d', fontSize: 11, fontWeight: 500, minWidth: 140 }}>{term}</span>
                      <select
                        className="match-select"
                        value={matchAnswers[question.questionId]?.[term] || ''}
                        onChange={(e) => handleMatchAnswer(term, e.target.value)}
                        style={{ flex: 1, padding: '8px 12px', borderRadius: 6, border: '1px solid #e0e1ed', fontSize: 11, background: '#fafaff', color: '#40486c' }}
                      >
                        <option value="">Select...</option>
                        {(optionOrder[question.questionId] || []).map((opt, optIndex) => (
                          <option key={`${opt}-${optIndex}`} value={opt}>{opt}</option>
                        ))}
                      </select>
                    </div>
                  ))}
              </div>
            </Reveal>
          )}

          {question.type === 'truefalse' && (
            <Reveal>
              <div className="answer-grid">
                {['True', 'False'].map((opt) => (
                  <button
                    key={opt}
                    type="button"
                    className={answers[question.questionId] === opt ? 'selected' : ''}
                    onClick={() => selectAnswer(opt)}
                    style={{
                      padding: '18px',
                      borderRadius: 10,
                      border: answers[question.questionId] === opt ? '2px solid #6557d8' : '1px solid #e0e1ed',
                      background: answers[question.questionId] === opt ? '#f0edff' : '#fafaff',
                      color: answers[question.questionId] === opt ? '#6557d8' : '#707795',
                      fontSize: 13,
                      fontWeight: 600,
                      cursor: 'pointer',
                      transition: 'all 0.2s ease'
                    }}
                  >{opt}</button>
                ))}
              </div>
            </Reveal>
          )}

          {(question.type === 'fillblank' || question.type === 'oneword' || question.type === 'reasoning' || question.type === 'criticalthinking' || question.type === 'problemsolving' || question.type === 'viva') && (
            <Reveal>
              <div style={{ position: 'relative' }}>
                <textarea
                  className="text-answer"
                  placeholder={question.type === 'fillblank' ? 'Type your answer...' : question.type === 'oneword' ? 'One word answer...' : 'Type your response...'}
                  value={textAnswers[question.questionId] || ''}
                  onChange={(e) => handleTextAnswer(e.target.value)}
                  rows={question.type === 'reasoning' || question.type === 'criticalthinking' || question.type === 'problemsolving' ? 4 : 2}
                  style={{
                    width: '100%',
                    padding: '14px 16px',
                    borderRadius: 10,
                    border: '1px solid #e0e1ed',
                    fontSize: 12,
                    fontFamily: 'inherit',
                    background: '#fafaff',
                    color: '#40486c',
                    resize: 'vertical',
                    outline: 'none',
                    transition: 'border-color 0.2s'
                  }}
                  onFocus={(e) => { e.target.style.borderColor = '#8b7ee4'; e.target.style.boxShadow = '0 0 0 3px rgba(139,126,228,0.1)' }}
                  onBlur={(e) => { e.target.style.borderColor = '#e0e1ed'; e.target.style.boxShadow = 'none' }}
                />
                <div style={{ textAlign: 'right', marginTop: 6 }}>
                  <span style={{ color: '#9ca2b5', fontSize: 10 }}>{(textAnswers[question.questionId] || '').length} characters</span>
                </div>
              </div>
            </Reveal>
          )}

          {/* Confidence section */}
          <Reveal delay={0.1}>
            <div className="confidence-block" style={{ marginTop: 28, padding: '16px 18px', borderRadius: 10, background: '#fafaff', border: '1px solid #f0f1f5' }}>
              <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 12 }}>
                <small style={{ color: '#7c829e', fontSize: 11, fontWeight: 600 }}>How confident are you?</small>
                <span style={{ fontSize: 16 }}>{"\uD83D\uDCA1"}</span>
              </div>
              <div style={{ display: 'flex', gap: 6, flexWrap: 'wrap' }}>
                {(['Very Confident', 'Confident', 'Unsure', 'Guessing'] as Confidence[]).map((level) => (
                  <button
                    key={level}
                    type="button"
                    onClick={() => selectConfidence(level)}
                    style={{
                      padding: '7px 14px',
                      borderRadius: 6,
                      border: confidence[question.questionId] === level ? `2px solid #6557d8` : '1px solid #e0e1ed',
                      background: confidence[question.questionId] === level ? '#6557d8' : '#ffffff',
                      color: confidence[question.questionId] === level ? '#fff' : '#707795',
                      fontSize: 10,
                      fontWeight: confidence[question.questionId] === level ? 600 : 500,
                      cursor: 'pointer',
                      transition: 'all 0.2s ease'
                    }}
                  >{level}</button>
                ))}
              </div>
            </div>
          </Reveal>

          {/* Navigation */}
          <Reveal delay={0.15}>
            <div className="question-footer" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: 28, paddingTop: 20, borderTop: '1px solid #edeef4' }}>
              <button
                type="button"
                onClick={handlePrev}
                disabled={current === 0}
                style={{
                  padding: '10px 18px',
                  border: '1px solid #d0d2e8',
                  borderRadius: 8,
                  background: '#fafaff',
                  color: current === 0 ? '#d0d2e8' : '#707795',
                  cursor: current === 0 ? 'not-allowed' : 'pointer',
                  fontSize: 11,
                  fontWeight: 500,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6
                }}
              >{"\u2190"} Previous</button>

              <span style={{
                padding: '6px 14px',
                borderRadius: 20,
                background: '#f0edff',
                color: '#6557d8',
                fontSize: 11,
                fontWeight: 600
              }}>{Math.round(((current + 1) / totalQ) * 100)}% complete</span>

              <button
                type="button"
                onClick={handleNext}
                style={{
                  padding: '10px 24px',
                  border: 'none',
                  borderRadius: 8,
                  background: 'linear-gradient(100deg,#6255d2,#8073e0 60%,#48c7b8)',
                  color: '#fff',
                  cursor: 'pointer',
                  fontSize: 11,
                  fontWeight: 600,
                  display: 'flex',
                  alignItems: 'center',
                  gap: 6
                }}
              >{lastQuestion ? 'Finish \u2713' : 'Next \u2192'}</button>
            </div>
          </Reveal>
        </div>
      </main>
    </motion.div>
  )
}

// ---- DNA EVOLUTION BADGE ----
function EvolutionBadge({ entries }: { entries: EvolutionEntry[] }) {
  if (entries.length < 2) return null
  const latest = entries[entries.length - 1]
  const prev = entries[entries.length - 2]
  const diff = latest.score - prev.score
  const isPositive = diff > 0
  return (
    <div className="dna-evolution-badge" style={{ display: 'inline-flex', alignItems: 'center', gap: 4 }}>
      {"\uD83D\uDCC8"} {isPositive ? '+' : ''}{diff} from v{prev.version}
    </div>
  )
}

// ---- CHAPTER ASSESSMENT RUNNER ----
// A chapter attempt keeps its per-question results so the Assessment tab can show
// a full review for that chapter, exactly like the baseline review.
interface ChapterQuestionResult {
  questionId: number
  isCorrect: boolean
  concept: string
  questionType: string
  userAnswer: string
  correctAnswer: string
  difficulty: string
}

function ChapterAssessmentRunner({ subject, chapterName, kind, onComplete, onExit }: {
  subject: string
  chapterName: string
  kind: 'assessment' | 'retest'
  onComplete: (result: { score: number; correct: number; total: number; reasoning: number; problemSolving: number; criticalThinking: number; questionResults: ChapterQuestionResult[] }) => void
  onExit: () => void
}) {
  const [questions] = useState<AssessmentQuestion[]>(() => {
    const pool = subjectsData[subject]?.chapters.find(c => c.name === chapterName)?.questions || []
    return shuffleArray(pool)
  })
  // Option order is fixed once per run. Shuffling during render would reshuffle
  // on every answer click and make the selection appear to jump.
  const [optionOrder] = useState<Record<number, string[]>>(() => {
    const map: Record<number, string[]> = {}
    for (const q of questions) {
      if (q.type === 'match') {
        const values = q.correctAnswer.split('|').map(pair => {
          const i = pair.indexOf('-')
          return pair.slice(i + 1)
        })
        map[q.questionId] = shuffleArray([...new Set(values)])
      } else {
        map[q.questionId] = shuffleArray(q.options || [])
      }
    }
    return map
  })
  const [index, setIndex] = useState(0)
  const [answers, setAnswers] = useState<Record<number, string>>({})
  const [matchAnswers, setMatchAnswers] = useState<Record<number, Record<string, string>>>({})
  const [finished, setFinished] = useState(false)

  const question = questions[index]
  const answeredCount = questions.filter(q => Boolean(answers[q.questionId])).length
  const isLast = index === questions.length - 1

  const currentAnswer = question ? (answers[question.questionId] || '') : ''
  const canAdvance = currentAnswer.trim().length > 0

  const handleNext = () => {
    if (!question) return
    if (!isLast) { setIndex(i => i + 1); return }

    const questionResults: ChapterQuestionResult[] = questions.map(q => ({
      questionId: q.questionId,
      isCorrect: checkAnswer(q, answers[q.questionId] || ''),
      concept: q.concept,
      questionType: q.type,
      userAnswer: answers[q.questionId] || '',
      correctAnswer: q.correctAnswer,
      difficulty: q.difficulty,
    }))

    const correct = questionResults.filter(r => r.isCorrect).length
    const total = questions.length
    const score = total > 0 ? Math.round((correct / total) * 100) : 0

    const rate = (types: string[]) => {
      const matching = questions.filter(q => types.includes(q.type))
      if (matching.length === 0) return -1
      return Math.round(matching.filter(q => checkAnswer(q, answers[q.questionId] || '')).length / matching.length * 100)
    }
    // Mirror the baseline derivation: fall back to the chapter score when the pool
    // contains no question of that type, rather than reporting a bare zero.
    const fallback = (value: number) => value >= 0 ? value : score
    const reasoning = fallback(rate(['reasoning', 'viva']))
    const problemSolving = fallback(rate(['problemsolving']))
    const criticalThinking = fallback(rate(['criticalthinking']))

    setFinished(true)
    onComplete({ score, correct, total, reasoning, problemSolving, criticalThinking, questionResults })
  }

  if (questions.length === 0) {
    return (
      <div className="explorer-empty">
        <h3>No questions for {chapterName}</h3>
        <p>This chapter has no questions in the bank yet.</p>
        <button className="primary-button" type="button" onClick={onExit}><span>{'\u2190'}</span> Back</button>
      </div>
    )
  }

  if (finished) {
    return (
      <div className="runner-done">
        <h2>{kind === 'retest' ? 'Retest' : 'Assessment'} complete</h2>
        <p>Your {subject} · {chapterName} DNA has been updated.</p>
        <button className="primary-button" type="button" onClick={onExit}><span>{'\u2192'}</span> Back to tracking</button>
      </div>
    )
  }

  const matchPairs = question?.type === 'match'
    ? (question.correctAnswer.split('|') || []).map(pair => {
        const i = pair.indexOf('-')
        return { term: pair.slice(0, i), correct: pair.slice(i + 1) }
      })
    : []
  const matchOptions = question ? (optionOrder[question.questionId] || []) : []

  return (
    <div className="chapter-runner">
      <header className="walk-header">
        <Logo />
        <span className="chapter-learning-crumb">
          {kind === 'retest' ? 'Retest' : 'Assessment'} · {subjectEmoji(subject)} {chapterName}
        </span>
        <button className="header-quiet" onClick={onExit}>{'\u2190'} Exit</button>
      </header>

      <div className="runner-progress">
        <div className="runner-progress-bar"><div style={{ width: `${(answeredCount / questions.length) * 100}%` }} /></div>
        <span>{answeredCount}/{questions.length} answered</span>
      </div>

      <main className="runner-stage">
        <div className="runner-card">
          <div className="runner-card-head">
            <span>Question {index + 1} of {questions.length}</span>
            <span className="runner-difficulty">{question?.difficulty}</span>
          </div>
          <h2>{question?.question}</h2>

          {question?.type === 'match' ? (
            <div className="match-grid">
              {matchPairs.map(({ term }) => (
                <div key={term} className="match-pair">
                  <span className="match-term">{term}</span>
                  <select
                    className="match-select"
                    value={(matchAnswers[question.questionId] || {})[term] || ''}
                    onChange={(e) => {
                      const picks = { ...(matchAnswers[question.questionId] || {}), [term]: e.target.value }
                      setMatchAnswers(prev => ({ ...prev, [question.questionId]: picks }))
                      setAnswers(prev => ({
                        ...prev,
                        [question.questionId]: matchPairs.every(p => picks[p.term])
                          ? matchPairs.map(p => `${p.term}-${picks[p.term]}`).join('|')
                          : ''
                      }))
                    }}
                  >
                    <option value="">Select...</option>
                    {matchOptions.map((opt, oi) => <option key={`${opt}-${oi}`} value={opt}>{opt}</option>)}
                  </select>
                </div>
              ))}
            </div>
          ) : question?.options ? (
            <div className="answer-grid">
              {(optionOrder[question.questionId] || question.options || []).map((opt, oi) => (
                <button
                  key={`${opt}-${oi}`}
                  type="button"
                  className={currentAnswer === opt ? 'selected' : ''}
                  aria-pressed={currentAnswer === opt}
                  onClick={() => setAnswers(prev => ({ ...prev, [question.questionId]: opt }))}
                >{opt}</button>
              ))}
            </div>
          ) : question?.type === 'truefalse' ? (
            <div className="answer-grid">
              {['True', 'False'].map(opt => (
                <button
                  key={opt}
                  type="button"
                  className={currentAnswer === opt ? 'selected' : ''}
                  aria-pressed={currentAnswer === opt}
                  onClick={() => setAnswers(prev => ({ ...prev, [question.questionId]: opt }))}
                >{opt}</button>
              ))}
            </div>
          ) : (
            <input
              className="text-answer"
              type="text"
              placeholder="Type your answer..."
              value={currentAnswer}
              onChange={(e) => setAnswers(prev => ({ ...prev, [question.questionId]: e.target.value }))}
            />
          )}

          <div className="runner-actions">
            <button type="button" disabled={index === 0} onClick={() => setIndex(i => Math.max(0, i - 1))}>{'\u2190'} Previous</button>
            <button
              type="button"
              className="is-primary"
              disabled={!canAdvance}
              onClick={handleNext}
            >{isLast ? 'Submit' : 'Next'} {'\u2192'}</button>
          </div>
        </div>
      </main>
    </div>
  )
}

// ---- DNA EVOLUTION ----
function DNAEvolution({ entries, baselineScore }: { entries: EvolutionEntry[]; baselineScore: number | null }) {
  const nodes: { label: string; sub: string; score: number | null; kind: string }[] = []

  if (baselineScore != null) {
    nodes.push({ label: 'Baseline DNA', sub: 'Initial assessment', score: baselineScore, kind: 'baseline' })
  }
  entries.forEach((entry, i) => {
    nodes.push({ label: entry.type, sub: new Date(entry.date).toLocaleDateString(), score: entry.score, kind: `v${entry.version + i}` })
  })

  if (nodes.length === 0) {
    return (
      <div className="explorer-empty small">
        <h3>No DNA history yet</h3>
        <p>Complete a chapter assessment to start your DNA evolution timeline.</p>
      </div>
    )
  }

  const scored = nodes.filter(n => n.score != null)
  const first = scored[0]?.score ?? 0
  const last = scored[scored.length - 1]?.score ?? 0
  const delta = last - first
  const masteryDelta = Math.round(last * 0.7) - Math.round(first * 0.7)
  const riskRank = { High: 3, Medium: 2, Low: 1 }
  const riskNow = getRiskBadge(last)
  const riskBefore = getRiskBadge(first)
  const riskReduction = riskRank[riskBefore] - riskRank[riskNow]

  return (
    <div className="evolution-panel">
      <div className="evolution-track">
        {nodes.map((node, i) => (
          <div key={i} className="evolution-step">
            <div className={`evolution-node kind-${node.kind}`}>
              <span className="evolution-node-label">{node.label}</span>
              <b>{node.score != null ? `${node.score}%` : '—'}</b>
              <small>{node.sub}</small>
            </div>
            {i < nodes.length - 1 && <span className="evolution-arrow">{'\u2193'}</span>}
          </div>
        ))}
      </div>

      <div className="evolution-deltas">
        <div>
          <span>Previous Score</span>
          <b>{first}%</b>
        </div>
        <div>
          <span>Current Score</span>
          <b>{last}%</b>
        </div>
        <div>
          <span>Improvement</span>
          <b className={delta >= 0 ? 'is-up' : 'is-down'}>{delta >= 0 ? '+' : ''}{delta}%</b>
        </div>
        <div>
          <span>Mastery Growth</span>
          <b className={masteryDelta >= 0 ? 'is-up' : 'is-down'}>{masteryDelta >= 0 ? '+' : ''}{masteryDelta}%</b>
        </div>
        <div>
          <span>Risk Reduction</span>
          <b className={riskReduction > 0 ? 'is-up' : riskReduction < 0 ? 'is-down' : ''}>
            {riskReduction > 0 ? `${riskBefore} \u2192 ${riskNow}` : riskNow}
          </b>
        </div>
      </div>
    </div>
  )
}

// ---- SUCCESS CRITERIA ----
const JOURNEY_STEPS = [
  { key: 'assessment', label: 'Assessment' },
  { key: 'dna', label: 'Initial DNA' },
  { key: 'learning', label: 'Learning' },
  { key: 'companion', label: 'AI Guidance' },
  { key: 'chapter-dna', label: 'Chapter DNA' },
  { key: 'subject-dna', label: 'Subject DNA' },
  { key: 'overall-dna', label: 'Overall DNA' },
  { key: 'evolution', label: 'DNA Evolution' }
]

function SuccessCriteriaJourney({ completed }: { completed: Set<string> }) {
  return (
    <div className="journey-strip">
      {JOURNEY_STEPS.map((step, i) => {
        const done = completed.has(step.key)
        const isLast = i === JOURNEY_STEPS.length - 1
        return (
          <Fragment key={step.key}>
            <div className={`journey-step ${done ? 'is-done' : ''}`}>
              <span className="journey-step-dot">{done ? '\u2713' : i + 1}</span>
              <b>{step.label}</b>
            </div>
            {!isLast && <span className="journey-connector">{'\u2192'}</span>}
          </Fragment>
        )
      })}
    </div>
  )
}

// ---- LEARNER HEADER ----
function LearnerHeader({ student, assessmentResult }: { student: RegistrationData; assessmentResult: AssessmentResult | null }) {
  const subjects = student.preferredSubjects.filter(s => s === 'Mathematics' || s === 'Science')
  const initials = student.studentName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()

  return (
    <section className="learner-header">
      <div className="learner-header-art" aria-hidden="true">
        <span className="art-orbit art-orbit-one" />
        <span className="art-orbit art-orbit-two" />
        <span className="art-glyph art-glyph-book">{'\uD83D\uDCD6'}</span>
        <span className="art-glyph art-glyph-flask">{'\uD83E\uDDEA'}</span>
        <span className="art-glyph art-glyph-pencil">{'\u270D\uFE0F'}</span>
        <span className="art-glyph art-glyph-star">{'\u2B50'}</span>
        <DNAHelix small />
      </div>

      <div className="learner-header-content">
        <small className="learner-header-kicker">LEARNER DASHBOARD</small>
        <div className="learner-header-identity">
          <div className="learner-header-avatar">{initials}</div>
          <div>
            <h1>{student.studentName}</h1>
            <p>{student.schoolName || 'School not recorded'}</p>
          </div>
        </div>

        <dl className="learner-header-facts">
          <div>
            <dt>Class</dt>
            <dd>{student.class}</dd>
          </div>
          <div>
            <dt>Subjects</dt>
            <dd>{subjects.length > 0 ? subjects.join(' · ') : student.preferredSubjects.join(' · ') || 'Not selected'}</dd>
          </div>
          <div>
            <dt>DNA Score</dt>
            <dd>{assessmentResult ? `${assessmentResult.score}%` : '—'}</dd>
          </div>
        </dl>

        <div className="learner-header-subjects">
          {subjects.map(s => (
            <span key={s} className="learner-subject-chip">
              <span>{subjectEmoji(s)}</span>{s}
            </span>
          ))}
        </div>
      </div>
    </section>
  )
}

// ---- BASELINE ASSESSMENT REVIEW ----
// Every question in the pool, keyed by id, so a result can be joined back to the
// question that produced it. Built once because it never changes.
const QUESTION_INDEX: Record<number, { question: AssessmentQuestion; subject: string }> = (() => {
  const index: Record<number, { question: AssessmentQuestion; subject: string }> = {}
  Object.entries(subjectsData).forEach(([subject, data]) => {
    data.chapters.forEach(chapter => {
      chapter.questions.forEach(question => { index[question.questionId] = { question, subject } })
    })
  })
  return index
})()

const buildBaselineReviews = (result: AssessmentResult): QuestionReview[] => {
  // Shared across the questions so a misconception repeated in the baseline is
  // reported with the confidence it deserves.
  const frequencySeed = new Map<string, number>()
  return result.questionResults
    .map(entry => {
      const found = QUESTION_INDEX[entry.questionId]
      if (!found) return null
      return buildQuestionReview(found.question, entry, entry.subject || found.subject, frequencySeed)
    })
    .filter((review): review is QuestionReview => Boolean(review))
}

// Question-level insight for a completed baseline: what was asked, what was
// answered, the full working, and for a wrong answer the misconception behind it
// with the remediation to launch next.
function AssessmentReviewPanel({ result, onClose, onStartLearning }: {
  result: AssessmentResult
  onClose: () => void
  onStartLearning: (subject: string, chapter: string) => void
}) {
  const reviews = useMemo(
    () => buildBaselineReviews(result),
    [result]
  )

  return (
    <ReviewPanel
      title={`${result.studentName}'s Baseline`}
      subtitle={`${result.answeredCorrectly} of ${result.totalQuestions} correct \u00b7 Score ${result.score}%`}
      reviews={reviews}
      onClose={onClose}
      onStartLearning={onStartLearning}
    />
  )
}

// ---- CHAPTER ASSESSMENT REVIEW ----
// The chapter twin of the baseline review. It reads the per-question results of
// that chapter's latest attempt rather than the baseline, and says so when the
// attempt predates question-level recording.
function ChapterReviewPanel({ subject, chapterName, attempt, questionResults, onClose, onStartLearning }: {
  subject: string
  chapterName: string
  attempt: ChapterAttempt | null
  questionResults: ChapterQuestionResult[]
  onClose: () => void
  onStartLearning: (subject: string, chapter: string) => void
}) {
  const reviews = useMemo(() => {
    const pool = subjectsData[subject]?.chapters.find(c => c.name === chapterName)?.questions || []
    const index = new Map(pool.map(question => [question.questionId, question]))
    const frequencySeed = new Map<string, number>()
    return questionResults
      .map(result => {
        const question = index.get(result.questionId)
        if (!question) return null
        return buildQuestionReview(question, result, subject, frequencySeed)
      })
      .filter((review): review is QuestionReview => Boolean(review))
  }, [subject, chapterName, questionResults])

  return (
    <ReviewPanel
      title={`${chapterName} Assessment`}
      subtitle={attempt
        ? `${attempt.correct}/${attempt.total} correct \u00b7 Score ${attempt.score}% \u00b7 ${subjectEmoji(subject)} ${subject}`
        : `${subjectEmoji(subject)} ${subject}`}
      reviews={reviews}
      emptyMessage="This attempt was recorded before question-level answers were saved. Take the chapter assessment again to see a full review."
      onClose={onClose}
      onStartLearning={onStartLearning}
    />
  )
}

// Shared question-level review surface, used by both the baseline and chapter reviews.
function ReviewPanel({ title, subtitle, reviews, emptyMessage, onClose, onStartLearning }: {
  title: string
  subtitle: string
  reviews: QuestionReview[]
  emptyMessage?: string
  onClose: () => void
  onStartLearning: (subject: string, chapter: string) => void
}) {
  const [showCorrect, setShowCorrect] = useState(false)

  const incorrect = reviews.filter(review => !review.isCorrect)
  const visible = showCorrect ? reviews : incorrect

  const misconceptionTally = useMemo(() => {
    const tally = new Map<string, { count: number; confidence: number }>()
    incorrect.forEach(review => {
      const label = review.misconception?.label
      if (!label) return
      const entry = tally.get(label)
      tally.set(label, {
        count: (entry?.count || 0) + 1,
        confidence: Math.max(entry?.confidence || 0, review.misconception?.confidence || 0),
      })
    })
    return [...tally.entries()].sort((a, b) => b[1].count - a[1].count || b[1].confidence - a[1].confidence)
  }, [incorrect])

  const averageConfidence = incorrect.length > 0
    ? Math.round(incorrect.reduce((sum, review) => sum + (review.misconception?.confidence || 0), 0) / incorrect.length)
    : 0

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKeyDown)
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', onKeyDown)
      document.body.style.overflow = ''
    }
  }, [onClose])

  return (
    <div className="review-backdrop" onClick={onClose}>
      <motion.div
        className="review-panel"
        role="dialog"
        aria-modal="true"
        aria-label="Assessment review"
        onClick={(e) => e.stopPropagation()}
        initial={{ opacity: 0, y: 40 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      >
        <header className="review-header">
          <div>
            <small>ASSESSMENT REVIEW</small>
            <h3>{title}</h3>
            <p>{subtitle}</p>
          </div>
          <button className="review-close" type="button" onClick={onClose} aria-label="Close review">{'✕'}</button>
        </header>

        <div className="review-summary">
          <div>
            <span>QUESTIONS REVIEWED</span>
            <b>{reviews.length}</b>
          </div>
          <div>
            <span>NEEDS WORK</span>
            <b className="is-warn">{incorrect.length}</b>
          </div>
          <div>
            <span>MISCONCEPTIONS FOUND</span>
            <b>{misconceptionTally.length}</b>
          </div>
          <div>
            <span>AVG CONFIDENCE</span>
            <b>{averageConfidence}%</b>
          </div>
        </div>

        {misconceptionTally.length > 0 && (
          <div className="review-tally">
            <h4>Detected Misconceptions</h4>
            <div className="review-tally-list">
              {misconceptionTally.map(([label, data]) => (
                <div key={label} className="review-tally-chip">
                  <span>{label}</span>
                  <b>{data.count} {data.count === 1 ? 'question' : 'questions'}</b>
                  <i>{data.confidence}% confidence</i>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="review-toolbar">
          <div className="review-tabs">
            <button type="button" className={!showCorrect ? 'active' : ''} onClick={() => setShowCorrect(false)}>
              Needs Work ({incorrect.length})
            </button>
            <button type="button" className={showCorrect ? 'active' : ''} onClick={() => setShowCorrect(true)}>
              All Questions ({reviews.length})
            </button>
          </div>
        </div>

        <div className="review-list">
          {visible.length === 0 ? (
            reviews.length === 0 && emptyMessage ? (
              <div className="review-empty">
                <span>{'📋'}</span>
                <h4>No question-level answers available</h4>
                <p>{emptyMessage}</p>
              </div>
            ) : (
              <div className="review-empty">
                <span>{'🎉'}</span>
                <h4>Every answer is correct</h4>
                <p>No misconceptions were detected in this assessment.</p>
              </div>
            )
          ) : visible.map((review, index) => (
            <article key={review.questionId} className={`review-card ${review.isCorrect ? 'is-correct' : 'is-wrong'}`}>
              <div className="review-card-head">
                <span className="review-card-index">Q{index + 1}</span>
                <span className={`review-status ${review.isCorrect ? 'is-correct' : 'is-wrong'}`}>
                  {review.isCorrect ? '✓ Correct' : '✕ Incorrect'}
                </span>
                <span className="review-concept">{review.concept}</span>
                <span className="review-type">{getTypeBadge(review.questionType)} &middot; {review.difficulty}</span>
              </div>

              <h4 className="review-question">{review.question}</h4>

              <div className="review-answers">
                <div className={`review-answer ${review.isCorrect ? 'is-correct' : 'is-wrong'}`}>
                  <span>Your Answer</span>
                  <b>{review.userAnswer.trim() || 'Not answered'}</b>
                </div>
                <div className="review-answer is-correct">
                  <span>Correct Answer</span>
                  <b>{review.correctAnswer}</b>
                </div>
              </div>

              <div className="review-block">
                <span className="review-block-label">Explanation</span>
                <ol className="review-steps">
                  {review.steps.map((step, i) => <li key={i}>{step}</li>)}
                </ol>
              </div>

              {!review.isCorrect && review.whyIncorrect && (
                <div className="review-block is-alert">
                  <span className="review-block-label">Why Incorrect</span>
                  <p>{review.whyIncorrect}</p>
                </div>
              )}

              {!review.isCorrect && review.misconception && (
                <div className="review-block is-misconception">
                  <span className="review-block-label">Detected Misconception</span>
                  <div className="review-misconception-row">
                    <b>{review.misconception.label}</b>
                    <div className="review-confidence">
                      <div className="review-confidence-track">
                        <div style={{ width: `${review.misconception.confidence}%` }} />
                      </div>
                      <span>Confidence Score: {review.misconception.confidence}%</span>
                    </div>
                  </div>
                </div>
              )}

              {!review.isCorrect && review.remediation && (
                <div className="review-block is-remediation">
                  <span className="review-block-label">Recommended Remediation</span>
                  <b className="review-remediation-title">{review.remediation.title}</b>
                  <p className="review-remediation-focus">{review.remediation.focus}</p>
                  <ul className="review-activities">
                    {review.remediation.activities.map(activity => <li key={activity}>{activity}</li>)}
                  </ul>
                  <button
                    className="review-start-btn"
                    type="button"
                    onClick={() => onStartLearning(review.subject, review.chapter)}
                  >
                    Start Learning {'→'}
                  </button>
                </div>
              )}

              {review.isCorrect && (
                <div className="review-block is-correct">
                  <span className="review-block-label">What this confirms</span>
                  <p>You have a sound grasp of {review.concept.toLowerCase()}. Keep it warm with a short revision before the retest.</p>
                </div>
              )}
            </article>
          ))}
        </div>
      </motion.div>
    </div>
  )
}

// ---- AI-POWERED CHAPTER DNA ----
// The full learner intelligence profile for one chapter attempt: what the learner
// knows, how they think, what is at risk, what comes next and what to do about it.
function ChapterDNAModal({ subject, chapterName, tracking, questionResults, onClose, onOpenChapter, onOpenProfile, onReviewAssessment }: {
  subject: string
  chapterName: string
  tracking: ChapterAssessmentTracking
  questionResults: ChapterQuestionResult[]
  onClose: () => void
  onOpenChapter: (subject: string, chapter: string, mode: LearningMode) => void
  onOpenProfile: () => void
  onReviewAssessment: () => void
}) {
  const latest = tracking.attempts[tracking.attempts.length - 1]

  const dna: ChapterDnaProfile = useMemo(() => {
    const pool = subjectsData[subject]?.chapters.find(c => c.name === chapterName)?.questions || []
    return buildChapterDna({
      questions: pool,
      questionResults,
      attempts: tracking.attempts.map(a => ({ attempt: a.attempt, kind: a.kind, score: a.score, date: a.date })),
      version: tracking.currentVersion?.version ?? 1,
      score: latest?.score ?? 0,
      mastery: latest?.mastery ?? 0,
      date: latest?.date ?? new Date().toISOString(),
      reasoning: latest?.reasoning ?? 0,
      problemSolving: latest?.problemSolving ?? 0,
      criticalThinking: latest?.criticalThinking ?? 0,
      chapterName,
      // Only the chapters this learner can actually open, so predictions and the
      // readiness recommendation never point at unpublished content.
      availableChapters: visibleChapters(subject).map(chapter => chapter.name),
    })
  }, [subject, chapterName, questionResults, tracking, latest])

  useEffect(() => {
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') onClose()
    }
    window.addEventListener('keydown', onKeyDown)
    document.body.style.overflow = 'hidden'
    return () => {
      window.removeEventListener('keydown', onKeyDown)
      document.body.style.overflow = ''
    }
  }, [onClose])

  const riskColor = dna.risk.level === 'Low' ? '#22c55e' : dna.risk.level === 'Medium' ? '#f59e0b' : '#ef4444'
  const masteryColor = dna.masteryLevel === 'Mastered' ? '#22c55e' : dna.masteryLevel === 'Proficient' ? '#4ebfb5' : dna.masteryLevel === 'Developing' ? '#f59e0b' : '#ef4444'

  return (
    <div className="dna-modal-backdrop" onClick={onClose}>
      <motion.div
        className="dna-modal is-wide"
        role="dialog"
        aria-modal="true"
        aria-label={`${chapterName} chapter DNA`}
        onClick={(e) => e.stopPropagation()}
        initial={{ opacity: 0, y: 40, scale: 0.98 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
      >
        <button className="dna-modal-close" type="button" onClick={onClose} aria-label="Close chapter DNA">{'✕'}</button>

        <header className="dna-modal-head">
          <small>AI-POWERED CHAPTER DNA</small>
          <h3>{chapterName}</h3>
          <p className="dna-modal-subject">{subjectEmoji(subject)} {subject}</p>
        </header>

        <div className="dna-modal-body">
          {/* SECTION 1: CHAPTER DNA SCORE */}
          <section className="cdna-section">
            <div className="cdna-score">
              <div>
                <span>CHAPTER DNA SCORE</span>
                <b style={{ color: riskColor }}>{dna.score}%</b>
              </div>
              <div className="dna-modal-track">
                <div style={{ width: `${dna.score}%`, background: riskColor }} />
              </div>
            </div>
            <div className="cdna-facts">
              <div><span>DNA VERSION</span><b>v{dna.version}</b></div>
              <div><span>ASSESSMENT DATE</span><b>{new Date(dna.date).toLocaleDateString()}</b></div>
              <div><span>MASTERY LEVEL</span><b style={{ color: masteryColor }}>{dna.masteryLevel}</b></div>
              <div><span>MASTERY</span><b>{dna.mastery}%</b></div>
            </div>
            <div className="cdna-cognitive">
              {dna.cognitive.map(item => (
                <div key={item.label}>
                  <span>{item.label}</span>
                  <b>{item.value}%</b>
                  <div className="cdna-mini-track"><div style={{ width: `${item.value}%` }} /></div>
                </div>
              ))}
            </div>
          </section>

          {/* SECTION 2: CONCEPT MASTERY */}
          <section className="cdna-section">
            <h4><span>{'\uD83D\uDCCA'}</span> Concept Mastery</h4>
            {dna.hasQuestionDetail && dna.conceptMastery.length > 0 ? (
              <div className="cdna-concepts">
                {dna.conceptMastery.map(item => (
                  <div key={item.concept} className="cdna-concept">
                    <div className="cdna-concept-head">
                      <b>{item.concept}</b>
                      <span>{item.mastery}%</span>
                    </div>
                    <div className="cdna-track">
                      <div
                        className={item.mastery >= 75 ? 'is-strong' : item.mastery < 55 ? 'is-weak' : 'is-mid'}
                        style={{ width: `${item.mastery}%` }}
                      />
                    </div>
                    <small>{item.correct} of {item.total} correct</small>
                  </div>
                ))}
              </div>
            ) : (
              <p className="cdna-empty">Concept-level mastery appears once this attempt's per-question answers are recorded.</p>
            )}
          </section>

          <div className="cdna-two-col">
            {/* SECTION 3: STRENGTHS */}
            <section className="cdna-section is-half">
              <h4><span>{'\uD83D\uDF31'}</span> Strengths</h4>
              {dna.strengths.length > 0 ? (
                <ul className="cdna-list is-strength">
                  {dna.strengths.map(item => <li key={item.concept}><span>{'\u2713'}</span>{item.concept}<i>{item.mastery}%</i></li>)}
                </ul>
              ) : (
                <p className="cdna-empty">No concept reached the strength threshold yet.</p>
              )}
            </section>

            {/* SECTION 4: KNOWLEDGE GAPS */}
            <section className="cdna-section is-half">
              <h4><span>{'\u26A0'}</span> Knowledge Gaps</h4>
              {dna.gaps.length > 0 ? (
                <ul className="cdna-list is-gap">
                  {dna.gaps.map(item => <li key={item.concept}><span>{'\u25CB'}</span>{item.concept}<i>{item.mastery}%</i></li>)}
                </ul>
              ) : (
                <p className="cdna-empty">No concept is below the gap threshold.</p>
              )}
            </section>
          </div>

          {/* SECTION 5: MISCONCEPTION ANALYSIS */}
          <section className="cdna-section">
            <h4><span>{'\uD83E\uDDEA'}</span> Misconception Analysis</h4>
            {dna.misconceptions.length > 0 ? (
              <div className="cdna-misconceptions">
                {dna.misconceptions.map(item => (
                  <div key={item.label} className="cdna-misconception">
                    <div className="cdna-misconception-head">
                      <b>{item.label}</b>
                      <span className="cdna-confidence-badge">Confidence: {item.confidence}%</span>
                    </div>
                    <p>{item.description}</p>
                    <div className="cdna-confidence-track">
                      <div style={{ width: `${item.confidence}%` }} />
                    </div>
                    <small>{item.occurrences} {item.occurrences === 1 ? 'question' : 'questions'} affected</small>
                  </div>
                ))}
              </div>
            ) : (
              <p className="cdna-empty is-good">{'✓'} No misconception pattern was detected on this attempt.</p>
            )}
          </section>

          {/* SECTION 6: LEARNING RISK */}
          <section className="cdna-section">
            <h4><span>{'\u26A1'}</span> Learning Risk</h4>
            <div className="cdna-risk" style={{ borderColor: riskColor }}>
              <span className="cdna-risk-level" style={{ color: riskColor }}>{dna.risk.level}</span>
              <p>{dna.risk.reason}</p>
            </div>
          </section>

          {/* SECTION 7: PREDICTIVE LEARNING INSIGHTS */}
          <section className="cdna-section">
            <h4><span>{'\uD83D\uDD0E'}</span> Predictive Learning Insights</h4>
<div className="cdna-forecast-grid">
              {/* Future assessments */}
              <div className="cdna-forecast">
                <span>Future Assessments</span>
                <b>{dna.predictive.nextAssessment.label}</b>
                <p>
                  Predicted score <strong>{dna.predictive.nextAssessment.predictedScore}%</strong>
                  {' '}at {dna.predictive.nextAssessment.confidence}% confidence.
                </p>
                <small>
                  {dna.predictive.nextAssessment.focusConcepts.length > 0
                    ? `Will test: ${dna.predictive.nextAssessment.focusConcepts.join(', ')}`
                    : 'No weak concept stands out, so expect a broad sample.'}
                </small>
              </div>

              {/* Remaining concepts within the chapter */}
              <div className="cdna-forecast">
                <span>Remaining Concepts</span>
                <b>{dna.predictive.remainingConcepts.length > 0 ? `${dna.predictive.remainingConcepts.length} left` : 'All covered'}</b>
                <p>
                  {dna.predictive.nextAssessment.unattemptedQuestions} question
                  {dna.predictive.nextAssessment.unattemptedQuestions === 1 ? '' : 's'} in this chapter not yet assessed.
                </p>
                {dna.predictive.remainingConcepts.length > 0 && (
                  <div className="cdna-chips">
                    {dna.predictive.remainingConcepts.slice(0, 4).map(item => (
                      <i key={item.concept}>{item.concept} &middot; {item.questions}</i>
                    ))}
                  </div>
                )}
              </div>

              {/* Retest performance */}
              <div className="cdna-forecast">
                <span>Retest Performance</span>
                <b className={`is-${dna.predictive.retest.direction}`}>
                  {dna.predictive.retest.direction === 'up' ? 'Improving' : dna.predictive.retest.direction === 'down' ? 'Slipping' : dna.predictive.retest.direction === 'flat' ? 'Steady' : 'No data'}
                </b>
                <p>
                  {dna.predictive.retest.direction === 'unknown'
                    ? `Current ${dna.predictive.retest.from}%`
                    : `${dna.predictive.retest.from}% ${'\u2192'} ${dna.predictive.retest.to}%`}
                </p>
                <small>{dna.predictive.retest.note}</small>
              </div>

              {/* Completion risk */}
              <div className="cdna-forecast">
                <span>Completion Risk</span>
                <b style={{ color: dna.predictive.completionRisk.level === 'Low' ? '#22c55e' : dna.predictive.completionRisk.level === 'Medium' ? '#f59e0b' : '#ef4444' }}>
                  {dna.predictive.completionRisk.level}
                </b>
                <p>{dna.predictive.completionRisk.reason}</p>
              </div>

              {/* Mastery progression */}
              <div className="cdna-forecast">
                <span>Mastery Progression</span>
                <b>{dna.masteryLevel}</b>
                <p>
                  {dna.predictive.progression.direction === 'unknown'
                    ? `Mastery ${dna.mastery}%`
                    : `${dna.predictive.progression.from}% ${'\u2192'} ${dna.predictive.progression.to}%`}
                </p>
                <small>{dna.predictive.progression.note}</small>
              </div>
            </div>
          </section>

          {/* SECTION 8: LEARNING READINESS */}
          <section className="cdna-section">
            <h4><span>{'\uD83C\uDFAF'}</span> Learning Readiness</h4>
            <div className="cdna-readiness">
              <div className="cdna-readiness-score">
                <span>READINESS SCORE</span>
                <b>{dna.readiness.score}%</b>
              </div>
              <div className={`cdna-readiness-status ${dna.readiness.ready ? 'is-ready' : 'is-not-ready'}`}>
                {dna.readiness.ready ? '✅ Ready' : '⚠ Needs Preparation'}
              </div>
              {dna.readiness.ready ? (
                dna.readiness.nextChapter ? (
                  <p className="cdna-readiness-next">Recommended Next Chapter: <b>{dna.readiness.nextChapter}</b></p>
                ) : (
                  <p className="cdna-readiness-next">
                    This is the last chapter in {subject} for now, so there is nothing further to unlock yet.
                  </p>
                )
              ) : (
                <>
                  <p className="cdna-readiness-next">Recommended Revision:</p>
                  <div className="cdna-chips">
                    {dna.readiness.revisionConcepts.length > 0
                      ? dna.readiness.revisionConcepts.map(item => <i key={item}>{item}</i>)
                      : <i>None recorded</i>}
                  </div>
                </>
              )}
            </div>
          </section>

          {/* SECTION 9: AI COACH RECOMMENDATION */}
          <section className="cdna-section is-coach">
            <h4><span>{'\uD83E\uDDBE'}</span> AI Coach Recommendation</h4>
            <div className="cdna-coach">
              <div className="cdna-coach-facts">
                <div><span>Focus Area</span><b>{dna.coach.focusArea}</b></div>
                <div><span>Recommended Time</span><b>{dna.coach.minutes} Minutes</b></div>
              </div>
              <div className="cdna-coach-modes">
                <span>Suggested Learning Modes</span>
                <div className="cdna-chips">{dna.coach.modes.map(mode => <i key={mode}>{mode}</i>)}</div>
              </div>
              <p className="cdna-coach-text">{dna.coach.recommendation}</p>
            </div>
          </section>

          {/* SECTION 10: RECOMMENDED REMEDIATION */}
          <section className="cdna-section">
            <h4><span>{'\uD83D\uDCD6'}</span> Recommended Remediation</h4>
            <div className="cdna-resources">
              {dna.resources.map(resource => (
                <button
                  key={resource.id}
                  className="cdna-resource"
                  type="button"
                  onClick={() => onOpenChapter(subject, chapterName, resource.mode)}
                >
                  <span className="cdna-resource-icon">{resource.icon}</span>
                  <b>{resource.label}</b>
                  <small>{resource.detail}</small>
                </button>
              ))}
            </div>
          </section>

          {/* SECTION 11: DNA EVOLUTION */}
          <section className="cdna-section">
            <h4><span>{'\uD83D\uDCC8'}</span> DNA Evolution</h4>
            {dna.evolution.length > 0 ? (
              <>
                <div className="cdna-evolution">
                  {dna.evolution.map((point, index) => (
                    <div key={`${point.label}-${index}`} className="cdna-evolution-step">
                      <span>{point.label}</span>
                      <b style={{ color: getRiskColor(getRiskBadge(point.score)) }}>{point.score}%</b>
                    </div>
                  ))}
                </div>
                {dna.evolution.length > 1 && (
                  <div className={`cdna-trend ${dna.trend >= 0 ? 'is-up' : 'is-down'}`}>
                    Trend: {dna.evolution.map(point => `${point.score}%`).join(' → ')} ({dna.trend >= 0 ? '+' : ''}{dna.trend}%)
                  </div>
                )}
              </>
            ) : (
              <p className="cdna-empty">Complete the retest to see how this DNA evolves.</p>
            )}
          </section>
        </div>

        <footer className="cdna-actions">
          <button className="cdna-action is-quiet" type="button" onClick={onOpenProfile}>Open full DNA Profile</button>
          {dna.hasQuestionDetail && (
            <button className="cdna-action is-quiet" type="button" onClick={onReviewAssessment}>Review Assessment</button>
          )}
          <button
            className="cdna-action is-primary"
            type="button"
            onClick={() => onOpenChapter(subject, chapterName, 'document')}
          >
            {'\u27A4'} Start Learning
          </button>
        </footer>
      </motion.div>
    </div>
  )
}

// ---- SUBJECT -> CHAPTER -> MODE EXPLORER ----
function SubjectExplorer({ student, onOpenChapter }: { student: RegistrationData; onOpenChapter: (subject: string, chapter: string, mode: LearningMode) => void }) {
  const subjects = student.preferredSubjects.filter(s => s === 'Mathematics' || s === 'Science')
  const [selectedSubject, setSelectedSubject] = useState<string | null>(subjects[0] || null)
  const [selectedChapter, setSelectedChapter] = useState<string | null>(null)

  useEffect(() => {
    if (!subjects.includes(selectedSubject || '')) setSelectedSubject(subjects[0] || null)
    setSelectedChapter(null)
  }, [subjects.join(',')])

  const chapters = selectedSubject ? visibleChapters(selectedSubject) : []

  if (subjects.length === 0) {
    return (
      <div className="explorer-empty">
        <span>{'\uD83D\uDCDD'}</span>
        <h3>No subjects selected</h3>
        <p>Register with Mathematics or Science to unlock chapters and learning modes.</p>
      </div>
    )
  }

  return (
    <div className="subject-explorer">
      <div className="explorer-step">
        <span className="explorer-step-label">Step 1 · Choose a subject</span>
        <div className="explorer-subject-grid">
          {subjects.map(subject => (
            <button
              key={subject}
              type="button"
              className={`explorer-subject ${selectedSubject === subject ? 'active' : ''}`}
              onClick={() => { setSelectedSubject(subject); setSelectedChapter(null) }}
            >
              <span className="explorer-subject-icon">{subjectEmoji(subject)}</span>
              <b>{subject}</b>
              <small>{visibleChapters(subject).length} chapters</small>
            </button>
          ))}
        </div>
      </div>

      {selectedSubject && (
        <div className="explorer-step">
          <span className="explorer-step-label">Step 2 · Choose a chapter</span>
          {chapters.length === 0 ? (
            <div className="explorer-empty small">
              <p>No chapters have been added to {selectedSubject} yet.</p>
            </div>
          ) : (
            <div className="explorer-chapter-list">
              {chapters.map((chapter, index) => (
                <button
                  key={chapter.name}
                  type="button"
                  className={`explorer-chapter ${selectedChapter === chapter.name ? 'active' : ''}`}
                  onClick={() => setSelectedChapter(selectedChapter === chapter.name ? null : chapter.name)}
                >
                  <span className="explorer-chapter-number">{String(index + 1).padStart(2, '0')}</span>
                  <span className="explorer-chapter-body">
                    <b>{chapter.name}</b>
                    <small>{chapter.questions.length} questions in this chapter</small>
                  </span>
                  <span className="explorer-chapter-caret">{selectedChapter === chapter.name ? '\u25BE' : '\u25B8'}</span>
                </button>
              ))}
            </div>
          )}
        </div>
      )}

      {selectedChapter && (
        <div className="explorer-step">
          <span className="explorer-step-label">Step 3 · Pick a learning mode</span>
          <div className="explorer-mode-grid">
            {LEARNING_MODES.map(mode => (
              <button
                key={mode.id}
                type="button"
                className="explorer-mode"
                onClick={() => onOpenChapter(selectedSubject as string, selectedChapter, mode.id)}
              >
                <span className="explorer-mode-icon">{mode.icon}</span>
                <b>{mode.label}</b>
                <small>{mode.blurb}</small>
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  )
}

// ---- VIDEO LEARNING MODE (Phase 1 MVP) ----
// Phase 1 MVP: slides are generated dynamically from the chapter's stored content
// and narrated with the browser Speech Synthesis API. Narration finishing advances
// to the next slide automatically, so the chapter plays like a short video.
//
// Explicitly out of scope for this phase:
//   - AI generated video, talking avatars, animated explainers
//   - personalised video generation, interactive AI tutor video
//   - server-side rendering (no ffmpeg, no external media service)
//
// The AI Learning Companion sits beside the player on the same screen, so a
// learner can pause playback and ask about what they just watched.
const VIDEO_COMPLETION_THRESHOLD = 80

function VideoLearningScreen({ content, title, chapterId, isActive = true, onProgress }: {
  content: string
  title: string
  chapterId: string
  isActive?: boolean
  onProgress: (percentage: number, completed: boolean) => void
}) {
  const slides = useMemo(() => buildVideoSlides(content, title), [content, title])
  const [index, setIndex] = useState(0)
  const [autoplay, setAutoplay] = useState(false)
  const [viewed, setViewed] = useState<Record<string, boolean>>({})
  const [announced, setAnnounced] = useState(false)
  // Guards the narration completion callback against cancelled utterances.
  const playTokenRef = useRef(0)
  const { speak, stop, speaking, paused, togglePause } = useVoiceNarration()

  const slide = slides[index]
  const total = slides.length
  const progress = total > 0 ? Math.round((Object.keys(viewed).length / total) * 100) : 0
  const isLast = index === total - 1
  const supported = typeof window !== 'undefined' && 'speechSynthesis' in window

  const viewedCount = Object.keys(viewed).length
  const isComplete = viewedCount === total || progress >= VIDEO_COMPLETION_THRESHOLD

  // Report progress so the parent can persist and unlock the chapter retest.
  useEffect(() => {
    if (slides.length === 0) return
    onProgress(progress, isComplete)
  }, [progress, isComplete, slides.length, onProgress])

  // Narrate the visible slide, then move on when the narration ends.
  // The play token guards the callback, because cancelling an utterance (Stop,
  // or a manual slide change) also fires onend and would otherwise auto-advance.
  const narrate = useCallback((from: number) => {
    const target = slides[from]
    if (!target) return
    const token = ++playTokenRef.current
    speak(target.narration, () => {
      if (playTokenRef.current !== token) return
      setAutoplay(current => {
        // Only auto-advance if the learner left playback running.
        if (current && from + 1 < slides.length) {
          setIndex(from + 1)
          return current
        }
        if (current && from + 1 >= slides.length) setAnnounced(true)
        return current
      })
    })
  }, [slides, speak])

  // Auto-start narration whenever a slide is displayed, per the MVP spec.
  useEffect(() => {
    if (!autoplay || !slide) return
    stop()
    narrate(index)
  }, [index, autoplay, slide, narrate, stop])

  // A slide only counts as watched once playback has actually been started, so
  // simply opening the Video tab reports 0% rather than counting the first slide.
  useEffect(() => {
    if (!slide || !autoplay) return
    setViewed(prev => (prev[slide.id] ? prev : { ...prev, [slide.id]: true }))
  }, [slide, autoplay])

  useEffect(() => () => { playTokenRef.current++; stop() }, [stop])

  // Stop the moment this mode is navigated away from, so narration never carries
  // over into another learning mode. The speech engine is global, so a lingering
  // utterance would otherwise keep talking over the new mode.
  useEffect(() => {
    if (isActive) return
    playTokenRef.current++
    stop()
    setAutoplay(false)
  }, [isActive, stop])

  // Manual navigation stops the current narration; the effect above starts the
  // new slide's narration when playback is still running.
  const goTo = (target: number) => {
    playTokenRef.current++
    stop()
    setAnnounced(false)
    setIndex(Math.max(0, Math.min(total - 1, target)))
  }

  const togglePlay = () => {
    if (autoplay) {
      playTokenRef.current++
      stop()
      setAutoplay(false)
    } else {
      setAnnounced(false)
      setAutoplay(true)
    }
  }

  if (slides.length === 0) {
    return <div className="explorer-empty small"><p>No video content could be generated for {title}.</p></div>
  }

  return (
    <div className="video-player">
      <div className="video-title-row">
        <h2 className="video-title">{title} {'\u00B7'} Video Lesson</h2>
        <span className="video-title-meta">
          {VIDEO_SLIDE_META[slide.kind].icon} {VIDEO_SLIDE_META[slide.kind].title} {'\u00B7'} Slide {index + 1} of {total}
        </span>
      </div>

      {/* The stage is the video container. Clicking it toggles playback, and a
          large centred Play button appears until playback starts, like YouTube. */}
      <div
        className={`video-stage ${autoplay ? 'is-playing' : ''}`}
        onClick={togglePlay}
        role="button"
        tabIndex={0}
        onKeyDown={(e) => { if (e.key === 'Enter' || e.key === ' ') { e.preventDefault(); togglePlay() } }}
        aria-label={autoplay ? 'Pause video lesson' : 'Play video lesson'}
      >
        <div className="video-slide" key={slide.id}>
          <h3>{slide.title}</h3>
          <p className="video-slide-subtitle">{slide.subtitle}</p>
          <ul>
            {slide.bullets.map((bullet, i) => <li key={i}>{bullet}</li>)}
          </ul>
        </div>

        {!autoplay && (
          <button
            type="button"
            className="video-overlay-play"
            onClick={(e) => { e.stopPropagation(); togglePlay() }}
            title={announced ? 'Replay the lesson' : 'Play'}
          >
            <span className="video-overlay-play-icon">{'\u25B6'}</span>
            <span className="video-overlay-play-label">
              {announced ? 'Replay lesson' : 'Play lesson'}
            </span>
          </button>
        )}

        {autoplay && paused && (
          <div className="video-paused-veil">
            <span>{'\u23F8'}</span>
            <small>Voice paused</small>
          </div>
        )}

        <span className="video-stage-counter">Slide {index + 1} / {total}</span>

        {!supported && (
          <div className="video-notice">This browser has no speech engine, so use Next to move through the slides.</div>
        )}
      </div>

      {isComplete && (
        <div className="video-complete-bar">
          {'\u2713'} Video learning complete
          {viewedCount < total ? ' \u00B7 80% threshold reached' : ''}
        </div>
      )}

      {/* Control bar: scrubber with slide ticks, transport buttons and time. */}
      <div className="video-controlbar">
        <div className="video-scrubber" onClick={(e) => {
          const rect = e.currentTarget.getBoundingClientRect()
          const ratio = (e.clientX - rect.left) / rect.width
          goTo(Math.min(total - 1, Math.max(0, Math.round(ratio * (total - 1)))))
        }}>
          <div className="video-scrubber-track">
            <div className="video-scrubber-fill" style={{ width: `${progress}%` }} />
            {slides.map((s, i) => (
              <span
                key={s.id}
                className={`video-scrubber-tick ${i <= index ? 'is-passed' : ''} ${viewed[s.id] ? 'is-viewed' : ''}`}
                style={{ left: `${total > 1 ? (i / (total - 1)) * 100 : 0}%` }}
              />
            ))}
          </div>
        </div>

        <div className="video-controlbar-row">
          <div className="video-transport">
            <button type="button" onClick={() => goTo(index - 1)} disabled={index === 0} title="Previous slide">
              <span>{'\u23EE'}</span>
            </button>
            <button
              type="button"
              className="video-transport-main"
              onClick={togglePlay}
              title={autoplay ? 'Pause' : announced ? 'Replay' : 'Play'}
            >
              <span>{autoplay ? '\u23F8' : '\u25B6'}</span>
            </button>
            <button type="button" onClick={() => goTo(index + 1)} disabled={isLast} title="Next slide">
              <span>{'\u23ED'}</span>
            </button>
            <button type="button" onClick={stop} disabled={!speaking} title="Stop narration">
              <span>{'\u23F9'}</span>
            </button>
            {speaking && (
              <button type="button" onClick={togglePause} title={paused ? 'Resume voice' : 'Pause voice'}>
                <span>{paused ? '\u25B6' : '\u23F8'}</span>
              </button>
            )}
          </div>

          <span className="video-time-readout">
            Slide {index + 1} of {total}
            <i /> Progress: {progress}%
          </span>
        </div>
      </div>

      <ol className="video-slide-list">
        {slides.map((s, i) => (
          <li
            key={s.id}
            className={`${i === index ? 'is-current' : ''} ${viewed[s.id] ? 'is-viewed' : ''}`}
          >
            <button type="button" onClick={() => goTo(i)}>
              <span className="video-slide-num">{viewed[s.id] ? '\u2713' : i + 1}</span>
              <span className="video-slide-name">{VIDEO_SLIDE_META[s.kind].title}</span>
            </button>
          </li>
        ))}
      </ol>

      <div className="video-footer">
        <span>{chapterId}</span>
        <span>{slides.length} slides generated from chapter content</span>
        {announced && !autoplay && <span className="video-footer-hint">Narration finished. Press Replay or pick a slide.</span>}
      </div>
    </div>
  )
}

// ---- LEARNER DOCUMENT ----
function LearnerDocument({ content, chapterTitle }: { content: string; chapterTitle: string }) {
  const sections = useMemo(() => parseDocumentSections(content), [content])

  if (sections.length === 0) {
    return <div className="explorer-empty small"><p>No document has been added to {chapterTitle} yet.</p></div>
  }

  return (
    <div className="learner-document">
      {sections.map((section, index) => (
        <section key={`${section.heading}-${index}`} className="document-section">
          <h4>
            <span className="document-section-index">{index + 1}</span>
            {section.heading}
          </h4>
          {section.body.map((line, i) => {
            const trimmed = line.replace(/\*\*(.+?)\*\*/g, '$1').trim()
            if (trimmed.startsWith('•') || /^\d+\.\s/.test(trimmed)) {
              return <p key={i} className="document-bullet">{trimmed.replace(/^•\s*/, '')}</p>
            }
            return <p key={i}>{trimmed}</p>
          })}
        </section>
      ))}
    </div>
  )
}

// ---- AI LEARNING COMPANION ----
// ---- VOICE INPUT HOOK ----
// Dictation for the AI Companion, using the Web Speech API's SpeechRecognition.
// Support is uneven: Chrome and Edge have it, Firefox and Safari do not, so
// callers must respect `supported` and keep the text input as the fallback.
//
// Chrome's SpeechRecognition streams audio to Google's servers, so it needs
// internet access and a working microphone. Each failure mode has a distinct
// error code, so the hook maps them to actionable messages and retries the
// common `no-speech` case (silence or a slow start) instead of giving up.
function useSpeechToText(onFinal: (text: string) => void) {
  const [listening, setListening] = useState(false)
  const [interim, setInterim] = useState('')
  const [error, setError] = useState('')
  const recognitionRef = useRef<any>(null)  // Held in a ref so start/stop stay stable while always calling the latest handler.
  const onFinalRef = useRef(onFinal)
  onFinalRef.current = onFinal
  // Retries for the transient `no-speech` error, keyed per recognition session.
  const retriesRef = useRef(0)
  const MAX_NO_SPEECH_RETRIES = 2

  const supported = typeof window !== 'undefined' &&
    Boolean((window as any).SpeechRecognition || (window as any).webkitSpeechRecognition)

  // Prefer the browser's own locale; fall back to en-IN only when nothing
  // narrower is available, so the speech service always has a model to use.
  const recognitionLang = (): string => {
    const nav = (navigator as any)
    const candidates = [nav?.language, nav?.userLanguage, ...(nav?.languages || [])]
    const first = candidates.find((l): l is string => typeof l === 'string' && l.trim() !== '')
    return first || 'en-IN'
  }

  const stop = useCallback(() => {
    try { recognitionRef.current?.stop() } catch { /* already stopped */ }
    recognitionRef.current = null
    setListening(false)
    setInterim('')
  }, [])

  const start = useCallback(() => {
    if (!supported || listening) return
    // Stop any narration first, otherwise the microphone records the lesson voice.
    if ('speechSynthesis' in window) window.speechSynthesis.cancel()

    const Recognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition
    const recognition = new Recognition()
    recognition.lang = recognitionLang()
    recognition.continuous = false
    recognition.interimResults = true
    recognition.maxAlternatives = 1

    let finalText = ''
    let lastError = ''
    retriesRef.current = 0

    recognition.onresult = (event: any) => {
      let pending = ''
      for (let i = event.resultIndex; i < event.results.length; i++) {
        const chunk = event.results[i][0]?.transcript ?? ''
        if (event.results[i].isFinal) finalText += chunk
        else pending += chunk
      }
      setInterim(finalText || pending)
    }
    recognition.onerror = (event: any) => {
      lastError = event?.error || ''
      if (lastError === 'not-allowed' || lastError === 'service-not-allowed') {
        setError('Microphone permission was denied. Allow mic access in the browser, then try again.')
      } else if (lastError === 'audio-capture') {
        setError('No microphone found. Check that a mic is connected and not in use elsewhere.')
      } else if (lastError === 'network') {
        setError('Voice needs an internet connection (Chrome sends audio to Google). Check your connection and try again.')
      } else if (lastError === 'no-speech') {
        // Silence or a slow start is transient; onend retries it below.
        setError('No speech detected. Speak a little louder and try again.')
      } else if (lastError === 'language-not-supported') {
        setError(`Voice is not supported for "${recognition.lang}". Try a different browser language.`)
      } else if (lastError === 'aborted') {
        // Stopped on purpose (e.g. narration cancelled it); no message needed.
      } else {
        setError('I could not hear that. Please try again.')
      }
    }
    recognition.onend = () => {
      setListening(false)
      setInterim('')
      const text = finalText.trim()
      // A clean session with speech hands the transcript straight through.
      if (text && !lastError) {
        onFinalRef.current(text)
        return
      }
      // `no-speech` is often just a slow start: restart automatically a
      // couple of times before giving up, so a hesitant speaker is not
      // cut off. start() is only legal once onend has returned, so the
      // restart is deferred to the next tick.
      if (lastError === 'no-speech' && retriesRef.current < MAX_NO_SPEECH_RETRIES) {
        retriesRef.current += 1
        window.setTimeout(() => {
          try {
            recognition.start()
            setError('')
            setListening(true)
          } catch {
            setError('Still no speech detected. You can type your question instead.')
          }
        }, 250)
        return
      }
      if (lastError === 'no-speech') {
        setError('Still no speech detected. You can type your question instead.')
      }
    }

    recognitionRef.current = recognition
    try {
      recognition.start()
      setError('')
      setListening(true)
    } catch {
      setListening(false)
      setError('The microphone is already in use.')
    }
  }, [supported, listening])

  useEffect(() => () => { try { recognitionRef.current?.stop() } catch { /* noop */ } }, [])

  return { supported, listening, interim, error, start, stop }
}

function AICompanionPanel({ studentId, chapterId, chapter, context, onUsed }: { studentId: string; chapterId: string; chapter: ChapterLearningContext['chapter']; context: ChapterLearningContext | null; onUsed: () => void }) {
  const [messages, setMessages] = useState<CompanionMessage[]>([])
  const [input, setInput] = useState('')
  const [busy, setBusy] = useState(false)
  const [speakAnswers, setSpeakAnswers] = useState(false)
  const [readingId, setReadingId] = useState('')
  const scrollRef = useRef<HTMLDivElement>(null)
  const { speak, stop: stopSpeaking, speaking } = useVoiceNarration()

  const suggested = context?.suggested_questions || [
    'What are the key concepts in this chapter?',
    'Explain in simple English.',
    'Give me a real-life example.',
    'Create practice questions.'
  ]

  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: 'smooth' })
  }, [messages, busy])

  const ask = async (question: string) => {
    const trimmed = question.trim()
    if (!trimmed || busy || !chapterId) return

    const learnerMessage: CompanionMessage = { id: `q-${Date.now()}`, role: 'learner', text: trimmed }
    setMessages(prev => [...prev, learnerMessage])
    setInput('')
    setBusy(true)
    onUsed()

    try {
      const response = await axios.post(`${API_URL}/chapters/${encodeURIComponent(chapterId)}/companion`, {
        student_id: studentId,
        message: trimmed
      })
      const answerId = `a-${Date.now()}`
      setMessages(prev => [...prev, {
        id: answerId,
        role: 'companion',
        text: response.data.response,
        sources: response.data.sources,
        usedDna: response.data.used_dna
      }])
      if (speakAnswers) {
        setReadingId(answerId)
        speak(stripMarkdown(response.data.response), () => setReadingId(''))
      }
    } catch (error) {
      setMessages(prev => [...prev, {
        id: `e-${Date.now()}`,
        role: 'companion',
        text: 'I could not reach the learning service. Check that the backend is running, then try again.'
      }])
    } finally {
      setBusy(false)
    }
  }

  // Voice input is set up after `ask` exists, so the hook can hand a finished
  // transcript straight through as a question.
  const handleSpokenQuestion = useCallback((text: string) => {
    setInput(text)
    ask(text)
  }, [ask])

  const voice = useSpeechToText(handleSpokenQuestion)

  // Optionally read each answer aloud, which is the other half of voice support.
  const readAnswer = (id: string, text: string) => {
    if (readingId === id && speaking) {
      stopSpeaking()
      setReadingId('')
      return
    }
    setReadingId(id)
    speak(stripMarkdown(text), () => setReadingId(''))
  }

  useEffect(() => () => stopSpeaking(), [stopSpeaking])

  return (
    <aside className="companion-panel">
      <header className="companion-head">
        <span className="companion-avatar">{'\uD83E\uDD16'}</span>
        <div>
          <b>AI Learning Companion</b>
          <small>Context-aware · {chapter.title}</small>
        </div>
        <button
          type="button"
          className={`companion-voice-toggle ${speakAnswers ? 'is-on' : ''}`}
          onClick={() => { setSpeakAnswers(prev => !prev); if (speakAnswers) { stopSpeaking(); setReadingId('') } }}
          title={speakAnswers ? 'Stop reading answers aloud' : 'Read answers aloud'}
        >
          <span>{speakAnswers ? '\uD83D\uDD0A' : '\uD83D\uDD0E'}</span>
        </button>
        {context?.dna && <span className="companion-dna-pill">DNA {Math.round(context.dna.overall_score)}%</span>}
      </header>

      <div className="companion-context">
        <span>{chapter.subject}</span>
        <span>{chapter.title}</span>
        {context && <span>{context.question_count} questions</span>}
      </div>

      <div className="companion-thread" ref={scrollRef}>
        {messages.length === 0 && (
          <div className="companion-welcome">
            <p>
              Ask me anything about <b>{chapter.title}</b>. I use the chapter content, your DNA and your
              assessment results, so my answers stay specific to you.
            </p>
          </div>
        )}
        {messages.map(message => (
          <div key={message.id} className={`companion-msg is-${message.role}`}>
            <p>{message.text}</p>
            {message.role === 'companion' && (
              <div className="companion-msg-actions">
                <button
                  type="button"
                  className={`companion-speak-btn ${readingId === message.id && speaking ? 'is-reading' : ''}`}
                  onClick={() => readAnswer(message.id, message.text)}
                  title={readingId === message.id && speaking ? 'Stop reading' : 'Read this answer aloud'}
                >
                  <span>{readingId === message.id && speaking ? '\u23F9' : '\uD83D\uDD0E'}</span>
                  {readingId === message.id && speaking ? 'Stop' : 'Listen'}
                </button>
                {message.sources?.slice(0, 3).map((source, i) => (
                  <span key={i} className="companion-source">{source.heading}</span>
                ))}
                {message.usedDna && <span className="companion-source is-dna">DNA used</span>}
</div>
          )}
          </div>
        ))}
        {busy && <div className="companion-msg is-companion is-typing"><span /><span /><span /></div>}
      </div>

      <div className="companion-suggestions">
        {suggested.map(question => (
          <button key={question} type="button" onClick={() => ask(question)} disabled={busy}>{question}</button>
        ))}
      </div>

      {voice.error && <div className="companion-voice-error">{voice.error}</div>}

      <form className="companion-input" onSubmit={(e) => { e.preventDefault(); ask(input) }}>
        {voice.supported && (
          <button
            type="button"
            className={`companion-mic ${voice.listening ? 'is-listening' : ''}`}
            onClick={() => (voice.listening ? voice.stop() : voice.start())}
            disabled={busy}
            title={voice.listening ? 'Stop listening' : 'Ask by voice'}
            aria-pressed={voice.listening}
          >
            <span>{'\uD83C\uDFA4'}</span>
          </button>
        )}
        <input
          value={voice.listening ? (voice.interim || 'Listening...') : input}
          onChange={(e) => setInput(e.target.value)}
          placeholder={voice.listening ? 'Speak your question...' : `Ask about ${chapter.title}...`}
          disabled={busy || voice.listening}
        />
        <button type="submit" disabled={busy || !input.trim() || voice.listening}>{'\u27A4'}</button>
      </form>
      {!voice.supported && (
        <p className="companion-voice-note">
          Voice input is not available in this browser. Chrome or Edge support it.
        </p>
      )}
    </aside>
  )
}

// ---- AUDIO LEARNING PLAYER ----
// There is no recorded audio for the seeded chapters, so narration comes from the
// browser Speech Synthesis API. This wraps it in a player that behaves like audio:
// a waveform scrubber, elapsed/remaining time, and navigable "tracks" built from
// the document's own sections.
//
// Advancement is driven by the speech engine's onend (accurate), while the visual
// progress is a smoothed estimate so the bar moves naturally between boundaries.
const WORDS_PER_SECOND = 2.4

const estimateDuration = (text: string) => Math.max(6, Math.round(text.trim().split(/\s+/).length / WORDS_PER_SECOND))
const formatTime = (seconds: number) => {
  const s = Math.max(0, Math.round(seconds))
  return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, '0')}`
}

interface AudioTrack {
  id: string
  title: string
  text: string
  narration: string
  seconds: number
}

function AudioLessonPlayer({ content, title, isActive = true, onProgress }: {
  content: string
  title: string
  isActive?: boolean
  onProgress: (percentage: number, completed: boolean) => void
}) {
  const tracks = useMemo<AudioTrack[]>(() => {
    const sections = parseDocumentSections(content)
    const built = sections
      .map((section, index) => {
        const lines = joinWrappedLines(section.body.filter(line => !isSkippableLine(stripMarkdown(line))))
        const narration = buildNarration(section.heading, lines)
        return {
          id: `track-${index}-${section.heading.toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 30)}`,
          title: section.heading,
          text: lines.join('. '),
          narration,
          seconds: estimateDuration(narration)
        }
      })
      .filter(track => track.text.length > 0)
    return built.length > 0
      ? built
      : [{ id: 'track-0-full', title, text: title, narration: `${title}.`, seconds: estimateDuration(title) }]
  }, [content, title])

  const [trackIndex, setTrackIndex] = useState(0)
  const [playing, setPlaying] = useState(false)
  const [elapsed, setElapsed] = useState(0)
  const [listened, setListened] = useState<Record<string, boolean>>({})
  const [finished, setFinished] = useState(false)
  // Incremented on every play/stop/jump so a cancelled utterance's onend callback
  // is ignored rather than treated as a completed track.
  const playTokenRef = useRef(0)
  const { speak, stop, speaking, paused, togglePause } = useVoiceNarration()

  const track = tracks[trackIndex]
  const totalSeconds = tracks.reduce((sum, t) => sum + t.seconds, 0)
  const elapsedBefore = tracks.slice(0, trackIndex).reduce((sum, t) => sum + t.seconds, 0)
  const overallProgress = totalSeconds > 0
    ? Math.min(100, Math.round(((elapsedBefore + Math.min(elapsed, track.seconds)) / totalSeconds) * 100))
    : 0

  const listenedCount = Object.keys(listened).length
  const isComplete = listenedCount === tracks.length

  const supported = typeof window !== 'undefined' && 'speechSynthesis' in window
  const supportedRef = useRef(supported)
  supportedRef.current = supported

  useEffect(() => {
    if (isComplete) onProgress(100, true)
  }, [isComplete, onProgress])

  // Smooth the progress bar while narration runs. Advancement itself is handled by
  // the speech engine callback, so this only drives the visuals.
  useEffect(() => {
    if (!playing) return
    const id = window.setInterval(() => {
      setElapsed(current => {
        const next = current + 0.25
        if (next >= track.seconds) return track.seconds
        return next
      })
    }, 250)
    return () => window.clearInterval(id)
  }, [playing, track.seconds])

  // Narrate the current track, moving to the next one when it finishes.
  // A track only counts as listened once its narration has actually ENDED, so
  // skipping through the list cannot mark the lesson complete.
  //
  // The play token guards the completion callback: browsers also fire onend when
  // an utterance is cancelled, so without this guard pressing Stop (or jumping to
  // another track) would look like the track finished and advance to the next one.
  const playTrack = useCallback((index: number) => {
    const target = tracks[index]
    if (!target) {
      setFinished(true)
      setPlaying(false)
      return
    }
    const token = ++playTokenRef.current
    setTrackIndex(index)
    setElapsed(0)
    setFinished(false)
    setPlaying(true)
    speak(target.narration, () => {
      if (playTokenRef.current !== token) return
      setListened(prev => (prev[target.id] ? prev : { ...prev, [target.id]: true }))
      if (index + 1 < tracks.length) playTrack(index + 1)
      else {
        setPlaying(false)
        setFinished(true)
      }
    })
  }, [tracks, speak])

  // No autoplay: the learner presses Play, so merely opening the tab does not
  // count towards completion.
  useEffect(() => () => stop(), [stop])

  // Stop as soon as the learner navigates to another learning mode.
  useEffect(() => {
    if (isActive) return
    playTokenRef.current++
    stop()
    setPlaying(false)
  }, [isActive, stop])

  const jumpTo = (index: number) => {
    const bounded = Math.max(0, Math.min(tracks.length - 1, index))
    playTokenRef.current++
    stop()
    if (supportedRef.current) playTrack(bounded)
    else {
      // Without a speech engine there is nothing to hear, so stepping through is
      // treated as consuming that section.
      setTrackIndex(bounded)
      setElapsed(0)
      setPlaying(false)
      setFinished(false)
      setListened(prev => ({ ...prev, [tracks[bounded].id]: true }))
    }
  }

  const togglePlay = () => {
    if (playing) {
      playTokenRef.current++
      stop()
      setPlaying(false)
    } else {
      jumpTo(trackIndex === tracks.length - 1 && finished ? 0 : trackIndex)
    }
  }

  const handleStop = () => {
    // Invalidate the pending narration callback first: cancelling an utterance
    // still fires its onend, which would otherwise be read as "track finished".
    playTokenRef.current++
    stop()
    setPlaying(false)
    setElapsed(0)
    setTrackIndex(0)
    setFinished(false)
  }

  // Deterministic bar heights give a waveform that does not jitter between renders.
  const bars = useMemo(
    () => Array.from({ length: 56 }, (_, i) => 22 + Math.abs(Math.sin(i * 0.7) * 58 + Math.cos(i * 0.31) * 22)),
    []
  )

  if (tracks.length === 0) {
    return <div className="explorer-empty small"><p>No audio content available for {title}.</p></div>
  }

  return (
    <div className="audio-player">
      <div className="audio-now-playing">
        <span className="audio-track-label">
          Track {trackIndex + 1} of {tracks.length}
        </span>
        <h3>{track.title}</h3>
        <p className="audio-track-text">{track.text.slice(0, 260)}{track.text.length > 260 ? '...' : ''}</p>
      </div>

      <div className={`audio-waveform ${playing && !paused ? 'is-playing' : ''}`} aria-hidden="true">
        {bars.map((height, i) => {
          const position = i / bars.length
          return (
            <span
              key={i}
              className={position <= overallProgress / 100 ? 'is-played' : ''}
              style={{ height: `${height}%`, animationDelay: `${(i % 7) * 0.09}s` }}
            />
          )
        })}
      </div>

      <div className="audio-scrub">
        <div className="audio-scrub-track">
          <div className="audio-scrub-fill" style={{ width: `${overallProgress}%` }} />
        </div>
        <div className="audio-time">
          <span>{formatTime(elapsedBefore + elapsed)}</span>
          <span>{formatTime(totalSeconds)}</span>
        </div>
      </div>

      <div className="audio-controls">
        <button type="button" onClick={() => jumpTo(trackIndex - 1)} disabled={trackIndex === 0} title="Previous track">
          <span>{'\u23EE'}</span> Previous
        </button>
        <button type="button" onClick={() => jumpTo(trackIndex - 1)} className="audio-btn-back" title="Back 10 seconds">
          {'\u21BA'} 10s
        </button>
        <button type="button" className="audio-btn-play" onClick={togglePlay}>
          <span>{playing ? '\u23F8' : '\u25B6'}</span> {playing ? 'Pause' : finished ? 'Replay' : 'Play'}
        </button>
        <button type="button" onClick={() => jumpTo(trackIndex + 1)} disabled={trackIndex === tracks.length - 1} title="Next track">
          Next <span>{'\u23ED'}</span>
        </button>
        <button type="button" onClick={handleStop} className="audio-btn-stop">
          <span>{'\u23F9'}</span> Stop
        </button>
        {speaking && (
          <button type="button" onClick={togglePause} className="audio-btn-pause">
            <span>{paused ? '\u25B6' : '\u23F8'}</span> {paused ? 'Resume' : 'Pause voice'}
          </button>
        )}
      </div>

      <ol className="audio-track-list">
        {tracks.map((t, i) => (
          <li key={t.id} className={`${i === trackIndex ? 'is-current' : ''} ${listened[t.id] ? 'is-listened' : ''}`}>
            <button type="button" onClick={() => jumpTo(i)}>
              <span className="audio-track-num">
                {i === trackIndex && playing ? <span className="audio-eq" /> : (listened[t.id] ? '\u2713' : i + 1)}
              </span>
              <span className="audio-track-name">{t.title}</span>
              <span className="audio-track-time">{formatTime(t.seconds)}</span>
            </button>
          </li>
        ))}
      </ol>

      <div className="audio-footer">
        <span>{listenedCount}/{tracks.length} tracks listened</span>
        {isComplete && <span className="audio-footer-done">{'\u2713'} Audio learning complete</span>}
        {!supported && <span className="audio-footer-warn">No speech engine in this browser — use the track list to step through.</span>}
      </div>
    </div>
  )
}

// ---- CHAPTER LEARNING SCREEN ----
function ChapterLearningScreen({ student, subject, chapterName, initialMode = 'document', onBack, onModeComplete, onCompanionUsed }: { student: RegistrationData; subject: string; chapterName: string; initialMode?: LearningMode; onBack: () => void; onModeComplete: (chapterName: string, subject: string, mode: string, percentage?: number) => void; onCompanionUsed: () => void }) {
  // Opens on the learning mode the learner picked in the Subjects tab.
  const [activeMode, setActiveMode] = useState<LearningMode>(initialMode)
  const [context, setContext] = useState<ChapterLearningContext | null>(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')
  const [slideIndex, setSlideIndex] = useState(0)
  const { speak, stop: stopVoice, speaking, paused, togglePause } = useVoiceNarration()

  // Chapter ids are owned by the repository (e.g. "sci-human-body"), so resolve them
  // from the API by subject + title rather than guessing a slug in the client.
  useEffect(() => {
    let cancelled = false

    const load = async () => {
      setLoading(true)
      setError('')
      try {
        const chapters = await axios.get(`${API_URL}/repo/chapters`).then(r => r.data as { id: string; title: string; subject: string }[])
        if (cancelled) return
        const match = chapters.find(c =>
          c.title.toLowerCase() === chapterName.toLowerCase() && c.subject === subject
        )
        if (!match) {
          setError(`"${chapterName}" is not in the content repository yet. Add it from the chapter repository screen.`)
          setLoading(false)
          return
        }
        const data = await axios
          .get(`${API_URL}/chapters/${encodeURIComponent(match.id)}/learning-context`, { params: { student_id: student.id || '' } })
          .then(r => r.data)
        if (!cancelled) setContext(data)
      } catch {
        if (!cancelled) setError('Chapter content could not be loaded. Is the backend running?')
      } finally {
        if (!cancelled) setLoading(false)
      }
    }

    load()
    return () => { cancelled = true }
  }, [subject, chapterName, student.id])

  useEffect(() => () => stopVoice(), [stopVoice])

  // Media is looked up across the whole content pool, not just the active mode.
  // The API groups content as document / ppt / video / audio, so scoping this to
  // activeMode would leave the audio tab empty even when a video exists to narrate.
  const contentPool = useMemo(
    () => Object.values(context?.modes || {}).flat() as ChapterContentItem[],
    [context]
  )
  const document = contentPool.find(item => item.type === 'document')
  const slides = contentPool.filter(item => item.type === 'ppt')
  const video = contentPool.find(item => item.type === 'video')
  const audio = contentPool.find(item => item.type === 'audio')
  // Narration falls back to the chapter's own writing when no audio file exists.
  const narration = audio || document
  const currentSlide = slides[slideIndex]

  // Moving to another slide or mode stops the current narration, otherwise the old
  // text keeps reading over the new content. The speech engine is a single global
  // queue, so switching learning modes must clear it explicitly.
  useEffect(() => {
    if ('speechSynthesis' in window) {
      window.speechSynthesis.pause()
      window.speechSynthesis.cancel()
    }
    stopVoice()
  }, [slideIndex, activeMode, stopVoice])
  useEffect(() => { setSlideIndex(0) }, [activeMode])

  // Remediation is only recorded when the learner says they finished the mode,
  // so simply opening a tab never unlocks a retest.
  const [markedModes, setMarkedModes] = useState<string[]>([])
  // Progress is tracked per learning mode so a mode never shows another mode's
  // numbers. The completion bar reads only the entry for the active mode.
  const [modeProgress, setModeProgress] = useState<Record<string, { percentage: number; completed: boolean }>>({})
  const activeProgress = modeProgress[activeMode] || { percentage: 0, completed: false }
  const markModeComplete = (mode: string) => {
    if (markedModes.includes(mode)) return
    setMarkedModes(prev => [...prev, mode])
    onModeComplete(chapterName, subject, mode)
  }

  const availableModes = LEARNING_MODES.filter(mode => {
    if (!context) return mode.id === 'document'
    const has = (key: string) => Boolean(context.modes?.[key]?.length)
    if (mode.id === 'document') return has('document')
    if (mode.id === 'ppt') return has('ppt')
    // Video and audio can both be generated from the document, so they are offered
    // whenever chapter notes exist rather than only when a media file is attached.
    if (mode.id === 'video') return has('video') || has('document')
    return has('audio') || has('video') || has('document')
  })

  // Each player reports into its own key, so switching modes never mixes progress.
  // Completion counts as remediation only once that mode's own threshold is met.
  const reportModeProgress = useCallback((mode: string, percentage: number, completed: boolean) => {
    setModeProgress(prev => {
      const current = prev[mode]
      if (current && current.percentage === percentage && current.completed === completed) return prev
      return { ...prev, [mode]: { percentage, completed } }
    })
    if (completed) onModeComplete(chapterName, subject, mode, percentage)
  }, [onModeComplete, chapterName, subject])

  // Video Learning reaches its threshold at 80% watched; audio needs every track.
  const handleVideoProgress = useCallback(
    (percentage: number, completed: boolean) => reportModeProgress('video', percentage, completed),
    [reportModeProgress]
  )
  const handleAudioProgress = useCallback(
    (percentage: number, completed: boolean) => reportModeProgress('voice', percentage, completed),
    [reportModeProgress]
  )

  return (
    <div className="chapter-learning">
      <header className="walk-header">
        <Logo />
        <span className="chapter-learning-crumb">{subjectEmoji(subject)} {subject} / {chapterName}</span>
        <button className="header-quiet" onClick={() => { stopVoice(); onBack() }}>{'\u2190'} Back</button>
      </header>

      <nav className="mode-switch">
        {availableModes.map(mode => (
          <button
            key={mode.id}
            type="button"
            className={`mode-switch-btn ${activeMode === mode.id ? 'active' : ''}`}
            onClick={() => setActiveMode(mode.id)}
          >
            <span>{mode.icon}</span>{mode.label}
          </button>
        ))}
      </nav>

      <div className="chapter-learning-body">
        <main className="chapter-learning-stage">
          {loading && <div className="explorer-empty"><p>Loading chapter content...</p></div>}
          {error && <div className="explorer-empty"><h3>Unavailable</h3><p>{error}</p></div>}

          {!loading && !error && (
            // Every mode panel stays mounted and inactive ones are hidden. That keeps
            // each player's own progress (current slide / track, what was watched or
            // heard) alive while the learner moves between modes, so returning to a
            // mode resumes where it was left instead of starting over.
            <div className="mode-stage">
              <div className="mode-panel" hidden={activeMode !== 'document'}>
                {document
                  ? <LearnerDocument content={document.text} chapterTitle={chapterName} />
                  : <div className="explorer-empty small"><p>No learner document for {chapterName} yet.</p></div>}
              </div>

              <div className="mode-panel" hidden={activeMode !== 'ppt'}>
                {slides.length > 0 ? (
                  <div className="ppt-stage">
                    <div className="ppt-stage-slide">
                      <small>Slide {slideIndex + 1} of {slides.length}</small>
                      <h3>{currentSlide.title}</h3>
                      <p>{currentSlide.text}</p>
                    </div>
                    <div className="ppt-stage-controls">
                      <button type="button" disabled={slideIndex === 0} onClick={() => setSlideIndex(i => Math.max(0, i - 1))}>{'\u2190'} Previous</button>
                      <SpeechControls
                        playLabel="Read aloud"
                        speaking={speaking}
                        paused={paused}
                        onPlay={() => speak(`${currentSlide.title}. ${currentSlide.text}`)}
                        onTogglePause={togglePause}
                        onStop={stopVoice}
                      />
                      <button type="button" disabled={slideIndex === slides.length - 1} onClick={() => setSlideIndex(i => Math.min(slides.length - 1, i + 1))}>Next {'\u2192'}</button>
                    </div>
                  </div>
                ) : <div className="explorer-empty small"><p>No slides for {chapterName} yet.</p></div>}
              </div>

              <div className="mode-panel" hidden={activeMode !== 'video'}>
                {/* A real, attached MP4 takes the video container. When the repository
                    only holds a placeholder link, the generated narrated lesson takes
                    that same slot, so the placeholder card is never shown alone. */}
                {video && isPlayableUrl(video.url)
                  ? (
                    <div className="media-stage">
                      <video className="media-player" controls preload="metadata" src={video.url} />
                      <div className="media-stage-meta">
                        <b>{video.title}</b>
                        <p>{video.description || 'Chapter video lesson'}</p>
                        {video.duration && <small>{video.duration}</small>}
                      </div>
                    </div>
                  )
                  : document
                    ? <VideoLearningScreen content={document.text} title={chapterName} chapterId={context?.chapter.id || chapterId} isActive={activeMode === 'video'} onProgress={handleVideoProgress} />
                    : video
                      ? (
                        <div className="media-stage">
                          <div className="media-stage-frame">
                            <span className="media-stage-icon">{'\uD83C\uDFAC'}</span>
                            <b>{video.title}</b>
                            <p>{video.description || 'Chapter video lesson'}</p>
                            {video.duration && <small>{video.duration}</small>}
                          </div>
                          <div className="explorer-empty small">
                            <p>No playable video is attached to this chapter, and there are no chapter notes to generate one from.</p>
                          </div>
                        </div>
                      )
                      : <div className="explorer-empty small"><p>No video for {chapterName} yet.</p></div>}
              </div>

              <div className="mode-panel" hidden={activeMode !== 'voice'}>
                {/* Same rule as video: a real audio file would use the media frame,
                    otherwise the player itself carries the now-playing header. */}
                {!narration
                  ? <div className="explorer-empty small"><p>Nothing to narrate for {chapterName} yet.</p></div>
                  : audio && isPlayableUrl(audio.url)
                    ? (
                      <div className="media-stage">
                        <div className="media-stage-frame is-audio">
                          <span className="media-stage-icon">{'\uD83C\uDFA7'}</span>
                          <b>{audio.title}</b>
                          <p>{audio.description || 'Chapter audio lesson'}</p>
                        </div>
                        <audio controls preload="metadata" src={audio.url} />
                      </div>
                    )
                    : <AudioLessonPlayer
                        content={narration.text}
                        title={audio?.title || chapterName}
                        isActive={activeMode === 'voice'}
                        onProgress={handleAudioProgress}
                      />}
              </div>
            </div>
          )}

          {!loading && !error && activeMode && (
            <div className="stage-complete-bar">
              <span>
                {activeProgress.completed
                  ? activeMode === 'video'
                    ? `Video learning complete (${activeProgress.percentage}% watched) — this counts as remediation automatically.`
                    : activeMode === 'voice'
                      ? 'Audio learning complete — every track was listened to, so this counts as remediation.'
                      : `${LEARNING_MODES.find(m => m.id === activeMode)?.label} complete.`
                  : activeProgress.percentage > 0
                    ? activeMode === 'video'
                      ? `Watched ${activeProgress.percentage}% of the video lesson. Reach ${VIDEO_COMPLETION_THRESHOLD}% to complete it automatically.`
                      : activeMode === 'voice'
                        ? `Listened to ${activeProgress.percentage}% of the audio lesson. Hear every track to complete it.`
                        : `${LEARNING_MODES.find(m => m.id === activeMode)?.label} in progress (${activeProgress.percentage}%).`
                    : markedModes.includes(activeMode)
                      ? `${LEARNING_MODES.find(m => m.id === activeMode)?.label} marked complete — this counts as remediation.`
                      : 'Finished this mode? Mark it complete to unlock the chapter retest.'}
              </span>
              <button
                className="primary-button"
                type="button"
                disabled={markedModes.includes(activeMode)}
                onClick={() => markModeComplete(activeMode)}
              >
                <span>{markedModes.includes(activeMode) ? '\u2713' : '\u25CF'}</span>
                {markedModes.includes(activeMode) ? 'Completed' : 'Mark complete'}
              </button>
            </div>
          )}
        </main>

        <AICompanionPanel
          studentId={student.id || ''}
          chapterId={context?.chapter.id || ''}
          chapter={context?.chapter || { id: '', title: chapterName, subject, grade: '', description: '' }}
          context={context}
          onUsed={onCompanionUsed}
        />
      </div>
    </div>
  )
}

// Splits chapter markdown into (heading, lines) sections. Shared by the learner
// document and the generated narrated lesson so both read the same way.
const parseDocumentSections = (content: string): { heading: string; body: string[] }[] => {
  const parsed: { heading: string; body: string[] }[] = []
  let heading = 'Introduction'
  let buffer: string[] = []
  // Kept off the previous line: a statement starting with "(" would otherwise be
  // parsed as a call on the `[]` above (ASI does not insert a semicolon there).
  const rawLines = (content || '').split('\n')
  rawLines.forEach((line: string) => {
    const match = line.trim().match(/^(#{1,6})\s+(.*)$/)
    if (match) {
      if (buffer.length > 0) parsed.push({ heading, body: buffer })
      heading = match[2].trim()
      buffer = []
    } else if (line.trim()) {
      buffer.push(line.trim())
    }
  })
  if (buffer.length > 0) parsed.push({ heading, body: buffer })
  return parsed
}

const stripMarkdown = (line: string) =>
  line
    .replace(/\*\*(.+?)\*\*/g, '$1')
    .replace(/^\s*[-*•]\s+/, '')
    .replace(/^\s*\d+[.)]\s+/, '')
    .trim()

// ---- VIDEO SLIDE GENERATION (Phase 1 MVP) ----
// Phase 1 presents the chapter's own content as narrated slides. Slides are built
// dynamically from the stored document rather than authored per chapter, so any
// chapter added to the repository works without new code.
//
// Future roadmap (not implemented in this phase):
//   Phase 2 - AI generated videos, talking avatars, animated explainers,
//             personalised video learning, interactive AI tutor videos.
//   Phase 3 - offline download, quizzes embedded in the timeline, cohort playback.

type VideoSlideKind = 'introduction' | 'concepts' | 'examples' | 'summary'

interface VideoSlide {
  id: string
  kind: VideoSlideKind
  title: string
  subtitle: string
  bullets: string[]
  narration: string
}

const VIDEO_SLIDE_META: Record<VideoSlideKind, { title: string; subtitle: string; icon: string }> = {
  introduction: { title: 'Introduction', subtitle: 'What this chapter is about', icon: '\uD83D\uDCD6' },
  concepts: { title: 'Key Concepts', subtitle: 'The ideas you need to know', icon: '\uD83E\uDDE0' },
  examples: { title: 'Examples', subtitle: 'Watch the ideas in action', icon: '\uD83D\uDCA1' },
  summary: { title: 'Summary', subtitle: 'The points worth remembering', icon: '\u2705' }
}

const SUMMARY_HEADING = /summary|recap|key points|revision|remember|wrap[- ]?up|conclusion/i
const EXAMPLE_HEADING = /example|worked|activity|practice|problem|demonstration/i

// A line that reads like a concrete worked step, e.g. "2 + 3 = 5" or "1/2 + 1/3 = 5/6".
const looksWorked = (line: string) => /\d\s*[+\-×x*/=]|\d\/\d|\=\s*\d/.test(line)

const isSkippableLine = (line: string) =>
  !line ||
  /^[-*_]{3,}$/.test(line) ||      // horizontal rules
  /^\|/.test(line) ||                 // table rows
  /^`/.test(line)                    // code fences
const isFragment = (line: string) => line.length < 12 && !/[.!?:]$/.test(line)

const STARTS_NEW_BULLET = /^\s*(?:[-*•]\s+|\d+[.)]\s+)/

/**
 * Chapter documents are hard-wrapped, so a single sentence often spans several
 * lines. Narration built line-by-line would pause and mispronounce at every
 * wrap, so wrapped continuations are rejoined into one bullet first.
 */
const joinWrappedLines = (lines: string[]): string[] => {
  const bullets: string[] = []
  let current = ''

  for (const raw of lines) {
    const line = stripMarkdown(raw)
    if (!line) continue
    const isNewBullet = STARTS_NEW_BULLET.test(raw) || !current
    if (isNewBullet) {
      if (current) bullets.push(current)
      current = line
    } else {
      // A wrap continues the sentence; a finished sentence just takes a space.
      current = `${current.replace(/\s+$/, '')} ${line}`
    }
  }
  if (current) bullets.push(current)
  return bullets
}

// Turns a parsed document section into a few clean, speakable bullet points.
const toBullets = (lines: string[], limit = 6): string[] => {
  const cleaned = lines.map(stripMarkdown).filter(line => !isSkippableLine(line))
  const picked: string[] = []

  // Prefer short declarative lines; they make the best narration and slide text.
  for (const line of cleaned) {
    if (picked.length >= limit) break
    if (line.length > 200) continue
    if (picked.includes(line)) continue
    picked.push(line)
  }

  // Fall back to the opening text when the section was mostly tables or art.
  if (picked.length === 0) {
    const joined = cleaned.join(' ').replace(/\s+/g, ' ').trim()
    if (joined) picked.push(joined.slice(0, 220))
  }
  return picked
}

const buildNarration = (slideTitle: string, bullets: string[]) => {
  // Tidy trailing punctuation so the speech engine does not read "...two parts:."
  const spoken = bullets
    .map(b => b.replace(/[\s:;,–—-]+$/, '').trim())
    .filter(Boolean)
    .join('. ')
  return spoken ? `${slideTitle.replace(/[\s:;,–—-]+$/, '')}. ${spoken}.` : `${slideTitle}.`
}

/**
 * Builds the four canonical video slides for a chapter from its stored content.
 * Sections are classified by heading and by whether the body reads like worked
 * example text, so the structure adapts to whatever the author wrote.
 */
const buildVideoSlides = (content: string, chapterTitle: string): VideoSlide[] => {
  const sections = parseDocumentSections(content)
  const buckets: Record<VideoSlideKind, { heading: string; body: string[] }[]> = {
    introduction: [], concepts: [], examples: [], summary: []
  }

  sections.forEach((section, index) => {
    const isFirst = index === 0
    if (SUMMARY_HEADING.test(section.heading)) {
      buckets.summary.push(section)
    } else if (EXAMPLE_HEADING.test(section.heading) || section.body.some(looksWorked)) {
      buckets.examples.push(section)
    } else if (isFirst) {
      buckets.introduction.push(section)
    } else {
      buckets.concepts.push(section)
    }
  })

  // Guarantee an introduction even when the document opens with a concepts heading.
  if (buckets.introduction.length === 0) {
    const fallback = buckets.concepts.shift() || sections[0]
    if (fallback) buckets.introduction.push(fallback)
  }

  const compose = (kind: VideoSlideKind, collected: { heading: string; body: string[] }[]): VideoSlide | null => {
    const meta = VIDEO_SLIDE_META[kind]
    const sourceHeading = collected[0]?.heading
    const title = kind === 'introduction' && sourceHeading
      ? sourceHeading.replace(/^#+\s*/, '')
      : meta.title

    // Merge each section's lines, rejoining hard wraps and dropping repeats.
    const merged: string[] = []
    for (const section of collected) {
      const usable = section.body.filter(raw => !isSkippableLine(stripMarkdown(raw)))
      merged.push(...joinWrappedLines(usable))
    }

    const seen = new Set<string>()
    const lines: string[] = []
    for (const line of merged) {
      const key = line.toLowerCase()
      if (seen.has(key) || isFragment(line)) continue
      seen.add(key)
      lines.push(line)
    }

    const bullets = toBullets(lines, kind === 'concepts' ? 7 : 5)
    if (bullets.length === 0) return null

    return {
      id: `${kind}-${collected.map(c => c.heading).join('-').toLowerCase().replace(/[^a-z0-9]+/g, '-').slice(0, 40)}`,
      kind,
      title,
      subtitle: meta.subtitle,
      bullets,
      narration: buildNarration(title, bullets)
    }
  }

  const slides: VideoSlide[] = []
  ;(['introduction', 'concepts', 'examples', 'summary'] as VideoSlideKind[]).forEach(kind => {
    const slide = compose(kind, buckets[kind])
    if (slide) slides.push(slide)
  })

  if (slides.length === 0) {
    // Never show an empty player: fall back to the chapter title as a single slide.
    return [{
      id: 'overview', kind: 'introduction', title: chapterTitle,
      subtitle: VIDEO_SLIDE_META.introduction.subtitle,
      bullets: [chapterTitle], narration: `${chapterTitle}.`
    }]
  }
  return slides
}

// ---- 3-TAB DASHBOARD ----
function Dashboard({ student, assessmentResult, initialTab = 'profile', chapterTracking, chapterQuestionResults, completedModes, evolutionEntries, companionUsed, onBack, onOpenChapter, onStartRunner }: { student: RegistrationData; assessmentResult: AssessmentResult | null; initialTab?: DashboardTab; chapterTracking: ChapterAssessmentTracking[]; chapterQuestionResults: Record<string, ChapterQuestionResult[]>; completedModes: Record<string, string[]>; evolutionEntries: EvolutionEntry[]; companionUsed: boolean; onBack: () => void; onOpenChapter: (subject: string, chapter: string, mode: LearningMode) => void; onStartRunner: (subject: string, chapterName: string, kind: 'assessment' | 'retest') => void }) {
  const [activeTab, setActiveTab] = useState<DashboardTab>(initialTab)

  // chapterTracking / completedModes / evolutionEntries are owned by App so the
  // learner's progress survives navigating into a chapter and back.
  const [showDNAModal, setShowDNAModal] = useState<{ subject: string; chapterName: string; tracking: ChapterAssessmentTracking } | null>(null)

  // The baseline review only opens once the learner has submitted a baseline, so
  // the card that offers it is the same card that carries the result.
  const [showReview, setShowReview] = useState(false)

  // Which chapter's review is open, if any.
  const [reviewChapter, setReviewChapter] = useState<{ subject: string; chapterName: string; tracking: ChapterAssessmentTracking } | null>(null)

  // Remediation from either review launches the chapter's learning content directly,
  // so the learner moves from "why I was wrong" into the material that fixes it.
  const startLearningFromReview = useCallback((subject: string, chapter: string) => {
    setShowReview(false)
    setReviewChapter(null)
    setActiveTab('subjects')
    onOpenChapter(subject, chapter, 'document')
  }, [onOpenChapter])

  // Closing the DNA modal always returns the learner to the Assessment tab they
  // opened it from, rather than leaving them wherever it happened to be.
  const closeDNAModal = useCallback(() => {
    setShowDNAModal(null)
    setActiveTab('assessment')
  }, [])

  useEffect(() => {
    if (!showDNAModal) return
    const onKeyDown = (event: KeyboardEvent) => {
      if (event.key === 'Escape') closeDNAModal()
    }
    window.addEventListener('keydown', onKeyDown)
    return () => window.removeEventListener('keydown', onKeyDown)
  }, [showDNAModal, closeDNAModal])
  const [overallScore, setOverallScore] = useState(assessmentResult?.score || 0)

  // Derive subject DNAs from assessment result
  const subjectDNAs = useMemo((): SubjectDNA[] => {
    const subjects = student.preferredSubjects.filter(s => s === 'Mathematics' || s === 'Science')
    return subjects.map(subject => {
      const chapterData = visibleChapters(subject)
      const totalChapters = chapterData.length
      let completedChapters = 0
      let totalReasoning = 0, totalProblemSolving = 0, totalCriticalThinking = 0, reasoningCount = 0, problemSolvingCount = 0, criticalThinkingCount = 0
      let totalScore = 0, scoreCount = 0

      chapterData.forEach((chapter) => {
        const isCompleted = chapterTracking.find(ct => ct.chapterName === chapter.name && ct.subject === subject)?.assessmentCompleted
        if (isCompleted) completedChapters++
        chapter.questions.forEach(q => {
          const isReasoning = q.type === 'reasoning'
          const isProblemSolving = q.type === 'problemsolving'
          const isCriticalThinking = q.type === 'criticalthinking'
          if (isReasoning) {
            reasoningCount++
            const qr = assessmentResult?.questionResults.find(r => r.questionId === q.questionId)
            if (qr) totalReasoning += qr.isCorrect ? 100 : 0
          }
          if (isProblemSolving) {
            problemSolvingCount++
            const qr = assessmentResult?.questionResults.find(r => r.questionId === q.questionId)
            if (qr) totalProblemSolving += qr.isCorrect ? 100 : 0
          }
          if (isCriticalThinking) {
            criticalThinkingCount++
            const qr = assessmentResult?.questionResults.find(r => r.questionId === q.questionId)
            if (qr) totalCriticalThinking += qr.isCorrect ? 100 : 0
          }
        })
      })

      const reasoning = reasoningCount > 0 ? Math.round(totalReasoning / reasoningCount) : 0
      const problemSolving = problemSolvingCount > 0 ? Math.round(totalProblemSolving / problemSolvingCount) : 0
      const criticalThinking = criticalThinkingCount > 0 ? Math.round(totalCriticalThinking / criticalThinkingCount) : 0
      const chapterScores = chapterTracking.filter(ct => ct.subject === subject).map(ct => ct.assessmentScore)
      const avgChapterScore = chapterScores.length > 0 ? Math.round(chapterScores.reduce((a, b) => a + b, 0) / chapterScores.length) : (assessmentResult?.subjects.includes(subject) ? assessmentResult.score : 0)

      return {
        subject,
        score: avgChapterScore,
        mastery: calcMastery(avgChapterScore, 70),
        confidence: 70,
        risk: getRiskBadge(avgChapterScore),
        strengths: [],
        gaps: [],
        reasoning,
        problemSolving,
        criticalThinking,
        chaptersTotal: totalChapters,
        chaptersCompleted: completedChapters,
        allChaptersCompleted: completedChapters === totalChapters && totalChapters > 0,
      }
    })
  }, [student.preferredSubjects, assessmentResult, chapterTracking])

  // Overall DNA score
  const overallDNA = useMemo(() => {
    if (subjectDNAs.length === 0) return { score: 0, mastery: 0, risk: 'High' as const }
    const avgScore = Math.round(subjectDNAs.reduce((sum, s) => sum + s.score, 0) / subjectDNAs.length)
    return { score: avgScore, mastery: calcMastery(avgScore, 70), risk: getRiskBadge(avgScore) }
  }, [subjectDNAs])

  // A subject's DNA is only trustworthy once every chapter under it has been assessed,
  // so the profile tab gates on full chapter completion rather than showing partials.
  const completedSubjectDNA = useMemo(() => {
    return subjectDNAs.map(dna => {
      const chapterData = visibleChapters(dna.subject)
      const totalChapters = chapterData.length
      const completed = chapterData.filter(chapter =>
        chapterTracking.find(ct => ct.chapterName === chapter.name && ct.subject === dna.subject)?.assessmentCompleted
      )
      const isComplete = totalChapters > 0 && completed.length === totalChapters

      // Latest attempt per chapter drives the subject's own numbers.
      const latest = chapterData
        .map(chapter => chapterTracking.find(ct => ct.chapterName === chapter.name && ct.subject === dna.subject))
        .filter((ct): ct is ChapterAssessmentTracking => Boolean(ct) && ct!.attempts.length > 0)
        .map(ct => ct!.attempts.reduce((best, a) => (a.attempt > best.attempt ? a : best), ct!.attempts[0]))

      const mean = (pick: (a: ChapterAttempt) => number) =>
        latest.length > 0 ? Math.round(latest.reduce((sum, a) => sum + pick(a), 0) / latest.length) : 0

      const score = latest.length > 0
        ? Math.round(latest.reduce((sum, a) => sum + a.score, 0) / latest.length)
        : dna.score

      return {
        subject: dna.subject,
        isComplete,
        chaptersCompleted: completed.length,
        chaptersTotal: totalChapters,
        score,
        mastery: calcMastery(score, 70),
        risk: getRiskBadge(score),
        // Chapter-level performance is the honest signal once chapters are done.
        strengths: latest.filter(a => a.score >= 70).map(a => a.chapterName).filter(Boolean),
        gaps: latest.filter(a => a.score < 50).map(a => a.chapterName).filter(Boolean),
        reasoning: mean(a => a.reasoning),
        problemSolving: mean(a => a.problemSolving),
        criticalThinking: mean(a => a.criticalThinking)
      }
    })
  }, [subjectDNAs, chapterTracking])

  // Baseline vs current. The baseline score is the original assessment and is never
  // mutated, so improvement stays meaningful as chapter DNA is recomputed.
  const dnaComparison = useMemo(() => {
    const baseline = assessmentResult ? assessmentResult.score : 0
    const current = overallDNA.score
    return {
      baseline,
      current,
      improvement: current - baseline,
      hasMovement: current !== baseline
    }
  }, [assessmentResult, overallDNA.score])

  // A retest unlocks once the learner has been remediated: they must have sat the
  // chapter assessment AND worked through at least one learning mode.
  const REMEDIATION_MODES_REQUIRED = 1
  const isRetestUnlocked = (tracking?: ChapterAssessmentTracking) =>
    Boolean(tracking?.assessmentCompleted) && (tracking?.completedModes.length ?? 0) >= REMEDIATION_MODES_REQUIRED && !tracking?.retestCompleted

  // Subject-wise results, strengths and gaps derived from the baseline answers so the
  // Profile tab can reuse the same components as the Baseline DNA page.
  const profileSubjectResults = useMemo<SubjectWiseResult[]>(() => {
    if (!assessmentResult) return []
    return subjectDNAs.map(dna => {
      const results = assessmentResult.questionResults.filter(r => r.subject === dna.subject)
      const correct = results.filter(r => r.isCorrect)
      const total = results.length
      return {
        subject: dna.subject,
        score: correct.length,
        total,
        percentage: total > 0 ? Math.round((correct.length / total) * 100) : 0,
        questionIds: results.map(r => r.questionId),
        correctQuestionIds: correct.map(r => r.questionId),
        incorrectQuestionIds: results.filter(r => !r.isCorrect).map(r => r.questionId),
        conceptsCorrect: [...new Set(correct.map(r => r.concept).filter(Boolean))],
        conceptsIncorrect: [...new Set(results.filter(r => !r.isCorrect).map(r => r.concept).filter(Boolean))]
      }
    }).filter(r => r.total > 0)
  }, [assessmentResult, subjectDNAs])

  const profileStrengths = useMemo(
    () => [...new Set(profileSubjectResults.flatMap(r => r.conceptsCorrect))],
    [profileSubjectResults]
  )
  const profileGaps = useMemo(
    () => [...new Set(profileSubjectResults.flatMap(r => r.conceptsIncorrect))],
    [profileSubjectResults]
  )

  // Mirrors the Baseline page: fall back to the overall score, and say so, when the
  // question pool contained no question exercising that skill.
  const profileSkills = useMemo(() => {
    const mean = (pick: (d: SubjectDNA) => number) =>
      subjectDNAs.length > 0
        ? Math.round(subjectDNAs.reduce((sum, d) => sum + pick(d), 0) / subjectDNAs.length)
        : 0
    const build = (value: number) => ({
      value: value > 0 ? value : overallDNA.score,
      basis: value > 0
        ? `measured across ${subjectDNAs.length} ${subjectDNAs.length === 1 ? 'subject' : 'subjects'}`
        : 'estimated from overall accuracy'
    })
    const reasoning = build(mean(d => d.reasoning))
    const problemSolving = build(mean(d => d.problemSolving))
    const criticalThinking = build(mean(d => d.criticalThinking))
    return { reasoning, problemSolving, criticalThinking }
  }, [subjectDNAs, overallDNA.score])

  // Which milestones of the journey this learner has actually reached.
  const journeyProgress = useMemo(() => {
    const done = new Set<string>()
    if (assessmentResult) done.add('assessment')
    if (assessmentResult) done.add('dna')
    if (Object.keys(completedModes).length > 0) done.add('learning')
    if (companionUsed) done.add('companion')
    if (chapterTracking.some(ct => ct.assessmentCompleted)) done.add('chapter-dna')
    if (subjectDNAs.some(dna => dna.chaptersCompleted > 0)) done.add('subject-dna')
    if (overallDNA.score > 0) done.add('overall-dna')
    if (chapterTracking.some(ct => ct.attempts.length > 1)) done.add('evolution')
    return done
  }, [assessmentResult, chapterTracking, subjectDNAs, overallDNA.score, completedModes, companionUsed])

  return (
    <div className="walkthrough">
      {showReview && assessmentResult && (
        <AssessmentReviewPanel
          result={assessmentResult}
          onClose={() => setShowReview(false)}
          onStartLearning={startLearningFromReview}
        />
      )}

      {reviewChapter && (
        <ChapterReviewPanel
          subject={reviewChapter.subject}
          chapterName={reviewChapter.chapterName}
          attempt={reviewChapter.tracking.attempts[reviewChapter.tracking.attempts.length - 1] || null}
          questionResults={chapterQuestionResults[`${reviewChapter.subject}::${reviewChapter.chapterName}`] || []}
          onClose={() => setReviewChapter(null)}
          onStartLearning={startLearningFromReview}
        />
      )}

      {showDNAModal && (
        <ChapterDNAModal
          subject={showDNAModal.subject}
          chapterName={showDNAModal.chapterName}
          tracking={showDNAModal.tracking}
          questionResults={chapterQuestionResults[`${showDNAModal.subject}::${showDNAModal.chapterName}`] || []}
          onClose={closeDNAModal}
          onOpenChapter={(subject, chapter, mode) => {
            closeDNAModal()
            onOpenChapter(subject, chapter, mode)
          }}
          onOpenProfile={() => {
            closeDNAModal()
            setActiveTab('profile')
          }}
          onReviewAssessment={() => {
            setReviewChapter({
              subject: showDNAModal.subject,
              chapterName: showDNAModal.chapterName,
              tracking: showDNAModal.tracking,
            })
            closeDNAModal()
          }}
        />
      )}

      <header className="walk-header">
        <Logo />
        <nav>
          <a href="#" onClick={(e) => { e.preventDefault(); setActiveTab('profile') }} style={{ color: activeTab === 'profile' ? '#6557d8' : '#7c829e' }}>DNA Profile</a>
          <a href="#" onClick={(e) => { e.preventDefault(); setActiveTab('subjects') }} style={{ color: activeTab === 'subjects' ? '#6557d8' : '#7c829e' }}>Subjects</a>
          <a href="#" onClick={(e) => { e.preventDefault(); setActiveTab('assessment') }} style={{ color: activeTab === 'assessment' ? '#6557d8' : '#7c829e' }}>Assessment</a>
        </nav>
        <button className="header-quiet" onClick={onBack}>{"\u2190"} Back</button>
      </header>

      <LearnerHeader student={student} assessmentResult={assessmentResult} />

      <div className="dna-dashboard-tabs">
        {(['profile', 'subjects', 'assessment'] as DashboardTab[]).map((tab) => (
          <button key={tab} className={`dna-tab ${activeTab === tab ? 'active' : ''}`} onClick={() => setActiveTab(tab)}>
            {tab === 'profile' ? '\uD83E\uDDE0' : tab === 'subjects' ? '\uD84C\uDF93' : '\uD83D\uDCDD'} {tab.charAt(0).toUpperCase() + tab.slice(1)}
          </button>
        ))}
      </div>

      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '30px 25px 80px' }}>
        <AnimatePresence mode="wait">
          {activeTab === 'profile' && (
            <motion.div key="profile" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} transition={{ duration: 0.3 }}>
              <Reveal>
                <div className="dna-status-bar">
                  <span className="dna-status-dot" />
                  <span>BASELINE DNA PROFILE GENERATED</span>
                </div>
              </Reveal>

              <Reveal delay={0.1}>
                <section className="dna-hero-card">
                  <div className="dna-hero-top">
                    <div className="dna-hero-identity">
                      <div className="dna-hero-avatar">{student.studentName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}</div>
                      <div className="dna-hero-meta">
                        <small>LEARNER DNA PROFILE</small>
                        <h3>{student.studentName}</h3>
                        <div className="dna-hero-tags">
                          <span>Class: {student.class}</span>
                          <span>{subjectDNAs.length} {subjectDNAs.length === 1 ? 'Subject' : 'Subjects'}</span>
                          <span>{assessmentResult ? `${assessmentResult.totalQuestions} Questions` : 'No questions yet'}</span>
                        </div>
                      </div>
                    </div>
                    <span className="dna-hero-badge">BASELINE</span>
                  </div>

                  <div className="dna-hero-metrics">
                    <div className="dna-metric">
                      <span className="dna-metric-label">OVERALL DNA SCORE</span>
                      <b className="dna-metric-value" style={{ color: getRiskColor(overallDNA.risk) }}>
                        <CountUp value={overallDNA.score} />
                      </b>
                      <div className="dna-metric-track">
                        <div className="dna-metric-fill" style={{ width: `${overallDNA.score}%`, background: getRiskColor(overallDNA.risk) }} />
                      </div>
                    </div>
                    <div className="dna-metric">
                      <span className="dna-metric-label">MASTERY LEVEL</span>
                      <b className="dna-metric-value" style={{ color: '#4ebfb5' }}>
                        <CountUp value={overallDNA.mastery} />
                      </b>
                      <div className="dna-metric-track">
                        <div className="dna-metric-fill" style={{ width: `${overallDNA.mastery}%`, background: '#4ebfb5' }} />
                      </div>
                    </div>
                    <div className="dna-metric">
                      <span className="dna-metric-label">RISK LEVEL</span>
                      <b className={`dna-metric-risk risk-${overallDNA.risk.toLowerCase()}`}>{overallDNA.risk}</b>
                      <p className="dna-metric-note">
                        {overallDNA.risk === 'Low' ? 'On track, no major gaps' : overallDNA.risk === 'Medium' ? 'Targeted support recommended' : 'Immediate remediation advised'}
                      </p>
                    </div>
                  </div>
                </section>
              </Reveal>

              <Reveal delay={0.15}>
                <div className="dna-compare-card">
                  <div className="subject-dna-head">
                    <h4 className="subject-results-title">DNA Comparison</h4>
                    <span className="subject-results-caption">Baseline against your current DNA</span>
                  </div>
                  <div className="dna-compare-grid">
                    <div className="dna-compare-cell">
                      <span>Baseline DNA Score</span>
                      <b>{dnaComparison.baseline}%</b>
                    </div>
                    <div className="dna-compare-arrow">{'\u2192'}</div>
                    <div className="dna-compare-cell is-current">
                      <span>Current DNA Score</span>
                      <b>{dnaComparison.current}%</b>
                    </div>
                    <div className={`dna-compare-improvement ${dnaComparison.improvement >= 0 ? 'is-up' : 'is-down'}`}>
                      <span>Improvement</span>
                      <b>{dnaComparison.improvement >= 0 ? '+' : ''}{dnaComparison.improvement}%</b>
                      <small>
                        {dnaComparison.hasMovement
                          ? 'Recalculated from your latest chapter results'
                          : 'Complete a chapter assessment to see movement'}
                      </small>
                    </div>
                  </div>
                </div>
              </Reveal>

              <Reveal delay={0.2}>
                <div className="dna-insight-grid">
                  <div className="dna-insight-card is-strength">
                    <h4>{'\uD83C\uDF31'} STRENGTHS</h4>
                    {profileStrengths.length > 0 ? (
                      <ul>
                        {profileStrengths.map((s, i) => (
                          <li key={i}><span className="dna-insight-marker strength">{'\u2713'}</span>{s}</li>
                        ))}
                      </ul>
                    ) : (
                      <span className="dna-insight-empty">No strengths detected yet</span>
                    )}
                  </div>
                  <div className="dna-insight-card is-gap">
                    <h4>{'\uD83D\uDD34'} GAPS</h4>
                    {profileGaps.length > 0 ? (
                      <ul>
                        {profileGaps.map((g, i) => (
                          <li key={i}><span className="dna-insight-marker gap">{'\u25CB'}</span>{g}</li>
                        ))}
                      </ul>
                    ) : (
                      <span className="dna-insight-empty">No gaps detected</span>
                    )}
                  </div>
                </div>
              </Reveal>

              {profileSubjectResults.length > 0 && (
                <Reveal delay={0.25}>
                  <SubjectResultsCard
                    subjectWiseResults={profileSubjectResults}
                    overall={{
                      correct: assessmentResult?.answeredCorrectly ?? 0,
                      total: assessmentResult?.totalQuestions ?? 0,
                      percentage: overallDNA.score
                    }}
                  />
                </Reveal>
              )}

              {completedSubjectDNA.length > 0 && (
                <Reveal delay={0.3}>
                  <div className="subject-dna-block">
                    <div className="subject-dna-head">
                      <h4 className="subject-results-title">Subject DNA</h4>
                      <span className="subject-dna-caption">Unlocks when every chapter in a subject is assessed</span>
                    </div>

                    {completedSubjectDNA.map(subjectDNA => {
                      if (!subjectDNA.isComplete) {
                        return (
                          <div key={subjectDNA.subject} className="subject-dna-row is-locked">
                            <div className="subject-dna-label">
                              <span className="subject-dna-emoji">{subjectEmoji(subjectDNA.subject)}</span>
                              <b>{subjectDNA.subject}</b>
                              <span className="subject-dna-lock">{'\uD83D\uDD12'} Locked</span>
                            </div>
                            <div className="subject-dna-track">
                              <div className="subject-dna-fill" style={{ width: `${subjectDNA.chaptersTotal ? (subjectDNA.chaptersCompleted / subjectDNA.chaptersTotal) * 100 : 0}%`, background: '#cbc6f2' }} />
                            </div>
                            <p className="subject-dna-locked-note">
                              Complete all {subjectDNA.chaptersTotal} chapters to generate {subjectDNA.subject} DNA
                              <b> {subjectDNA.chaptersCompleted}/{subjectDNA.chaptersTotal}</b> done.
                            </p>
                          </div>
                        )
                      }
                      return (
                        <div key={subjectDNA.subject} className="subject-dna-row">
                          <div className="subject-dna-label">
                            <span className="subject-dna-emoji">{subjectEmoji(subjectDNA.subject)}</span>
                            <b>{subjectDNA.subject}</b>
                            <span className={`subject-dna-risk risk-${subjectDNA.risk.toLowerCase()}`}>{subjectDNA.risk} risk</span>
                          </div>
                          <div className="subject-dna-score">
                            <span>DNA Score</span>
                            <b style={{ color: getRiskColor(subjectDNA.risk) }}>{subjectDNA.score}%</b>
                          </div>
                          <div className="subject-dna-track">
                            <div className="subject-dna-fill" style={{ width: `${subjectDNA.mastery}%`, background: getRiskColor(subjectDNA.risk) }} />
                          </div>
                          <div className="subject-dna-metrics">
                            <span>Mastery <b>{subjectDNA.mastery}%</b></span>
                            <span>Reasoning <b>{subjectDNA.reasoning}%</b></span>
                            <span>Problem Solving <b>{subjectDNA.problemSolving}%</b></span>
                            <span>Critical Thinking <b>{subjectDNA.criticalThinking}%</b></span>
                          </div>
                          <div className="subject-dna-concepts">
                            <div className="concept-group">
                              <small>{'\u2713'} STRENGTHS</small>
                              <div className="concept-chip-list">
                                {subjectDNA.strengths.length > 0
                                  ? subjectDNA.strengths.map(c => <span key={c} className="concept-chip strength">{c}</span>)
                                  : <span className="concept-empty">No strong chapters yet</span>}
                              </div>
                            </div>
                            <div className="concept-group">
                              <small>{'\u25CB'} LEARNING GAPS</small>
                              <div className="concept-chip-list">
                                {subjectDNA.gaps.length > 0
                                  ? subjectDNA.gaps.map(c => <span key={c} className="concept-chip gap">{c}</span>)
                                  : <span className="concept-empty">No weak chapters detected</span>}
                              </div>
                            </div>
                          </div>
                        </div>
                      )
                    })}
                  </div>
                </Reveal>
              )}

              <Reveal delay={0.32}>
                <div className="cognitive-skills-card">
                  <div className="subject-dna-head">
                    <h4 className="subject-results-title">Cognitive Skills</h4>
                    <span className="subject-results-caption">Derived from how you answered, not just what you scored</span>
                  </div>
                  <div className="cognitive-skills-grid">
                    {[
                      { label: 'Reasoning', icon: '\uD83E\uDDEB', value: profileSkills.reasoning.value, basis: profileSkills.reasoning.basis, tone: 'reasoning' },
                      { label: 'Problem Solving', icon: '\uD83D\uDD27', value: profileSkills.problemSolving.value, basis: profileSkills.problemSolving.basis, tone: 'problem' },
                      { label: 'Critical Thinking', icon: '\uD83D\uDCAF', value: profileSkills.criticalThinking.value, basis: profileSkills.criticalThinking.basis, tone: 'critical' }
                    ].map(skill => (
                      <div key={skill.label} className={`cognitive-skill-tile tone-${skill.tone}`}>
                        <div className="cognitive-skill-head">
                          <span className="cognitive-skill-icon">{skill.icon}</span>
                          <b>{skill.label}</b>
                        </div>
                        <b className="cognitive-skill-value">
                          <CountUp value={skill.value} />
                        </b>
                        <div className="cognitive-skill-track">
                          <div className="cognitive-skill-fill" style={{ width: `${skill.value}%` }} />
                        </div>
                        <small className="cognitive-skill-basis">{skill.basis}</small>
                      </div>
                    ))}
                  </div>
                </div>
              </Reveal>

              <Reveal delay={0.35}>
                <div className="dna-cta">
                  <div>
                    <h3>Ready to strengthen these areas?</h3>
                    <p>Pick a subject and work through your personalised chapters.</p>
                  </div>
                  <button
                    className="primary-button"
                    style={{ background: 'linear-gradient(100deg, #6557d8, #8073e0 60%, #50c1b4)', fontSize: 13, padding: '16px 34px' }}
                    onClick={() => setActiveTab('subjects')}
                  >
                    <span>{'\u2192'}</span> Start Learning Journey
                  </button>
                </div>
              </Reveal>
            </motion.div>
          )}

          {activeTab === 'subjects' && (
            <motion.div key="subjects" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} transition={{ duration: 0.3 }}>
              <Reveal>
                <h1 style={{ margin: '10px 0 8px', color: '#292b55', font: '600 clamp(28px,4vw,42px) Space Grotesk, sans-serif', letterSpacing: '-1.5px' }}>
                  Your <span style={{ color: '#6557d8' }}>Subjects</span>
                </h1>
                <p style={{ margin: '0 0 25px', color: '#8c92ab', fontSize: 12 }}>
                  Choose a subject, pick a chapter, then learn it the way that suits you best.
                </p>
              </Reveal>
              <SubjectExplorer student={student} onOpenChapter={onOpenChapter} />
            </motion.div>
          )}

          {activeTab === 'assessment' && (
            <motion.div key="assessment" initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: 20 }} transition={{ duration: 0.3 }}>
              <Reveal>
                <h1 style={{ margin: '10px 0 25px', color: '#292b55', font: '600 clamp(28px,4vw,42px) Space Grotesk, sans-serif', letterSpacing: '-1.5px' }}>
                  Assessment <span style={{ color: '#6557d8' }}>Tracking</span>
                </h1>
              </Reveal>

              {/* Assessment Results */}
              {assessmentResult && (
                <Reveal delay={0.1}>
                  <div className="result-card" style={{ padding: 24, border: '1px solid #d5d2f3', borderRadius: 16, background: 'linear-gradient(135deg, #fbfbff, #f3f1ff)', marginBottom: 25 }}>
                    <div className="result-card-top" style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', paddingBottom: 16, borderBottom: '1px solid #e6e5f1' }}>
                      <div>
                        <small style={{ display: 'block', color: '#989db2', font: '600 9px Space Grotesk, sans-serif', letterSpacing: 1, marginBottom: 4 }}>BASELINE ASSESSMENT</small>
                        <h3 style={{ margin: 0, color: '#383d65', font: '600 18px Space Grotesk, sans-serif' }}>{assessmentResult.studentName}</h3>
                      </div>
                      <div className="baseline-card-actions">
                        <span className="card-badge dna-badge" style={{ padding: '5px 10px', borderRadius: 5, font: '600 9px Space Grotesk, sans-serif', letterSpacing: 0.8, color: '#6558c7', background: '#e8e4ff' }}>COMPLETED</span>
                        <button className="review-open-btn" type="button" onClick={() => setShowReview(true)}>
                          Review Assessment
                        </button>
                      </div>
                    </div>
                    <div className="result-stats" style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20, padding: 20, marginTop: 10 }}>
                      <div><span style={{ display: 'block', color: '#9ca2b5', fontSize: 9 }}>SCORE</span><b style={{ display: 'block', margin: '4px 0 0', color: '#545b80', font: '600 20px Space Grotesk, sans-serif' }}><CountUp value={assessmentResult.score} /></b></div>
                      <div><span style={{ display: 'block', color: '#9ca2b5', fontSize: 9 }}>CORRECT</span><b style={{ display: 'block', margin: '4px 0 0', color: '#545b80', font: '600 20px Space Grotesk, sans-serif' }}>{assessmentResult.answeredCorrectly}/{assessmentResult.totalQuestions}</b></div>
                      <div><span style={{ display: 'block', color: '#9ca2b5', fontSize: 9 }}>SUBJECTS</span><b style={{ display: 'block', margin: '4px 0 0', color: '#545b80', font: '500 11px Space Grotesk, sans-serif' }}>{assessmentResult.subjects.join(', ')}</b></div>
                      <div><span style={{ display: 'block', color: '#9ca2b5', fontSize: 9 }}>RISK</span><b style={{ display: 'block', margin: '4px 0 0', color: getRiskColor(getRiskBadge(assessmentResult.score)), font: '600 11px Space Grotesk, sans-serif' }}>{getRiskBadge(assessmentResult.score)}</b></div>
                    </div>
                  </div>
                </Reveal>
              )}

              {/* Chapter-wise assessment tracking */}
              <Reveal delay={0.2}>
                <h2 className="tracking-title">Chapter-wise Assessment Tracking</h2>
                <p className="tracking-subtitle">
                  Take a chapter assessment, work through a learning mode to unlock the retest, then watch your DNA evolve.
                </p>

                {subjectDNAs.length === 0 ? (
                  <div className="explorer-empty"><h3>No subjects yet</h3><p>Register with Mathematics or Science to see chapters.</p></div>
                ) : (
                  <div className="tracking-groups">
                    {subjectDNAs.map(dna => {
                      const chapters = visibleChapters(dna.subject)
                      return (
                        <div key={dna.subject} className="tracking-group">
                          <div className="tracking-group-head">
                            <span className="tracking-group-emoji">{subjectEmoji(dna.subject)}</span>
                            <b>{dna.subject}</b>
                            <span className="tracking-group-meta">
                              {chapters.filter(c => chapterTracking.find(t => t.chapterName === c.name && t.subject === dna.subject)?.assessmentCompleted).length}/{chapters.length} chapters assessed
                            </span>
                          </div>

                          {chapters.map((chapter, index) => {
                            const tracking = chapterTracking.find(t => t.chapterName === chapter.name && t.subject === dna.subject)
                            const modes = completedModes[chapter.name] || []
                            const assessmentDone = Boolean(tracking?.assessmentCompleted)
                            const retestDone = Boolean(tracking?.retestCompleted)
                            const retestUnlocked = isRetestUnlocked(tracking)
                            const canTakeAssessment = !assessmentDone

return (
                              <div key={chapter.name} className="tracking-chapter">
                                <div className="tracking-chapter-id">
                                  <span className="tracking-chapter-number">{String(index + 1).padStart(2, '0')}</span>
                                  <b>{chapter.name}</b>
                                </div>

                                <div className="tracking-actions">
                                  <div className="tracking-action">
                                    <span className="tracking-action-label">Assessment</span>
                                    {assessmentDone ? (
                                      <span className="tracking-state is-done">{'\u2705'} Completed</span>
                                    ) : canTakeAssessment ? (
                                      <button
                                        className="tracking-btn"
                                        type="button"
                                        onClick={() => onStartRunner(dna.subject, chapter.name, 'assessment')}
                                      >Start</button>
                                    ) : null}
                                    {assessmentDone && <small className="tracking-score">{tracking?.assessmentScore}%</small>}
                                    {assessmentDone && (
                                      <button
                                        className="tracking-btn is-ghost"
                                        type="button"
                                        onClick={() => setReviewChapter({ subject: dna.subject, chapterName: chapter.name, tracking: tracking! })}
                                      >
                                        Review Assessment
                                      </button>
                                    )}
                                  </div>

                                  <div className="tracking-action">
                                    <span className="tracking-action-label">Retest</span>
                                    {retestDone ? (
                                      <span className="tracking-state is-done">{'\u2705'} Completed</span>
                                    ) : retestUnlocked ? (
                                      <button
                                        className="tracking-btn is-primary"
                                        type="button"
                                        onClick={() => onStartRunner(dna.subject, chapter.name, 'retest')}
                                      >Retake</button>
                                    ) : (
                                      <span className="tracking-state is-locked" title={assessmentDone ? 'Complete a learning mode to unlock' : 'Complete the assessment first'}>
                                        {'\uD83D\uDD12'} Locked
                                      </span>
                                    )}
                                    {retestDone && tracking?.currentVersion && <small className="tracking-score">{tracking.currentVersion.score}%</small>}
                                  </div>

                                  <div className="tracking-action">
                                    <span className="tracking-action-label">DNA</span>
                                    {tracking?.currentVersion ? (
                                      <button
                                        className="tracking-btn is-ghost"
                                        type="button"
                                        onClick={() => setShowDNAModal({ subject: dna.subject, chapterName: chapter.name, tracking })}
                                      >
                                        View DNA
                                      </button>
                                    ) : (
                                      <span className="tracking-state is-muted">Not available</span>
                                    )}
                                    {modes.length > 0 && (
                                      <small className="tracking-modes">{modes.length} {modes.length === 1 ? 'mode' : 'modes'} done</small>
                                    )}
                                  </div>
                                </div>
                              </div>
                            )
                          })}
                        </div>
                      )
                    })}
                  </div>
                )}
              </Reveal>

              {/* DNA Evolution */}
              <Reveal delay={0.3}>
                <h2 className="tracking-title">DNA Evolution</h2>
                <p className="tracking-subtitle">Every assessment and retest adds a new version to your learning DNA.</p>
                <DNAEvolution
                  entries={evolutionEntries}
                  baselineScore={assessmentResult ? assessmentResult.score : null}
                />
              </Reveal>

              {/* Success criteria */}
              <Reveal delay={0.35}>
                <h2 className="tracking-title">Your Learning Journey</h2>
                <p className="tracking-subtitle">The path to a fully personalised learning profile.</p>
                <SuccessCriteriaJourney completed={journeyProgress} />
              </Reveal>
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </div>
  )
}

// ---- LEARNING MODE ----
// ---- CHAPTER DNA ----
function ChapterDNA({ student, assessmentResult, onBack, onGoToDashboard }: { student: RegistrationData; assessmentResult: AssessmentResult; onBack: () => void; onGoToDashboard: () => void }) {
  const [showPopup, setShowPopup] = useState(true)
  const [showDashboard, setShowDashboard] = useState(false)
  const [activeChapter, setActiveChapter] = useState<string | null>(null)
  const subjects = student.preferredSubjects.filter(s => s === 'Mathematics' || s === 'Science')

  const chapterDNAs: ChapterDNA[] = useMemo(() => {
    const results: ChapterDNA[] = []
    const subjectChapters: Record<string, typeof subjectsData.Mathematics.chapters> = {
      Mathematics: subjectsData.Mathematics.chapters,
      Science: subjectsData.Science.chapters,
    }

    subjects.forEach(subject => {
      const chapters = subjectChapters[subject] || []
      chapters.forEach(chapter => {
        const chapterQuestions = chapter.questions
        const questionResults = assessmentResult.questionResults.filter(r =>
          chapterQuestions.some(q => q.questionId === r.questionId)
        )
        const correctCount = questionResults.filter(r => r.isCorrect).length
        const score = questionResults.length > 0 ? Math.round((correctCount / questionResults.length) * 100) : 0
        const mastery = calcMastery(score, 60)
        const risk = getRiskBadge(score)

        const strengths: string[] = []
        const gaps: string[] = []
        questionResults.forEach(r => {
          if (r.isCorrect) {
            if (!strengths.includes(r.concept)) strengths.push(r.concept)
          } else {
            if (!gaps.includes(r.concept)) gaps.push(r.concept)
          }
        })

        // If no questions from this chapter were in the assessment, generate synthetic data
        if (questionResults.length === 0) {
          results.push({
            chapter: chapter.name,
            subject,
            score: 0,
            mastery: 0,
            confidence: 0,
            risk: 'High' as const,
            strengths: [],
            gaps: chapterQuestions.slice(0, 2).map(q => q.concept),
            misconceptions: 'No data yet',
          })
        } else {
          results.push({
            chapter: chapter.name,
            subject,
            score,
            mastery,
            confidence: 60,
            risk,
            strengths,
            gaps,
            misconceptions: gaps.length > 0 ? 'Review ' + gaps.join(', ') : 'No misconceptions detected',
          })
        }
      })
    })
    return results
  }, [subjects, assessmentResult])

  if (showPopup) {
    const overallScore = Math.round(chapterDNAs.reduce((s, c) => s + c.score, 0) / Math.max(chapterDNAs.length, 1))
    const allStrengths = [...new Set(chapterDNAs.flatMap(c => c.strengths))]
    const allGaps = [...new Set(chapterDNAs.flatMap(c => c.gaps))]

    return (
      <div className="dna-popup-overlay">
        <div className="dna-popup-backdrop" />
        <div className="dna-particles" aria-hidden="true">
          {Array.from({ length: 20 }, (_, i) => (
            <span
              key={i}
              className="dna-particle"
              style={{
                left: `${(i * 17) % 100}%`,
                top: `${(i * 23) % 100}%`,
                width: 4 + (i % 4) * 2,
                height: 4 + (i % 4) * 2,
                background: i % 2 === 0 ? '#6557d8' : '#50c1b4',
                opacity: 0.3 + (i % 5) * 0.1,
                animation: `helix-rung-pulse ${1.5 + (i % 3) * 0.5}s ease-in-out infinite`,
                animationDelay: `${i * 0.2}s`,
              }}
            />
          ))}
        </div>
        <motion.div
          className="dna-popup-glass"
          initial={{ opacity: 0, scale: 0.85, y: 30 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          exit={{ opacity: 0, scale: 0.85, y: 30 }}
          transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
        >
          <div className="dna-popup-header">
            <div className="dna-popup-icon">{"\uD83E\uDDE0"}</div>
            <div>
              <span className="dna-popup-tag">LEARNING DNA GENERATED</span>
              <h2>{student.studentName}'s Profile</h2>
            </div>
          </div>

          <div className="dna-popup-gauge-section">
            <div className="dna-gauge-container">
              <svg className="dna-gauge-svg" viewBox="0 0 120 120">
                <circle cx="60" cy="60" r="50" fill="none" stroke="rgba(255,255,255,0.08)" strokeWidth="8" />
                <circle
                  cx="60"
                  cy="60"
                  r="50"
                  fill="none"
                  stroke="url(#gaugeGradient)"
                  strokeWidth="8"
                  strokeLinecap="round"
                  strokeDasharray={`${2 * Math.PI * 50}`}
                  strokeDashoffset={`${2 * Math.PI * 50 * (1 - overallScore / 100)}`}
                  transform="rotate(-90 60 60)"
                  style={{ transition: 'stroke-dashoffset 1.5s ease-out' }}
                />
                <defs>
                  <linearGradient id="gaugeGradient" x1="0%" y1="0%" x2="100%" y2="0%">
                    <stop offset="0%" stopColor="#6557d8" />
                    <stop offset="100%" stopColor="#50c1b4" />
                  </linearGradient>
                </defs>
              </svg>
              <div className="dna-gauge-text">
                <span className="dna-gauge-value"><CountUp value={overallScore} /></span>
                <span className="dna-gauge-label">OVERALL SCORE</span>
              </div>
            </div>
          </div>

          <div className="dna-popup-stats">
            <div className="dna-stat-card strengths-card">
              <h3>{"\uD83D\uDF31"} STRENGTHS</h3>
              <ul>
                {allStrengths.length > 0 ? allStrengths.slice(0, 4).map((s, i) => <li key={i}>{s}</li>) : <li>No strengths detected yet</li>}
              </ul>
            </div>
            <div className="dna-stat-card gaps-card">
              <h3>{"\uD83D\uDD34"} GAPS</h3>
              <ul>
                {allGaps.length > 0 ? allGaps.slice(0, 4).map((g, i) => <li key={i}>{g}</li>) : <li>No gaps detected</li>}
              </ul>
            </div>
          </div>

          <div className="dna-popup-bottom">
            <div className="dna-risk-section">
              <div className="dna-risk-indicator" style={{ background: getRiskColor(getRiskBadge(overallScore)), color: getRiskColor(getRiskBadge(overallScore)) }} />
              <div>
                <span className="dna-risk-label">RISK LEVEL</span>
                <span className="dna-risk-value" style={{ color: getRiskColor(getRiskBadge(overallScore)) }}>{getRiskBadge(overallScore)}</span>
              </div>
            </div>
            <div className="dna-focus-section">
              <span className="dna-focus-icon">{"\uD83C\uDFAF"}</span>
              <div>
                <span className="dna-focus-label">FOCUS AREA</span>
                <span className="dna-focus-value">{allGaps.length > 0 ? allGaps[0] : 'No focus needed'}</span>
              </div>
            </div>
          </div>

          <div className="dna-popup-action">
            <button
              className="dna-popup-continue"
              type="button"
              onClick={() => {
                setShowPopup(false)
                setShowDashboard(true)
                onGoToDashboard()
              }}
            >
              Explore Chapter DNA <span>{"\u2197"}</span>
            </button>
          </div>
        </motion.div>
      </div>
    )
  }

  return (
    <motion.div className="walkthrough" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <header className="walk-header">
        <Logo />
        <span style={{ color: '#858ba5', fontSize: 10, marginLeft: 'auto' }}>CHAPTER DNA</span>
        <button className="header-quiet" onClick={onBack}>{"\u2190"} Back</button>
      </header>
      <div style={{ maxWidth: 1100, margin: '0 auto', padding: '30px 25px 80px' }}>
        <Reveal>
          <h1 style={{ margin: '10px 0 25px', color: '#292b55', font: '600 clamp(28px,4vw,42px) Space Grotesk, sans-serif', letterSpacing: '-1.5px' }}>
            Chapter <span style={{ color: '#6557d8' }}>DNA</span> Profile
          </h1>
          <p style={{ color: '#8990aa', fontSize: 13, maxWidth: 500, marginBottom: 30 }}>
            Your Learning DNA breakdown by chapter for {subjects.join(' & ')}.
          </p>
        </Reveal>

        {subjects.map((subject, subjectIdx) => (
          <Reveal key={subject} delay={subjectIdx * 0.1}>
            <h2 style={{ font: '600 20px Space Grotesk, sans-serif', color: '#383d65', marginBottom: 15, marginTop: subjectIdx > 0 ? 30 : 0 }}>
              {subject === 'Mathematics' ? '\uD83D\uDED9' : '\uD83D\uDD2C'} {subject}
            </h2>
            <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(300px, 1fr))', gap: 15 }}>
              {chapterDNAs.filter(c => c.subject === subject).map((dna, idx) => (
                <motion.div
                  key={dna.chapter}
                  className="comparison-card"
                  style={{ cursor: 'pointer', borderLeft: `4px solid ${getRiskColor(dna.risk)}` }}
                  whileHover={{ y: -3, boxShadow: '0 17px 30px rgba(62,57,140,.1)' }}
                  onClick={() => setActiveChapter(activeChapter === dna.chapter ? null : dna.chapter)}
                >
                  <div className="card-top">
                    <div>
                      <div className="card-icon">{subject === 'Mathematics' ? '\uD83D\uDED9' : '\uD83D\uDD2C'}</div>
                      <div className="card-label">{subject.toUpperCase()}</div>
                      <h3 style={{ margin: '8px 0 0', color: '#383d65', font: '600 17px Space Grotesk, sans-serif' }}>{dna.chapter}</h3>
                    </div>
                    <span className={`card-badge ${dna.risk === 'Low' ? 'neutral-badge' : dna.risk === 'Medium' ? 'dna-badge' : 'dna-badge'}`} style={{ color: getRiskColor(dna.risk), background: `${getRiskColor(dna.risk)}18` }}>{dna.risk} Risk</span>
                  </div>
                  <div className="score-row">
                    <div><small>Score</small><strong><CountUp value={dna.score} /></strong></div>
                    <div><small>Mastery</small><strong style={{ color: '#4ebfb5', fontSize: 32 }}><CountUp value={dna.mastery} /></strong></div>
                  </div>
                  <div className="bar"><span style={{ width: `${dna.score}%`, background: getRiskColor(dna.risk) }} /></div>
                  {activeChapter === dna.chapter && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: 'auto' }}
                      exit={{ opacity: 0, height: 0 }}
                      style={{ marginTop: 15, paddingTop: 15, borderTop: '1px solid #eaebf1' }}
                    >
                      <div style={{ display: 'grid', gridTemplateColumns: '1fr 1fr', gap: 15 }}>
                        <div>
                          <span style={{ display: 'block', color: '#22c55e', fontSize: 9, marginBottom: 4, fontWeight: 600 }}>STRENGTHS</span>
                          {dna.strengths.length > 0 ? dna.strengths.map((s, i) => <div key={i} style={{ fontSize: 10, color: '#545b80', marginBottom: 2 }}>{"\u2713"} {s}</div>) : <span style={{ fontSize: 10, color: '#9298ae' }}>None yet</span>}
                        </div>
                        <div>
                          <span style={{ display: 'block', color: '#f59e0b', fontSize: 9, marginBottom: 4, fontWeight: 600 }}>GAPS</span>
                          {dna.gaps.length > 0 ? dna.gaps.map((g, i) => <div key={i} style={{ fontSize: 10, color: '#545b80', marginBottom: 2 }}>{"\u25CB"} {g}</div>) : <span style={{ fontSize: 10, color: '#9298ae' }}>None</span>}
                        </div>
                      </div>
                      <div style={{ marginTop: 10, padding: '8px 12px', borderRadius: 8, background: '#f0edff', fontSize: 10, color: '#545b7d' }}>
                        <strong>Misconception:</strong> {dna.misconceptions}
                      </div>
                    </motion.div>
                  )}
                </motion.div>
              ))}
            </div>
          </Reveal>
        ))}
      </div>
    </motion.div>
  )
}

// ---- ASSESSMENT COMPLETION ----
function AssessmentCompletion({ submissionData, onGenerateDNA }: {
  submissionData: AssessmentSubmissionData
  onGenerateDNA: () => void
}) {
  const [submitted, setSubmitted] = useState(false)
  const [submittedAt, setSubmittedAt] = useState<string>('')

  const handleConfirmSubmit = () => {
    setSubmitted(true)
    setSubmittedAt(new Date().toLocaleString())
  }

  return (
    <motion.div className="walkthrough" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <header className="walk-header">
        <Logo />
        <span style={{ color: '#858ba5', fontSize: 10, marginLeft: 'auto' }}>BASELINE ASSESSMENT</span>
      </header>
      <main className="chapter-result-content">
        <div className="section-wrap" style={{ textAlign: 'center', paddingBottom: 60 }}>
          <Reveal>
            <motion.div
              initial={{ scale: 0 }}
              animate={{ scale: submitted ? 1 : 1 }}
              transition={{ type: "spring", stiffness: 260, damping: 20 }}
              style={{ display: 'inline-flex', alignItems: 'center', justifyContent: 'center', width: 72, height: 72, borderRadius: '50%', background: 'linear-gradient(135deg, #22c55e, #16a34a)', marginBottom: 20 }}
            >
              <span style={{ color: '#fff', fontSize: 36 }}>{"\u2713"}</span>
            </motion.div>
          </Reveal>
          <Reveal>
            <div className="section-kicker" style={{ color: '#8177da' }}>ASSESSMENT COMPLETED</div>
            <h1 style={{ margin: '14px 0 12px' }}>Assessment<br /><span>Completed.</span></h1>
            <p style={{ maxWidth: 460, margin: '0 auto 36px', color: '#8990aa', fontSize: 13, lineHeight: 1.7 }}>
              Thank you, {submissionData.studentName}! Your responses have been recorded. Generate your Learning DNA to explore your personalized profile.
            </p>
          </Reveal>

          <Reveal delay={0.15}>
            <div className="result-card" style={{ maxWidth: 700, margin: '0 auto 40px', padding: 30 }}>
              <div className="result-card-top">
                <div className="result-score">
                  <span style={{ fontSize: 36 }}>{"\uD83E\uDDE0"}</span>
                  <small style={{ display: 'block', marginTop: 8 }}>Your DNA Score</small>
                  <b style={{ display: 'block', margin: '6px 0 0' }}><CountUp value={submissionData.assessmentResults.score} /></b>
                </div>
              </div>
              <div style={{ display: 'grid', gridTemplateColumns: 'repeat(4, 1fr)', gap: 20, padding: 20, marginTop: 15, borderTop: '1px solid #e6e5f1' }}>
                <div>
                  <span style={{ display: 'block', color: '#9ca2b5', fontSize: 9 }}>QUESTIONS ANSWERED</span>
                  <b style={{ display: 'block', margin: '4px 0 0', color: '#545b80', font: '600 18px Space Grotesk, sans-serif' }}>
                    {submissionData.assessmentResults.answeredCorrectly}/{submissionData.assessmentResults.totalQuestions}
                  </b>
                </div>
                <div>
                  <span style={{ display: 'block', color: '#9ca2b5', fontSize: 9 }}>SCORE</span>
                  <b style={{ display: 'block', margin: '4px 0 0', color: getRiskColor(getRiskBadge(submissionData.assessmentResults.score)), font: '600 18px Space Grotesk, sans-serif' }}>
                    {submissionData.assessmentResults.score}%
                  </b>
                </div>
                <div>
                  <span style={{ display: 'block', color: '#9ca2b5', fontSize: 9 }}>SUBJECTS</span>
                  <b style={{ display: 'block', margin: '4px 0 0', color: '#545b80', font: '500 11px Space Grotesk, sans-serif' }}>
                    {submissionData.selectedSubjects.join(', ')}
                  </b>
                </div>
                <div>
                  <span style={{ display: 'block', color: '#9ca2b5', fontSize: 9 }}>STATUS</span>
                  <b style={{ display: 'block', margin: '4px 0 0', color: '#22c55e', font: '600 11px Space Grotesk, sans-serif' }}>
                    Completed
                  </b>
                </div>
              </div>

              {submitted && submittedAt && (
                <motion.div
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  style={{ marginTop: 15, padding: '10px 14px', borderRadius: 8, background: '#f0fdf4', border: '1px solid #bbf7d0', color: '#166534', fontSize: 10, textAlign: 'center' }}
                >
                  {"\uD83D\uDCDD"} Assessment submitted at {submittedAt}
                </motion.div>
              )}
            </div>
          </Reveal>

          <Reveal delay={0.2}>
            <SubjectResultsCard
              subjectWiseResults={submissionData.subjectWiseResults}
              overall={{
                correct: submissionData.assessmentResults.answeredCorrectly,
                total: submissionData.assessmentResults.totalQuestions,
                percentage: submissionData.assessmentResults.score
              }}
            />
          </Reveal>

          <Reveal delay={0.25}>
            <div style={{ display: 'flex', gap: 12, justifyContent: 'center', flexWrap: 'wrap' }}>
              <button className="primary-button" style={{ background: 'linear-gradient(100deg, #6255d2, #8073e0 60%, #48c7b8)' }} onClick={handleConfirmSubmit}>
                <span>{"\uD83D\uDCE5"}</span> Confirm Submission
              </button>
            </div>
          </Reveal>

          <Reveal delay={0.35}>
            <motion.div
              style={{ marginTop: 32 }}
              whileHover={{ scale: 1.03 }}
              whileTap={{ scale: 0.97 }}
            >
              <button
                className="primary-button"
                style={{
                  background: 'linear-gradient(100deg, #6557d8, #8073e0 60%, #50c1b4)',
                  fontSize: 14,
                  padding: '18px 44px',
                  boxShadow: '0 15px 35px rgba(101,87,216,.35)',
                  minWidth: 280
                }}
                onClick={onGenerateDNA}
              >
                <span>{"\uD83E\uDDE0"}</span> Generate Learning DNA
              </button>
            </motion.div>
          </Reveal>
        </div>
      </main>
    </motion.div>
  )
}

// ---- SUBJECT-WISE RESULTS ----
function SubjectResultsCard({ subjectWiseResults, overall }: {
  subjectWiseResults: SubjectWiseResult[]
  overall: { correct: number; total: number; percentage: number }
}) {
  if (subjectWiseResults.length === 0) return null
  return (
    <div className="subject-results-card">
      <div className="subject-results-head">
        <h4 className="subject-results-title">Subject-Wise Results</h4>
        <span className="subject-results-caption">Performance split by subject</span>
      </div>
      <div className="subject-results-grid">
        {subjectWiseResults.map(result => (
          <div key={result.subject} className="subject-result-tile">
            <div className="subject-result-head">
              <span className="subject-result-emoji">{subjectEmoji(result.subject)}</span>
              <div>
                <small>SUBJECT</small>
                <b>{result.subject}</b>
              </div>
              <span className={`subject-result-risk risk-${getRiskBadge(result.percentage).toLowerCase()}`}>{getRiskBadge(result.percentage)}</span>
            </div>
            <div className="subject-result-score">
              <b>{result.score}<span>/{result.total}</span></b>
              <em>{result.percentage}%</em>
            </div>
            <div className="subject-result-track">
              <div className="subject-result-fill" style={{ width: `${result.percentage}%`, background: getRiskColor(getRiskBadge(result.percentage)) }} />
            </div>
            <div className="subject-result-meta">
              <span>{result.conceptsCorrect.length} concepts strong</span>
              <span>{result.conceptsIncorrect.length} to improve</span>
            </div>
          </div>
        ))}
      </div>
      <div className="subject-results-overall">
        <div>
          <small>OVERALL SCORE</small>
          <b>{overall.correct}<span>/{overall.total}</span></b>
        </div>
        <div className="subject-results-overall-track">
          <div className="subject-results-overall-fill" style={{ width: `${overall.percentage}%` }} />
        </div>
        <em>{overall.percentage}%</em>
      </div>
    </div>
  )
}

// ---- LEARNING DNA PAGE ----
function LearningDNAPage({ submissionData, initiallyGenerated = false, onGenerated, onBack, onGoToDashboard }: {
  submissionData: AssessmentSubmissionData
  /** When the profile already exists, skip straight to it instead of re-generating. */
  initiallyGenerated?: boolean
  onGenerated?: () => void
  onBack: () => void
  onGoToDashboard: () => void
}) {
  const [generating, setGenerating] = useState(false)
  const [generated, setGenerated] = useState(initiallyGenerated)
  const [score, setScore] = useState(initiallyGenerated ? submissionData.assessmentResults.score : 0)

  const confidenceWeights: Record<string, number> = { 'Very Confident': 100, 'Confident': 75, 'Unsure': 40, 'Guessing': 15 }
  const avgConfidence = useMemo(() => {
    const total = submissionData.confidenceResponses.reduce((sum, r) => sum + (confidenceWeights[r.confidenceLevel] || 0), 0)
    return Math.round(total / Math.max(submissionData.confidenceResponses.length, 1))
  }, [submissionData.confidenceResponses])

  const cognitiveSkills = submissionData.dnaInput.cognitiveSkills

  // Stages shown while the profile is being built, so the wait is informative
  // rather than a bare spinner.
  const GENERATION_STAGES = [
    'Reading your answers...',
    'Analysing confidence levels...',
    'Mapping strengths and gaps...',
    'Building your DNA profile...'
  ]
  const [stage, setStage] = useState(0)

  const handleGenerate = async () => {
    setGenerating(true)
    setStage(0)
    // Advance the stage text across the wait, then reveal the profile.
    const total = 2600
    const step = total / GENERATION_STAGES.length
    for (let i = 0; i < GENERATION_STAGES.length; i++) {
      await new Promise(resolve => setTimeout(resolve, step))
      setStage(i + 1)
    }
    setScore(submissionData.assessmentResults.score)
    setGenerating(false)
    setGenerated(true)
    onGenerated?.()
  }

  const strengths = submissionData.assessmentResults.questionResults
    .filter(r => r.isCorrect)
    .map(r => r.concept)
    .filter((v, i, a) => a.indexOf(v) === i)

  const gaps = submissionData.assessmentResults.questionResults
    .filter(r => !r.isCorrect)
    .map(r => r.concept)
    .filter((v, i, a) => a.indexOf(v) === i)

  return (
    <motion.div className="walkthrough" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
      <header className="walk-header">
        <Logo />
        <span style={{ color: '#858ba5', fontSize: 10, marginLeft: 'auto' }}>LEARNING DNA</span>
        <button className="header-quiet" onClick={onBack}>{"\u2190"} Back</button>
      </header>

      <main style={{ maxWidth: 900, margin: '0 auto', padding: '40px 25px 80px' }}>
        {!generated && !generating && (
          <Reveal>
            <div style={{ textAlign: 'center', marginTop: 40 }}>
              <span style={{ fontSize: 48, display: 'block', marginBottom: 16 }}>{"\uD83E\uDDE0"}</span>
              <h1 style={{ margin: '0 0 12px', color: '#292b55', font: '600 clamp(28px,4vw,42px) Space Grotesk, sans-serif', letterSpacing: '-1.5px' }}>
                Generate Your <span style={{ color: '#6557d8' }}>Learning DNA</span>
              </h1>
              <p style={{ color: '#8990aa', fontSize: 13, maxWidth: 500, margin: '0 auto 36px', lineHeight: 1.7 }}>
                Your DNA profile captures not just what you know, but how confident you are — creating a unique learner fingerprint.
              </p>

              <div className="dna-student-facts">
                <div className="dna-fact">
                  <span>STUDENT</span>
                  <b>{submissionData.studentName}</b>
                </div>
                <div className="dna-fact">
                  <span>CLASS</span>
                  <b>{submissionData.className}</b>
                </div>
                <div className="dna-fact">
                  <span>SUBJECTS</span>
                  <b>{submissionData.selectedSubjects.join(', ')}</b>
                </div>
                <div className="dna-fact">
                  <span>QUESTIONS</span>
                  <b>{submissionData.assessmentResults.answeredCorrectly}/{submissionData.assessmentResults.totalQuestions}</b>
                </div>
                <div className="dna-fact is-score">
                  <span>BASELINE SCORE</span>
                  <b style={{ color: getRiskColor(getRiskBadge(submissionData.assessmentResults.score)) }}>
                    <CountUp value={submissionData.assessmentResults.score} />
                  </b>
                </div>
                <div className="dna-fact">
                  <span>RESPONSES</span>
                  <b>{submissionData.confidenceResponses.length}</b>
                </div>
              </div>

              <SubjectResultsCard
                subjectWiseResults={submissionData.subjectWiseResults}
                overall={{
                  correct: submissionData.assessmentResults.answeredCorrectly,
                  total: submissionData.assessmentResults.totalQuestions,
                  percentage: submissionData.assessmentResults.score
                }}
              />

              <motion.button
                className="primary-button"
                style={{
                  background: 'linear-gradient(100deg, #6557d8, #8073e0 60%, #50c1b4)',
                  fontSize: 15,
                  padding: '20px 48px',
                  boxShadow: '0 15px 40px rgba(101,87,216,.4)',
                  minWidth: 320,
                  fontWeight: 700
                }}
                whileHover={{ scale: 1.04 }}
                whileTap={{ scale: 0.97 }}
                onClick={handleGenerate}
              >
                <span>{"\uD83E\uDDE0"}</span> Generate Baseline DNA
              </motion.button>
            </div>
          </Reveal>
        )}

        {generating && (
          <Reveal>
            <div className="dna-brain-loading">
              <div className="dna-brain-stage">
                <span className="dna-brain-ring" />
                <span className="dna-brain-ring is-lagging" />
                <motion.span
                  className="dna-brain-icon"
                  animate={{ scale: [1, 1.12, 1] }}
                  transition={{ duration: 1.6, repeat: Infinity, ease: 'easeInOut' }}
                >
                  {'\uD83E\uDDE0'}
                </motion.span>
              </div>
              <h2>Building Your Baseline DNA</h2>
              <p className="dna-brain-stage-label">{GENERATION_STAGES[Math.min(stage, GENERATION_STAGES.length - 1)]}</p>
              <div className="dna-brain-track">
                <motion.div
                  className="dna-brain-fill"
                  initial={{ width: '0%' }}
                  animate={{ width: '100%' }}
                  transition={{ duration: 2.6, ease: 'easeInOut' }}
                />
              </div>
              <ol className="dna-brain-steps">
                {GENERATION_STAGES.map((label, i) => (
                  <li key={label} className={i < stage ? 'is-done' : i === stage ? 'is-active' : ''}>
                    <span>{i < stage ? '\u2713' : i + 1}</span>{label.replace('...', '')}
                  </li>
                ))}
              </ol>
            </div>
          </Reveal>
        )}

        {generated && (
          <>
            <Reveal>
              <div className="dna-status-bar">
                <span className="dna-status-dot" />
                <span>BASELINE DNA PROFILE GENERATED</span>
              </div>
            </Reveal>

            <Reveal delay={0.1}>
              <section className="dna-hero-card">
                <div className="dna-hero-top">
                  <div className="dna-hero-identity">
                    <div className="dna-hero-avatar">{submissionData.studentName.split(' ').map(n => n[0]).join('').slice(0, 2).toUpperCase()}</div>
                    <div className="dna-hero-meta">
                      <small>LEARNER DNA PROFILE</small>
                      <h3>{submissionData.studentName}</h3>
                      <div className="dna-hero-tags">
                        <span>Class: {submissionData.className}</span>
                        <span>{submissionData.selectedSubjects.length} {submissionData.selectedSubjects.length === 1 ? 'Subject' : 'Subjects'}</span>
                        <span>{submissionData.dnaInput.totalQuestions} Questions</span>
                      </div>
                    </div>
                  </div>
                  <span className="dna-hero-badge">BASELINE</span>
                </div>

                <div className="dna-hero-metrics">
                  <div className="dna-metric">
                    <span className="dna-metric-label">OVERALL SCORE</span>
                    <b className="dna-metric-value" style={{ color: getRiskColor(getRiskBadge(score)) }}>
                      <CountUp value={score} />
                    </b>
                    <div className="dna-metric-track">
                      <div className="dna-metric-fill" style={{ width: `${score}%`, background: getRiskColor(getRiskBadge(score)) }} />
                    </div>
                  </div>
                  <div className="dna-metric">
                    <span className="dna-metric-label">CONFIDENCE</span>
                    <b className="dna-metric-value" style={{ color: '#4ebfb5' }}>
                      <CountUp value={avgConfidence} />
                    </b>
                    <div className="dna-metric-track">
                      <div className="dna-metric-fill" style={{ width: `${avgConfidence}%`, background: '#4ebfb5' }} />
                    </div>
                  </div>
                  <div className="dna-metric">
                    <span className="dna-metric-label">RISK LEVEL</span>
                    <b className={`dna-metric-risk risk-${getRiskBadge(score).toLowerCase()}`}>{getRiskBadge(score)}</b>
                    <p className="dna-metric-note">
                      {getRiskBadge(score) === 'Low' ? 'On track, no major gaps' : getRiskBadge(score) === 'Medium' ? 'Targeted support recommended' : 'Immediate remediation advised'}
                    </p>
                  </div>
                </div>
              </section>
            </Reveal>

            <Reveal delay={0.2}>
              <div className="dna-insight-grid">
                <div className="dna-insight-card is-strength">
                  <h4>{"\uD83C\uDF31"} STRENGTHS</h4>
                  {strengths.length > 0 ? (
                    <ul>
                      {strengths.map((s, i) => (
                        <li key={i}><span className="dna-insight-marker strength">{"\u2713"}</span>{s}</li>
                      ))}
                    </ul>
                  ) : (
                    <span className="dna-insight-empty">No strengths detected yet</span>
                  )}
                </div>
                <div className="dna-insight-card is-gap">
                  <h4>{"\uD83D\uDD34"} GAPS</h4>
                  {gaps.length > 0 ? (
                    <ul>
                      {gaps.map((g, i) => (
                        <li key={i}><span className="dna-insight-marker gap">{"\u25CB"}</span>{g}</li>
                      ))}
                    </ul>
                  ) : (
                    <span className="dna-insight-empty">No gaps detected</span>
                  )}
                </div>
              </div>
            </Reveal>

            <Reveal delay={0.3}>
              <SubjectResultsCard
                subjectWiseResults={submissionData.subjectWiseResults}
                overall={{
                  correct: submissionData.dnaInput.totalCorrect,
                  total: submissionData.dnaInput.totalQuestions,
                  percentage: submissionData.dnaInput.overallPercentage
                }}
              />
            </Reveal>

            <Reveal delay={0.3}>
              <div className="subject-dna-block">
                <div className="subject-dna-head">
                  <h4 className="subject-dna-title">Subject DNA Breakdown</h4>
                  <span className="subject-dna-caption">Mastery, confidence and concept coverage per subject</span>
                </div>
                {submissionData.dnaInput.subjectDNA.map(subjectDNA => (
                  <div key={subjectDNA.subject} className="subject-dna-row">
                    <div className="subject-dna-label">
                      <span className="subject-dna-emoji">{subjectEmoji(subjectDNA.subject)}</span>
                      <b>{subjectDNA.subject}</b>
                      <span className={`subject-dna-risk risk-${subjectDNA.risk.toLowerCase()}`}>{subjectDNA.risk} risk</span>
                    </div>
                    <div className="subject-dna-track">
                      <div className="subject-dna-fill" style={{ width: `${subjectDNA.mastery}%`, background: getRiskColor(subjectDNA.risk) }} />
                    </div>
                    <div className="subject-dna-metrics">
                      <span>Score <b>{subjectDNA.answeredCorrectly}/{subjectDNA.totalQuestions}</b></span>
                      <span>Mastery <b>{subjectDNA.mastery}%</b></span>
                      <span>Confidence <b>{subjectDNA.confidence}%</b></span>
                    </div>
                    <div className="subject-dna-concepts">
                      {subjectDNA.strengths.length > 0 && (
                        <div className="concept-group">
                          <small>{"\u2713"} STRENGTHS</small>
                          <div className="concept-chip-list">
                            {subjectDNA.strengths.slice(0, 4).map(c => <span key={c} className="concept-chip strength">{c}</span>)}
                          </div>
                        </div>
                      )}
                      {subjectDNA.gaps.length > 0 && (
                        <div className="concept-group">
                          <small>{"\u25CB"} GAPS</small>
                          <div className="concept-chip-list">
                            {subjectDNA.gaps.slice(0, 4).map(c => <span key={c} className="concept-chip gap">{c}</span>)}
                          </div>
                        </div>
                      )}
                      {subjectDNA.strengths.length === 0 && subjectDNA.gaps.length === 0 && (
                        <span className="concept-empty">No strengths or gaps detected</span>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </Reveal>

            <Reveal delay={0.32}>
              <div className="cognitive-skills-card">
                <div className="subject-dna-head">
                  <h4 className="subject-results-title">Cognitive Skills</h4>
                  <span className="subject-results-caption">Derived from how you answered, not just what you scored</span>
                </div>
                <div className="cognitive-skills-grid">
                  {[
                    { key: 'reasoning' as const, label: 'Reasoning', icon: '\uD83E\uDDEB', value: cognitiveSkills.reasoning, basis: cognitiveSkills.reasoningBasis, tone: 'reasoning' },
                    { key: 'problemSolving' as const, label: 'Problem Solving', icon: '\uD83D\uDD27', value: cognitiveSkills.problemSolving, basis: cognitiveSkills.problemSolvingBasis, tone: 'problem' },
                    { key: 'criticalThinking' as const, label: 'Critical Thinking', icon: '\uD83D\uDCAF', value: cognitiveSkills.criticalThinking, basis: cognitiveSkills.criticalThinkingBasis, tone: 'critical' }
                  ].map(skill => (
                    <div key={skill.key} className={`cognitive-skill-tile tone-${skill.tone}`}>
                      <div className="cognitive-skill-head">
                        <span className="cognitive-skill-icon">{skill.icon}</span>
                        <b>{skill.label}</b>
                      </div>
                      <b className="cognitive-skill-value">
                        <CountUp value={skill.value} />
                      </b>
                      <div className="cognitive-skill-track">
                        <div className="cognitive-skill-fill" style={{ width: `${skill.value}%` }} />
                      </div>
                      <small className="cognitive-skill-basis">{skill.basis}</small>
                    </div>
                  ))}
                </div>
              </div>
            </Reveal>

            <Reveal delay={0.35}>
              <div className="dna-cta">
                <div>
                  <h3>Your learning path is ready</h3>
                  <p>Continue into your personalised chapters, content and AI companion.</p>
                </div>
                <button
                  className="primary-button"
                  style={{ background: 'linear-gradient(100deg, #6557d8, #8073e0 60%, #50c1b4)', fontSize: 13, padding: '16px 34px' }}
                  onClick={onGoToDashboard}
                >
                  <span>{"\u2192"}</span> Start Learning Journey
                </button>
              </div>
            </Reveal>
          </>
        )}
      </main>
    </motion.div>
  )
}

// ---- MAIN APP ----
export default function App() {
  const [screen, setScreen] = useState<Screen>('register')
  const [student, setStudent] = useState<RegistrationData | null>(null)
  const [assessmentResult, setAssessmentResult] = useState<AssessmentResult | null>(null)
  const [showDNAPopup, setShowDNAPopup] = useState(false)
  const [showInitialDNAPopup, setShowInitialDNAPopup] = useState(false)
  const [passedToDashboard, setPassedToDashboard] = useState(false)
  const [baselineState, setBaselineState] = useState<BaselineAssessmentState | null>(null)
  const [submissionData, setSubmissionData] = useState<AssessmentSubmissionData | null>(null)
  // Once the baseline profile has been built, revisiting it shows the profile
  // directly instead of replaying the Generate step.
  const [baselineDnaGenerated, setBaselineDnaGenerated] = useState(false)
  const [chapterSelection, setChapterSelection] = useState<{ subject: string; chapter: string; mode: LearningMode } | null>(null)
  const [dashboardInitialTab, setDashboardInitialTab] = useState<DashboardTab>('profile')

  // Lifted out of Dashboard so tracking survives navigating to a chapter and back.
  const [chapterTracking, setChapterTracking] = useState<ChapterAssessmentTracking[]>([])
  const [completedModes, setCompletedModes] = useState<Record<string, string[]>>({})
  const [evolutionEntries, setEvolutionEntries] = useState<EvolutionEntry[]>([])
  const [companionUsed, setCompanionUsed] = useState(false)
  // Real chapter ids owned by the repository, keyed "subject::chapterName".
  const [chapterIds, setChapterIds] = useState<Record<string, string>>({})

  // Per-question results of the latest chapter attempt, keyed "subject::chapter".
  // The Assessment tab's chapter review reads this, so it is lifted here to
  // survive navigating into a chapter and back.
  const [chapterQuestionResults, setChapterQuestionResults] = useState<Record<string, ChapterQuestionResult[]>>({})

  const chapterIdFor = useCallback(
    (subject: string, chapterName: string) => chapterIds[`${subject}::${chapterName}`] || '',
    [chapterIds]
  )

  // Restore the learner's chapter progress so a page refresh does not lose it.
  const [progressLoadedFor, setProgressLoadedFor] = useState('')
  useEffect(() => {
    const studentId = student?.id
    if (!studentId || progressLoadedFor === studentId) return
    setProgressLoadedFor(studentId)

    const load = async () => {
      try {
        const chapters = await axios.get(`${API_URL}/repo/chapters`).then(r => r.data as { id: string; title: string; subject: string }[])
        const map: Record<string, string> = {}
        chapters.forEach(c => { map[`${c.subject}::${c.title}`] = c.id })
        setChapterIds(map)
      } catch {
        // Progress still works in-memory; persistence is simply unavailable.
      }

      try {
        const progress = await axios.get(`${API_URL}/progress/${encodeURIComponent(studentId)}`).then(r => r.data)
        const tracked: ChapterAssessmentTracking[] = (progress.chapters || []).map((entry: {
          chapter_id: string
          chapterName: string
          subject: string
          completedModes: string[]
          assessmentCompleted: boolean
          retestCompleted: boolean
          currentVersion: DNAVersion | null
          attempts: (Omit<ChapterAttempt, 'chapterName'> & { answers?: ChapterQuestionResult[] })[]
        }) => {
          const latest = entry.currentVersion
          const last = entry.attempts[entry.attempts.length - 1]
          return {
            chapterId: entry.chapter_id,
            chapterName: entry.chapterName,
            subject: entry.subject,
            assessmentCompleted: entry.assessmentCompleted,
            retestCompleted: entry.retestCompleted,
            retestAvailable: false,
            currentVersion: latest,
            completedModes: entry.completedModes || [],
            assessmentScore: last?.score ?? 0,
            reasoningScore: latest?.reasoning ?? 0,
            problemSolvingScore: latest?.problemSolving ?? 0,
            criticalThinkingScore: latest?.criticalThinking ?? 0,
            attempts: (entry.attempts || []).map(a => ({ ...a, chapterName: entry.chapterName }))
          }
        })
        if (tracked.length > 0) {
          setChapterTracking(tracked)
          setCompletedModes(tracked.reduce<Record<string, string[]>>((acc, t) => {
            if (t.completedModes.length > 0) acc[t.chapterName] = t.completedModes
            return acc
          }, {}))
          setEvolutionEntries((progress.evolution || []) as EvolutionEntry[])

          // Restore the per-question results of each chapter's latest attempt so
          // the chapter review is available immediately after a refresh.
          setChapterQuestionResults(tracked.reduce<Record<string, ChapterQuestionResult[]>>((acc, t) => {
            const last = t.attempts[t.attempts.length - 1]
            if (last?.answers && last.answers.length > 0) acc[`${t.subject}::${t.chapterName}`] = last.answers
            return acc
          }, {}))
        }
      } catch {
        // Leave the in-memory state as-is when progress cannot be read.
      }
    }

    load()
  }, [student?.id, progressLoadedFor])

  const addEvolutionEntry = (type: string, chapter: string, score: number, mastery: number, risk: string, version: number) => {
    setEvolutionEntries(prev => [...prev, { date: new Date().toISOString(), type, chapter, score, mastery, risk, version }])
  }

  const [runner, setRunner] = useState<{ subject: string; chapterName: string; kind: 'assessment' | 'retest' } | null>(null)

  const handleChapterAssessmentComplete = useCallback((
    chapterName: string,
    subject: string,
    result: { score: number; correct: number; total: number; reasoning: number; problemSolving: number; criticalThinking: number; questionResults: ChapterQuestionResult[] }
  ) => {
    const { score, correct, total, reasoning, problemSolving, criticalThinking, questionResults } = result
    const risk = getRiskBadge(score)
    const mastery = calcMastery(score, 70)
    const chapterId = chapterIdFor(subject, chapterName)

    // A tracking entry also exists once a learning mode is done, so the attempt kind
    // must key off whether the chapter was actually ASSESSED - otherwise a chapter
    // with only remediation progress stores its first assessment as a retest.
    const existing = chapterTracking.find(ct => ct.chapterName === chapterName && ct.subject === subject)
    const isRetest = Boolean(existing?.assessmentCompleted)

    // Persist before the in-memory update so a refresh keeps the attempt. The UI
    // updates regardless, so a backend outage never blocks the learner.
    if (chapterId && student?.id) {
      const payload = {
        student_id: student.id,
        chapter_id: chapterId,
        kind: isRetest ? 'retest' : 'assessment',
        score, correct, total, reasoning, problemSolving, criticalThinking,
        // Per-question results travel with the attempt so the chapter review
        // still works after a refresh.
        answers: questionResults
      }
      axios.post(`${API_URL}/progress/chapter-assessment`, payload).catch(() => {
        // Progress stays local for this session.
      })
    }

    setChapterQuestionResults(prev => ({ ...prev, [`${subject}::${chapterName}`]: questionResults }))

    setChapterTracking(prev => {
      // The second attempt is the retest; the first is the chapter assessment.
      const prior = prev.find(ct => ct.chapterName === chapterName && ct.subject === subject)
      const version = prior ? (prior.currentVersion?.version ?? 0) + 1 : 1
      const date = new Date().toISOString()
      const attempt: ChapterAttempt = {
        kind: isRetest ? 'retest' : 'assessment',
        attempt: version,
        chapterName,
        score, mastery, risk, correct, total, date,
        reasoning, problemSolving, criticalThinking
      }
      const updated: ChapterAssessmentTracking = {
        chapterId: `${subject}-${chapterName}`,
        chapterName,
        subject,
        assessmentCompleted: true,
        retestCompleted: isRetest || Boolean(prior?.retestCompleted),
        retestAvailable: false,
        currentVersion: { version, score, mastery, risk: risk.toString(), date, assessmentResult: null, reasoning, problemSolving, criticalThinking },
        completedModes: prior?.completedModes ?? [],
        assessmentScore: score,
        reasoningScore: reasoning,
        problemSolvingScore: problemSolving,
        criticalThinkingScore: criticalThinking,
        attempts: [...(prior?.attempts ?? []), attempt]
      }
      return prior
        ? prev.map(ct => ct.chapterName === chapterName && ct.subject === subject ? updated : ct)
        : [...prev, updated]
    })
  }, [chapterIdFor, chapterTracking, student?.id])

  const handleStartAssessment = (regData: RegistrationData) => {
    setStudent(regData)
    setScreen('baseline')
    setBaselineState({
      // Registration always supplies an id (server-allocated or device-local).
      // Fall back to a unique local one rather than a shared id, so a missing id
      // can never merge two learners' DNA.
      studentId: regData.id || `LOCAL-${Date.now().toString(36).toUpperCase()}`,
      studentName: regData.studentName,
      className: regData.class,
      preferredSubjects: regData.preferredSubjects
    })
  }

  const handleBaselineComplete = (data: AssessmentSubmissionData) => {
    setSubmissionData(data)
    // A fresh assessment means a fresh profile, so the Generate step runs again.
    setBaselineDnaGenerated(false)
    setScreen('learning-dna')
  }

  const handleGenerateLearningDNA = () => {
    setShowDNAPopup(true)
    setPassedToDashboard(false)
  }

  const handleDNAPopupClose = () => {
    setShowDNAPopup(false)
    setPassedToDashboard(true)
  }

  // The Dashboard owns chapter tracking, so the chapter screen reports remediation
  // back to App. This must stay above the early returns below: React requires the
  // same hooks in the same order on every render.
  const handleModeComplete = useCallback((chapterName: string, subject: string, mode: string, percentage = 100) => {
    const chapterId = chapterIdFor(subject, chapterName)
    if (chapterId && student?.id) {
      axios.post(`${API_URL}/progress/mode-complete`, {
        student_id: student.id,
        chapter_id: chapterId,
        mode,
        completion_percentage: percentage,
        completed: true
      }).catch(() => {
        // Remediation still counts for this session.
      })
    }

    setCompletedModes(prev => {
      const modes = prev[chapterName] || []
      if (modes.includes(mode)) return prev
      return { ...prev, [chapterName]: [...modes, mode] }
    })
    setChapterTracking(prev => prev.map(ct => {
      if (ct.chapterName !== chapterName || ct.subject !== subject) return ct
      if (ct.completedModes.includes(mode)) return ct
      return { ...ct, completedModes: [...ct.completedModes, mode] }
    }))
  }, [chapterIdFor, student?.id])

  const handleAssessmentComplete = (result: AssessmentResult) => {
    setAssessmentResult(result)
    setScreen('complete')
  }

  if (screen === 'register') {
    return <RegistrationScreen onStartAssessment={handleStartAssessment} />
  }

  if (screen === 'baseline' && baselineState) {
    return (
      <BaselineAssessmentPage
        student={baselineState}
        onBack={() => { setScreen('register'); setBaselineState(null) }}
        onComplete={handleBaselineComplete}
      />
    )
  }

  if (screen === 'learning-dna' && submissionData) {
    return (
      <LearningDNAPage
        submissionData={submissionData}
        initiallyGenerated={baselineDnaGenerated}
        onGenerated={() => setBaselineDnaGenerated(true)}
        onBack={() => {
          if (submissionData) {
            setAssessmentResult(submissionData.assessmentResults)
            setScreen('complete')
          } else {
            setScreen('register')
          }
        }}
        onGoToDashboard={() => {
          setAssessmentResult(submissionData.assessmentResults)
          if (!student) {
            setStudent({
              id: submissionData.studentId,
              studentName: submissionData.studentName,
              class: submissionData.className,
              schoolName: '',
              email: '',
              contactNumber: '',
              preferredSubjects: submissionData.selectedSubjects,
              learningGoal: ''
            })
          }
          setDashboardInitialTab('subjects')
          setScreen('dashboard')
        }}
      />
    )
  }

  if (screen === 'overview' && student) {
    return <AssessmentOverview student={student} onNext={() => setScreen('questions')} />
  }

  if (screen === 'questions' && student) {
    return <AssessmentQuestions student={student} onComplete={handleAssessmentComplete} />
  }

  if (screen === 'complete' && student && assessmentResult) {
    // The learner can revisit the assessment, but the completed result is kept in
    // App state, so going back never throws away their score.
    const openBaselineDNA = () => {
      if (submissionData) {
        setScreen('learning-dna')
      } else {
        setDashboardInitialTab('profile')
        setScreen('dashboard')
      }
    }

    return (
      <motion.div className="walkthrough" initial={{ opacity: 0 }} animate={{ opacity: 1 }}>
        <header className="walk-header"><Logo />
          <button className="header-quiet" onClick={() => setScreen('baseline')}>{"\u2190"} Back</button>
        </header>
        <main className="chapter-result-content">
          <div className="section-wrap" style={{ textAlign: 'center', paddingBottom: 60 }}>
            <Reveal>
              <div className="section-kicker" style={{ color: '#8177da' }}>BASELINE ASSESSMENT COMPLETE</div>
              <h1 style={{ margin: '14px 0 12px' }}>Assessment<br /><span>Completed.</span></h1>
              <p style={{ maxWidth: 460, margin: '0 auto 36px', color: '#8990aa', fontSize: 13, lineHeight: 1.7 }}>
                Your baseline is recorded. Open your DNA profile to see your strengths and gaps,
                then start your personalised learning journey.
              </p>
            </Reveal>
            <Reveal delay={0.15}>
              <div className="result-card" style={{ maxWidth: 700, margin: '0 auto 40px', padding: 30 }}>
                <div className="result-card-top">
                  <div className="result-score"><span style={{ fontSize: 36 }}>{"\uD83E\uDDE0"}</span><small style={{ display: 'block', marginTop: 8 }}>Your DNA Score</small><b style={{ display: 'block', margin: '6px 0 0' }}><CountUp value={assessmentResult.score} /></b></div>
                </div>
                <div style={{ display: 'grid', gridTemplateColumns: 'repeat(3, 1fr)', gap: 20, padding: 20, marginTop: 15, borderTop: '1px solid #e6e5f1' }}>
                  <div><span style={{ display: 'block', color: '#9ca2b5', fontSize: 9 }}>QUESTIONS ANSWERED</span><b style={{ display: 'block', margin: '4px 0 0', color: '#545b80', font: '600 18px Space Grotesk, sans-serif' }}>{assessmentResult.answeredCorrectly}/{assessmentResult.totalQuestions}</b></div>
                  <div><span style={{ display: 'block', color: '#9ca2b5', fontSize: 9 }}>SCORE</span><b style={{ display: 'block', margin: '4px 0 0', color: getRiskColor(getRiskBadge(assessmentResult.score)), font: '600 18px Space Grotesk, sans-serif' }}>{assessmentResult.score}%</b></div>
                  <div><span style={{ display: 'block', color: '#9ca2b5', fontSize: 9 }}>SUBJECTS</span><b style={{ display: 'block', margin: '4px 0 0', color: '#545b80', font: '500 11px Space Grotesk, sans-serif' }}>{assessmentResult.subjects.join(', ')}</b></div>
                </div>
              </div>
            </Reveal>
            <Reveal delay={0.25}>
              <div className="complete-actions">
                <button
                  className="primary-button is-hero"
                  style={{
                    background: 'linear-gradient(100deg, #6557d8, #8073e0 60%, #50c1b4)',
                    fontSize: 13,
                    padding: '16px 36px',
                    boxShadow: '0 15px 35px rgba(101,87,216,.3)',
                  }}
                  onClick={openBaselineDNA}
                >
                  <span>{"\uD83E\uDDE0"}</span> View Your Baseline DNA
                </button>
              </div>
            </Reveal>
          </div>
        </main>
      </motion.div>
    )
  }

  if (screen === 'chapter-dna' && student && assessmentResult) {
    return (
      <ChapterDNA
        student={student}
        assessmentResult={assessmentResult}
        onBack={() => setScreen('complete')}
        onGoToDashboard={() => setScreen('dashboard')}
      />
    )
  }

  if (runner) {
    return (
      <ChapterAssessmentRunner
        subject={runner.subject}
        chapterName={runner.chapterName}
        kind={runner.kind}
        onComplete={result => {
          handleChapterAssessmentComplete(runner.chapterName, runner.subject, result)
          addEvolutionEntry(
            runner.kind === 'retest' ? 'Retest' : 'Chapter Assessment',
            runner.chapterName,
            result.score,
            calcMastery(result.score, 70),
            getRiskBadge(result.score).toString(),
            1
          )
        }}
        onExit={() => setRunner(null)}
      />
    )
  }

  if (screen === 'chapter-content' && student && chapterSelection) {
    return (
      <ChapterLearningScreen
        student={student}
        subject={chapterSelection.subject}
        chapterName={chapterSelection.chapter}
        initialMode={chapterSelection.mode}
        onModeComplete={handleModeComplete}
        onCompanionUsed={() => setCompanionUsed(true)}
        onBack={() => setScreen('dashboard')}
      />
    )
  }

  if (screen === 'dashboard' && student) {
    return (
      <Dashboard
        student={student}
        assessmentResult={assessmentResult}
        initialTab={dashboardInitialTab}
        chapterTracking={chapterTracking}
        chapterQuestionResults={chapterQuestionResults}
        completedModes={completedModes}
        evolutionEntries={evolutionEntries}
        companionUsed={companionUsed}
        onBack={() => setScreen('complete')}
        onStartRunner={(subject, chapter, kind) => {
          // The runner is always launched from the Assessment tab, so return there on exit.
          setDashboardInitialTab('assessment')
          setRunner({ subject, chapterName: chapter, kind })
        }}
        onOpenChapter={(subject, chapter, mode) => {
          setChapterSelection({ subject, chapter, mode })
          setScreen('chapter-content')
        }}
      />
    )
  }

  return null
}
